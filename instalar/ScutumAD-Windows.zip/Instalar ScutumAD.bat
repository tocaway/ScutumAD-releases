@echo off
rem Instalador de ScutumAD para Windows (doble clic).
rem
rem Descarga el ayudante de actualizacion publicado en tocaway/ScutumAD-releases,
rem comprueba su SHA-256, lo copia a %USERPROFILE%\ScutumAD y lo registra en los
rem navegadores. El ayudante instala entonces la ultima version firmada de la
rem extension en %USERPROFILE%\ScutumAD\extension. curl no envia cookies ni referer.
setlocal EnableDelayedExpansion

set "RELEASES=https://raw.githubusercontent.com/tocaway/ScutumAD-releases/main"
if defined SCUTUMAD_RELEASES_URL set "RELEASES=%SCUTUMAD_RELEASES_URL%"
set "DEST=%USERPROFILE%\ScutumAD"
if defined SCUTUMAD_DEST set "DEST=%SCUTUMAD_DEST%"

echo === Instalar ScutumAD ===
echo.

:esperar
set "abierto="
for %%p in (chrome.exe msedge.exe brave.exe) do (
  tasklist /FI "IMAGENAME eq %%p" 2>nul | find /I "%%p" > nul && set "abierto=1"
)
if defined abierto (
  echo Primero cierra el navegador del todo y despues pulsa una tecla.
  pause > nul
  goto esperar
)

set "NAME=scutumad-updater-windows-amd64.exe"
if /I "%PROCESSOR_ARCHITECTURE%"=="ARM64" set "NAME=scutumad-updater-windows-arm64.exe"
if /I "%PROCESSOR_ARCHITEW6432%"=="ARM64" set "NAME=scutumad-updater-windows-arm64.exe"

set "TMPDIR=%TEMP%\scutumad-instalador-%RANDOM%"
mkdir "%TMPDIR%" || goto error_descarga

echo Descargando el actualizador...
curl.exe -fsSL -o "%TMPDIR%\%NAME%" "%RELEASES%/updater/%NAME%" || goto error_descarga
curl.exe -fsSL -o "%TMPDIR%\SHA256SUMS" "%RELEASES%/updater/SHA256SUMS" || goto error_descarga

set "EXPECTED="
for /f "tokens=1,2" %%a in ('type "%TMPDIR%\SHA256SUMS"') do (
  if "%%b"=="%NAME%" set "EXPECTED=%%a"
)
set "ACTUAL="
for /f "skip=1 delims=" %%h in ('certutil -hashfile "%TMPDIR%\%NAME%" SHA256') do (
  if not defined ACTUAL set "ACTUAL=%%h"
)
set "ACTUAL=%ACTUAL: =%"
if not defined EXPECTED goto error_firma
if /I not "%EXPECTED%"=="%ACTUAL%" goto error_firma

echo Instalando ScutumAD en %DEST%...
"%TMPDIR%\%NAME%" install "%DEST%" || goto error_instalar
rmdir /S /Q "%TMPDIR%" 2> nul

echo.
echo === Listo. Ahora, en Chrome (solo la primera vez) ===
echo.
echo 1. Abre Chrome y escribe en la barra de direcciones:  chrome://extensions
echo 2. Activa "Modo de desarrollador" (arriba a la derecha).
echo 3. Pulsa "Cargar descomprimida" y elige esta carpeta:
echo    %DEST%\extension
echo 4. Recomendado: en "Detalles" de ScutumAD, activa "Permitir scripts de usuario".
echo 5. Fija el icono de ScutumAD en la barra.
echo.
echo No borres ni muevas la carpeta ScutumAD de tu carpeta de usuario.
echo Las versiones nuevas se instalan desde ScutumAD - Configuracion - Actualizaciones.
echo.
start "" explorer "%DEST%"
pause
exit /b 0

:error_descarga
set "MSG=no se pudo descargar. Comprueba la conexion a internet."
goto fallo
:error_firma
set "MSG=el archivo descargado no es el publicado."
goto fallo
:error_instalar
set "MSG=la instalacion no termino (mira el mensaje de arriba)."
:fallo
if defined TMPDIR rmdir /S /Q "%TMPDIR%" 2> nul
echo.
echo ERROR: %MSG%
echo No se ha instalado nada. Puedes cerrar esta ventana.
pause
exit /b 1
