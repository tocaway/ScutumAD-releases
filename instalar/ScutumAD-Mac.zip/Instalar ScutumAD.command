#!/bin/bash
# Instalador de ScutumAD para macOS (doble clic).
#
# Descarga el ayudante de actualización publicado en tocaway/ScutumAD-releases,
# comprueba su SHA-256, lo copia a ~/ScutumAD y lo registra en los navegadores.
# El ayudante instala entonces la última versión firmada de la extensión en
# ~/ScutumAD/extension. Las descargas son anónimas: curl no envía cookies ni referer.
set -euo pipefail

RELEASES="${SCUTUMAD_RELEASES_URL:-https://raw.githubusercontent.com/tocaway/ScutumAD-releases/main}"
DEST="${SCUTUMAD_DEST:-$HOME/ScutumAD}"

fail() {
  echo
  echo "ERROR: $1"
  echo "No se ha instalado nada. Puedes cerrar esta ventana."
  exit 1
}

echo "=== Instalar ScutumAD ==="
echo

while pgrep -xq "Google Chrome|Microsoft Edge|Brave Browser|Chromium"; do
  echo "Primero cierra el navegador del todo (Cmd+Q) y después pulsa Intro."
  read -r
done

case "$(uname -m)" in
  arm64) name="scutumad-updater-darwin-arm64" ;;
  *) name="scutumad-updater-darwin-amd64" ;;
esac

tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT

echo "Descargando el actualizador…"
curl -fsSL --proto '=https,http' -o "$tmp/$name" "$RELEASES/updater/$name" || fail "no se pudo descargar. Comprueba la conexión a internet."
curl -fsSL --proto '=https,http' -o "$tmp/SHA256SUMS" "$RELEASES/updater/SHA256SUMS" || fail "no se pudo descargar la lista de comprobación."

expected="$(awk -v n="$name" '$2 == n { print $1 }' "$tmp/SHA256SUMS")"
actual="$(shasum -a 256 "$tmp/$name" | awk '{ print $1 }')"
[ -n "$expected" ] && [ "$expected" = "$actual" ] || fail "el archivo descargado no es el publicado."
chmod +x "$tmp/$name"

echo "Instalando ScutumAD en $DEST…"
"$tmp/$name" install "$DEST" || fail "la instalación no terminó (mira el mensaje de arriba)."

cat <<EOF

=== Listo. Ahora, en Chrome (solo la primera vez) ===

1. Abre Chrome y escribe en la barra de direcciones:  chrome://extensions
2. Activa «Modo de desarrollador» (arriba a la derecha).
3. Pulsa «Cargar descomprimida» y elige esta carpeta:
   $DEST/extension
4. Recomendado: en «Detalles» de ScutumAD, activa «Permitir scripts de usuario».
5. Fija el icono de ScutumAD en la barra.

No borres ni muevas la carpeta ScutumAD de tu carpeta de usuario.
Las versiones nuevas se instalan desde ScutumAD → Configuración → Actualizaciones.

EOF
open "$DEST" 2>/dev/null || true
echo "Puedes cerrar esta ventana."
