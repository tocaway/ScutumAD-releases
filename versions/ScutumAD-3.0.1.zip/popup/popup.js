(() => {
  let activeTab = null;
  let currentState = null;
  let noticeTimer = null;

  const elements = {
    blockPopupPageButton: document.getElementById("blockPopupPageButton"),
    statusCard: document.getElementById("statusCard"),
    statusLabel: document.getElementById("statusLabel"),
    statusHint: document.getElementById("statusHint"),
    siteName: document.getElementById("siteName"),
    protectionToggle: document.getElementById("protectionToggle"),
    adsToggle: document.getElementById("adsToggle"),
    trackersToggle: document.getElementById("trackersToggle"),
    youtubeToggle: document.getElementById("youtubeToggle"),
    annoyancesToggle: document.getElementById("annoyancesToggle"),
    learningToggle: document.getElementById("learningToggle"),
    malwareToggle: document.getElementById("malwareToggle"),
    stealthToggle: document.getElementById("stealthToggle"),
    siteModeButtons: [...document.querySelectorAll("[data-site-mode]")],
    loggerButton: document.getElementById("loggerButton"),
    siteHint: document.getElementById("siteHint"),
    notice: document.getElementById("notice"),
    optionsButton: document.getElementById("optionsButton")
  };

  function sendMessage(message) {
    return chrome.runtime.sendMessage(message);
  }

  async function getActiveTab() {
    const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    return tabs[0] || null;
  }

  function showNotice(message) {
    elements.notice.textContent = message;
    clearTimeout(noticeTimer);
    noticeTimer = setTimeout(() => {
      elements.notice.textContent = "";
    }, 3600);
  }

  const MODE_HINTS = {
    off: "Sin protección en este sitio.",
    basic: "Solo bloqueo de red: no oculta elementos.",
    optimal: "Red, ocultación y scriptlets (recomendado).",
    strict: "Óptimo y cierra cualquier pop-up no pedido."
  };

  function siteDomain() {
    const hostname = currentState?.hostname || "";
    return hostname.replace(/^www\./, "");
  }

  function updateStatus() {
    if (!currentState) {
      return;
    }

    const { settings, hostname, supported } = currentState;
    const whitelisted = currentState.siteMode === "off";
    const active = settings.protectionEnabled && !whitelisted;
    elements.statusCard.classList.toggle("is-off", !settings.protectionEnabled);
    elements.statusCard.classList.toggle("is-whitelisted", whitelisted);

    if (!supported) {
      elements.statusLabel.textContent = "NO DISPONIBLE";
      elements.statusHint.textContent = "Chrome no permite intervenir en esta página";
    } else if (whitelisted) {
      elements.statusLabel.textContent = "SITIO PERMITIDO";
      elements.statusHint.textContent = "ScutumAD está en pausa aquí";
    } else if (active) {
      elements.statusLabel.textContent = "PROTEGIDO";
      elements.statusHint.textContent = "Bloqueo local activo en esta página";
    } else {
      elements.statusLabel.textContent = "DESACTIVADO";
      elements.statusHint.textContent = "La protección está pausada";
    }

    elements.siteName.textContent = hostname || "Página interna de Chrome";
    elements.blockPopupPageButton.hidden = !(settings.learningEnabled && currentState.popupLearning?.available);
    elements.protectionToggle.checked = settings.protectionEnabled;
    elements.protectionToggle.disabled = !supported;
    elements.adsToggle.checked = settings.blockAds;
    elements.trackersToggle.checked = settings.blockTrackers;
    elements.youtubeToggle.checked = settings.youtubeProtection;
    elements.annoyancesToggle.checked = settings.blockAnnoyances;
    elements.learningToggle.checked = settings.learningEnabled;
    elements.malwareToggle.checked = settings.blockMalware;
    elements.stealthToggle.checked = settings.stealthMode !== false;

    elements.siteModeButtons.forEach((button) => {
      button.disabled = !supported;
      button.setAttribute("aria-checked", String(button.dataset.siteMode === currentState.siteMode));
    });
    elements.loggerButton.disabled = !supported;
    elements.siteHint.textContent = supported
      ? MODE_HINTS[currentState.siteMode] || MODE_HINTS.optimal
      : "Esta página no admite scripts de extensiones.";
    if (!elements.blockPopupPageButton.hidden) {
      elements.siteHint.textContent = `Abierta desde ${currentState.popupLearning.domain}. Puedes bloquear este destino publicitario.`;
    }
    elements.siteHint.title = elements.siteHint.textContent;

    [
      elements.adsToggle,
      elements.trackersToggle,
      elements.youtubeToggle,
      elements.annoyancesToggle,
      elements.learningToggle,
      elements.malwareToggle,
      elements.stealthToggle
    ]
      .forEach((control) => { control.disabled = !supported; });
  }

  async function loadState() {
    activeTab = await getActiveTab();
    if (!activeTab) {
      elements.siteName.textContent = "No hay una pestaña activa";
      return;
    }

    currentState = await sendMessage({
      type: "GET_STATE",
      tabId: activeTab.id,
      url: activeTab.url || ""
    });
    updateStatus();
  }

  async function updateSetting(key, value) {
    try {
      const result = await sendMessage({ type: "UPDATE_SETTINGS", patch: { [key]: value } });
      if (result?.settings) {
        await loadState();
        showNotice("Preferencia guardada localmente.");
      }
    } catch {
      showNotice("No se pudo guardar la preferencia.");
    }
  }

  async function setSiteMode(mode) {
    if (!currentState?.supported || mode === currentState.siteMode) {
      return;
    }
    try {
      const result = await sendMessage({
        type: "SET_SITE_MODE",
        domain: siteDomain(),
        hostname: currentState.hostname,
        mode
      });
      if (!result?.ok) throw new Error(result?.error);
      await loadState();
      showNotice(mode === "off"
        ? "Protección desactivada en este sitio."
        : "Modo guardado. Recarga la página para aplicarlo entero.");
    } catch {
      showNotice("No se pudo cambiar el modo del sitio.");
    }
  }

  elements.protectionToggle.addEventListener("change", (event) => {
    void updateSetting("protectionEnabled", event.target.checked);
  });

  [
    elements.adsToggle,
    elements.trackersToggle,
    elements.youtubeToggle,
    elements.annoyancesToggle,
    elements.learningToggle,
    elements.malwareToggle,
    elements.stealthToggle
  ].forEach((control) => {
    control.addEventListener("change", (event) => {
      void updateSetting(control.dataset.setting, event.target.checked);
    });
  });

  elements.siteModeButtons.forEach((button) => {
    button.addEventListener("click", () => {
      void setSiteMode(button.dataset.siteMode);
    });
  });

  elements.loggerButton.addEventListener("click", () => {
    void chrome.tabs.create({ url: chrome.runtime.getURL(`logger/logger.html?tab=${activeTab.id}`) });
  });

  elements.optionsButton.addEventListener("click", () => {
    void chrome.runtime.openOptionsPage();
  });
  elements.blockPopupPageButton.addEventListener("click", () => {
    elements.blockPopupPageButton.disabled = true;
    void sendMessage({ type: "LEARN_POPUP_PAGE", tabId: activeTab.id }).then(result => {
      if (!result?.ok) throw new Error(result?.error || "No se pudo guardar la página.");
      showNotice("Página publicitaria bloqueada para el sitio que la abrió.");
    }).catch(error => {
      elements.blockPopupPageButton.disabled = false;
      showNotice(error.message);
    });
  });

  void loadState().catch(() => {
    showNotice("No se pudo cargar el estado de ScutumAD.");
  });
})();
