(() => {
  const { DEFAULT_SETTINGS, KEYS: SETTINGS_KEYS } = globalThis.ScutumADSettings;

  let settings = { ...DEFAULT_SETTINGS };
  let noticeTimer = null;

  const elements = {
    adsToggle: document.getElementById("adsToggle"),
    trackersToggle: document.getElementById("trackersToggle"),
    youtubeToggle: document.getElementById("youtubeToggle"),
    annoyancesToggle: document.getElementById("annoyancesToggle"),
    learningToggle: document.getElementById("learningToggle"),
    malwareToggle: document.getElementById("malwareToggle"),
    stealthToggle: document.getElementById("stealthToggle"),
    whitelistForm: document.getElementById("whitelistForm"),
    domainInput: document.getElementById("domainInput"),
    modeInput: document.getElementById("modeInput"),
    domainError: document.getElementById("domainError"),
    whitelistList: document.getElementById("whitelistList"),
    emptyWhitelist: document.getElementById("emptyWhitelist"),
    autoUpdateToggle: document.getElementById("autoUpdateToggle"),
    listsStatus: document.getElementById("listsStatus"),
    userScriptsHint: document.getElementById("userScriptsHint"),
    updateLists: document.getElementById("updateLists"),
    useBundledLists: document.getElementById("useBundledLists"),
    listVersions: document.getElementById("listVersions"),
    exportSettings: document.getElementById("exportSettings"),
    importSettings: document.getElementById("importSettings"),
    importFile: document.getElementById("importFile"),
    learnedRuleCount: document.getElementById("learnedRuleCount"),
    learnedRuleList: document.getElementById("learnedRuleList"),
    emptyLearnedRules: document.getElementById("emptyLearnedRules"),
    clearLearnedRules: document.getElementById("clearLearnedRules"),
    notice: document.getElementById("notice")
  };

  function showNotice(message) {
    elements.notice.textContent = message;
    clearTimeout(noticeTimer);
    noticeTimer = setTimeout(() => {
      elements.notice.textContent = "";
    }, 3500);
  }

  function normalizeDomain(value) {
    let candidate = String(value || "").trim().toLowerCase();
    if (!candidate) {
      return null;
    }
    if (!candidate.includes("://")) {
      candidate = `https://${candidate}`;
    }

    try {
      const parsed = new URL(candidate);
      const hostname = parsed.hostname.replace(/^\.+|\.+$/g, "");
      if (!hostname || !/^[a-z0-9.-]+$/i.test(hostname)) {
        return null;
      }
      return hostname;
    } catch {
      return null;
    }
  }

  async function loadData() {
    const stored = await chrome.storage.local.get(DEFAULT_SETTINGS);
    settings = {
      ...DEFAULT_SETTINGS,
      ...stored,
      whitelist: Array.isArray(stored.whitelist) ? [...new Set(stored.whitelist)] : []
    };
    render();
  }

  async function saveSettings(patch) {
    const result = await chrome.runtime.sendMessage({
      type: "UPDATE_SETTINGS",
      patch
    });
    if (!result?.settings) {
      throw new Error(result?.error || "No se pudo guardar");
    }
    settings = result.settings;
    render();
  }

  const MODE_LABELS = { off: "Desactivado", basic: "Básico", optimal: "Óptimo", strict: "Estricto" };

  function setSiteMode(domain, mode) {
    return chrome.runtime.sendMessage({ type: "SET_SITE_MODE", domain, mode }).then((result) => {
      if (!result?.ok) throw new Error(result?.error || "No se pudo guardar");
      settings = result.settings;
      render();
    });
  }

  function renderWhitelist() {
    elements.whitelistList.replaceChildren();
    const entries = [
      ...settings.whitelist.map((domain) => [domain, "off"]),
      ...Object.entries(settings.siteModes || {})
    ].sort(([a], [b]) => a.localeCompare(b, "es"));
    elements.emptyWhitelist.hidden = entries.length > 0;

    entries.forEach(([domain, mode]) => {
      const item = document.createElement("li");
      item.className = "domain-item";

      const code = document.createElement("code");
      code.textContent = domain;

      const select = document.createElement("select");
      select.setAttribute("aria-label", `Modo de ${domain}`);
      for (const [value, label] of Object.entries(MODE_LABELS)) {
        const option = document.createElement("option");
        option.value = value;
        option.textContent = label;
        option.selected = value === mode;
        select.append(option);
      }
      select.addEventListener("change", () => {
        void setSiteMode(domain, select.value)
          .then(() => showNotice(`${domain}: modo ${MODE_LABELS[select.value]}.`))
          .catch(() => showNotice("No se pudo cambiar el modo."));
      });

      const button = document.createElement("button");
      button.className = "remove-domain";
      button.type = "button";
      button.textContent = "Quitar";
      button.addEventListener("click", () => {
        void setSiteMode(domain, "optimal")
          .then(() => showNotice(`${domain} vuelve al modo Óptimo.`))
          .catch(() => showNotice("No se pudo cambiar el modo."));
      });

      item.append(code, select, button);
      elements.whitelistList.append(item);
    });
  }


  function renderLearnedRules() {
    const rules = Array.isArray(settings.learnedRules) ? [...settings.learnedRules] : [];
    elements.learnedRuleList.replaceChildren();
    elements.learnedRuleCount.textContent = `${rules.length} regla${rules.length === 1 ? "" : "s"} guardada${rules.length === 1 ? "" : "s"}`;
    elements.emptyLearnedRules.hidden = rules.length > 0;
    elements.clearLearnedRules.disabled = rules.length === 0;

    rules
      .sort((a, b) => `${a.domain}${a.selector || a.destinationDomain}`.localeCompare(`${b.domain}${b.selector || b.destinationDomain}`, "es"))
      .forEach((rule) => {
        const item = document.createElement("li");
        item.className = "learned-rule-item";

        const copy = document.createElement("div");
        const domain = document.createElement("strong");
        domain.textContent = rule.domain;
        const selector = document.createElement("code");
        selector.textContent = rule.action === "block-popup" ? `Página publicitaria: ${rule.destinationDomain}` : rule.selector;
        if (rule.frameDomain) domain.textContent += ` · marco ${rule.frameDomain}`;
        copy.append(domain, selector);
        if (rule.disabled) {
          const note = document.createElement("small");
          note.textContent = "Pendiente de nueva selección: regla antigua demasiado amplia. No se aplica.";
          copy.append(note);
        }

        const button = document.createElement("button");
        button.className = "remove-domain";
        button.type = "button";
        button.textContent = "Eliminar";
        button.addEventListener("click", () => {
          void chrome.runtime.sendMessage({ type: "REMOVE_LEARNED_RULE", ruleId: rule.id })
            .then((result) => {
              if (!result?.ok) throw new Error(result?.error || "No se pudo eliminar");
              settings.learnedRules = result.learnedRules;
              renderLearnedRules();
              showNotice("Regla aprendida eliminada.");
            })
            .catch(() => showNotice("No se pudo eliminar la regla aprendida."));
        });

        item.append(copy, button);
        elements.learnedRuleList.append(item);
      });
  }

  function render() {
    elements.adsToggle.checked = settings.blockAds;
    elements.trackersToggle.checked = settings.blockTrackers;
    elements.youtubeToggle.checked = settings.youtubeProtection;
    elements.annoyancesToggle.checked = settings.blockAnnoyances;
    elements.learningToggle.checked = settings.learningEnabled;
    elements.malwareToggle.checked = settings.blockMalware;
    elements.stealthToggle.checked = settings.stealthMode !== false;
    elements.autoUpdateToggle.checked = settings.autoUpdateLists !== false;
    renderWhitelist();
    renderLearnedRules();
  }

  [
    elements.adsToggle,
    elements.trackersToggle,
    elements.youtubeToggle,
    elements.annoyancesToggle,
    elements.learningToggle,
    elements.malwareToggle,
    elements.stealthToggle,
    elements.autoUpdateToggle
  ].forEach((control) => {
    control.addEventListener("change", () => {
      void saveSettings({ [control.dataset.setting]: control.checked })
        .then(() => showNotice("Preferencia guardada localmente."))
        .catch(() => showNotice("No se pudo guardar la preferencia."));
    });
  });

  elements.whitelistForm.addEventListener("submit", (event) => {
    event.preventDefault();
    elements.domainError.textContent = "";
    const domain = normalizeDomain(elements.domainInput.value);
    if (!domain) {
      elements.domainError.textContent = "Escribe un dominio válido, por ejemplo: ejemplo.com";
      return;
    }
    const mode = elements.modeInput.value;
    void setSiteMode(domain, mode)
      .then(() => {
        elements.domainInput.value = "";
        showNotice(`${domain}: modo ${MODE_LABELS[mode]}.`);
      })
      .catch(() => showNotice("No se pudo guardar el modo."));
  });


  function formatDate(timestamp) {
    return new Date(timestamp).toLocaleString("es", { dateStyle: "medium", timeStyle: "short" });
  }

  function renderListsStatus(status) {
    const { meta = {}, bundled, userScripts } = status || {};
    const parts = [];
    if (meta.dynamic && meta.updatedAt) {
      parts.push(`Listas actualizadas el ${formatDate(meta.updatedAt)} (${(meta.ruleCount || 0).toLocaleString("es")} reglas de red).`);
    } else {
      parts.push(`Se usan las listas incluidas en esta versión${bundled?.built ? `, compiladas el ${formatDate(bundled.built)}` : ""}.`);
    }
    if (meta.lastError) parts.push(`Último aviso: ${meta.lastError}.`);
    elements.listsStatus.textContent = parts.join(" ");
    elements.userScriptsHint.hidden = userScripts !== false;
    elements.useBundledLists.disabled = !meta.dynamic;
    const versions = meta.dynamic && meta.versions ? meta.versions : bundled?.versions || {};
    elements.listVersions.replaceChildren(...Object.entries(versions).map(([name, version]) => {
      const item = document.createElement("li");
      item.textContent = `${name}: ${version}`;
      return item;
    }));
  }

  function loadListsStatus() {
    return chrome.runtime.sendMessage({ type: "LISTS_STATUS" }).then(renderListsStatus);
  }

  elements.updateLists.addEventListener("click", () => {
    elements.updateLists.disabled = true;
    elements.listsStatus.textContent = "Descargando y compilando las listas…";
    void chrome.runtime.sendMessage({ type: "UPDATE_LISTS" })
      .then(() => loadListsStatus())
      .then(() => showNotice("Listas actualizadas."))
      .catch(() => showNotice("No se pudieron actualizar las listas."))
      .finally(() => { elements.updateLists.disabled = false; });
  });

  elements.useBundledLists.addEventListener("click", () => {
    void chrome.runtime.sendMessage({ type: "USE_BUNDLED_LISTS" })
      .then(() => loadListsStatus())
      .then(() => showNotice("Se usan las listas incluidas en esta versión."))
      .catch(() => showNotice("No se pudo cambiar a las listas incluidas."));
  });

  elements.exportSettings.addEventListener("click", () => {
    void chrome.runtime.sendMessage({ type: "EXPORT_SETTINGS" })
      .then((result) => {
        if (!result?.ok) throw new Error(result?.error || "No se pudo exportar");
        const blob = new Blob([JSON.stringify(result.data, null, 2)], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = `ScutumAD-ajustes-${new Date().toISOString().slice(0, 10)}.json`;
        link.click();
        setTimeout(() => URL.revokeObjectURL(url), 60000);
        showNotice("Ajustes exportados.");
      })
      .catch(() => showNotice("No se pudieron exportar los ajustes."));
  });

  elements.importSettings.addEventListener("click", () => {
    elements.importFile.value = "";
    elements.importFile.click();
  });

  elements.importFile.addEventListener("change", () => {
    const file = elements.importFile.files?.[0];
    if (!file) return;
    if (file.size > 1024 * 1024) {
      showNotice("El archivo es demasiado grande para ser una copia de ScutumAD.");
      return;
    }
    void file.text()
      .then((text) => chrome.runtime.sendMessage({ type: "IMPORT_SETTINGS", data: JSON.parse(text) }))
      .then((result) => {
        if (!result?.ok) throw new Error(result?.error || "No se pudo importar");
        settings = result.settings;
        render();
        showNotice("Ajustes importados.");
      })
      .catch((error) => showNotice(error instanceof SyntaxError
        ? "El archivo no es un JSON válido."
        : error.message || "No se pudieron importar los ajustes."));
  });

  elements.clearLearnedRules.addEventListener("click", () => {
    void chrome.runtime.sendMessage({ type: "CLEAR_LEARNED_RULES" })
      .then((result) => {
        if (!result?.ok) throw new Error(result?.error || "No se pudo borrar");
        settings.learnedRules = [];
        renderLearnedRules();
        showNotice("Reglas aprendidas eliminadas.");
      })
      .catch(() => showNotice("No se pudieron borrar las reglas aprendidas."));
  });

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === "local" && SETTINGS_KEYS.some((key) => key in changes)) {
      void loadData();
    }
  });

  void loadData().catch(() => showNotice("No se pudo cargar la configuración."));
  void loadListsStatus().catch(() => { elements.listsStatus.textContent = "No se pudo leer el estado de las listas."; });
})();
