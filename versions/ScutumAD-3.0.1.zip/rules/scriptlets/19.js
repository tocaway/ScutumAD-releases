// Generado por scripts/build-rules.mjs a partir de src/scriptlets/engine.js.
// Motor de scriptlets de ScutumAD (implementación propia, compatible con los
// nombres de uBlock Origin y Adblock Plus). Se ejecuta en el mundo MAIN antes
// que la página. RULES_PLACEHOLDER se sustituye por { rules, exceptions }:
// en la publicación (rules/scriptlets.js) o al actualizar las listas.
(function scutumadScriptlets(data) {
  "use strict";
  const hostname = location.hostname.toLowerCase().replace(/\.$/, "");
  if (!hostname) return;
  // Segunda defensa: nunca scriptlets de las listas en YouTube (detecta que
  // se reescriben sus respuestas y bloquea el vídeo).
  if (/(?:^|\.)youtube(?:-nocookie|kids)?\.com$/.test(hostname)) return;

  // Claves que aplican a este host: el dominio y sus padres, y las
  // entidades (ejemplo.*) cuando quedan como mucho dos etiquetas de TLD.
  const labels = hostname.split(".");
  const keys = [];
  for (let start = 0; start < labels.length; start++) {
    keys.push(labels.slice(start).join("."));
    for (let end = Math.max(start + 1, labels.length - 2); end < labels.length; end++) {
      keys.push(`${labels.slice(start, end).join(".")}.*`);
    }
  }
  const exceptions = new Set(keys.flatMap((key) => data.exceptions[key] || []));
  if (exceptions.has("*")) return;
  const seen = new Set();
  const rules = keys.flatMap((key) => data.rules[key] || []).filter((rule) => {
    const signature = rule.join("\u0000");
    if (seen.has(signature) || exceptions.has(signature)) return false;
    seen.add(signature);
    return true;
  });
  if (!rules.length) return;

  const MARKER = `scutumad-${Math.random().toString(36).slice(2)}`;
  const defineProperty = Object.defineProperty;
  const getDescriptor = Object.getOwnPropertyDescriptor;
  const apply = Reflect.apply;

  window.addEventListener("error", (event) => {
    if (typeof event.message === "string" && event.message.includes(MARKER)) event.preventDefault();
  }, true);
  const abort = () => {
    throw new ReferenceError(MARKER);
  };

  // Aguja: texto o /regex/flags; "!" delante invierte; vacía casa con todo.
  function matcher(needle = "") {
    let negate = false;
    let text = String(needle);
    if (text.startsWith("!")) {
      negate = true;
      text = text.slice(1);
    }
    if (!text) return () => !negate;
    const regex = /^\/(.+)\/([gimsu]*)$/.exec(text);
    let test;
    if (regex) {
      try {
        const pattern = new RegExp(regex[1], regex[2].replace("g", ""));
        test = (value) => pattern.test(value);
      } catch {
        return () => false;
      }
    } else {
      test = (value) => value.includes(text);
    }
    return (value) => test(String(value)) !== negate;
  }

  function regexOrText(value) {
    const regex = /^\/(.+)\/([gimsu]*)$/.exec(value);
    if (regex) {
      try {
        return new RegExp(regex[1], regex[2]);
      } catch {
        return null;
      }
    }
    return value;
  }

  const noop = () => {};
  function constantValue(raw, extra = []) {
    const factories = {
      undefined: () => undefined, false: () => false, true: () => true, null: () => null,
      "": () => "", emptyStr: () => "",
      noopFunc: () => noop, trueFunc: () => () => true, falseFunc: () => () => false,
      throwFunc: () => () => { throw new Error(); }, noopCallbackFunc: () => () => noop,
      emptyArray: () => [], "[]": () => [], emptyObj: () => ({}), "{}": () => ({}),
      yes: () => "yes", no: () => "no", on: () => "on", off: () => "off"
    };
    let value;
    if (Object.prototype.hasOwnProperty.call(factories, raw)) {
      value = factories[raw]();
    } else if (/^-?\d+(?:\.\d+)?$/.test(raw) && Math.abs(Number(raw)) <= 0x7fff) {
      value = Number(raw);
    } else {
      return { ok: false };
    }
    if (extra.includes("asFunction")) {
      const inner = value;
      value = () => inner;
    } else if (extra.includes("asCallback")) {
      const inner = value;
      value = () => () => inner;
    } else if (extra.includes("asResolved")) {
      value = Promise.resolve(value);
    } else if (extra.includes("asRejected")) {
      value = Promise.reject(value);
    }
    return { ok: true, value };
  }

  // Getter/setter en el último eslabón de `chain` (a.b.c). Si un eslabón aún
  // no existe, espera a que la página lo cree.
  function trapChain(owner, chain, makeDescriptor) {
    const dot = chain.indexOf(".");
    const name = dot < 0 ? chain : chain.slice(0, dot);
    const rest = dot < 0 ? "" : chain.slice(dot + 1);
    if (!rest) {
      const current = getDescriptor(owner, name);
      if (current && current.configurable === false) return;
      try {
        defineProperty(owner, name, { configurable: true, ...makeDescriptor(current, owner) });
      } catch {
        // Propiedad protegida.
      }
      return;
    }
    const next = owner[name];
    if (next && (typeof next === "object" || typeof next === "function")) {
      trapChain(next, rest, makeDescriptor);
      return;
    }
    let value = next;
    try {
      defineProperty(owner, name, {
        configurable: true,
        get: () => value,
        set(newValue) {
          value = newValue;
          if (newValue && (typeof newValue === "object" || typeof newValue === "function")) {
            trapChain(newValue, rest, makeDescriptor);
          }
        }
      });
    } catch {
      // Propiedad protegida.
    }
  }

  function holder(current, owner) {
    let value = current && "value" in current ? current.value : undefined;
    return {
      read: () => (current?.get ? apply(current.get, owner, []) : value),
      write: (newValue) => (current?.set ? apply(current.set, owner, [newValue]) : (value = newValue))
    };
  }

  function guardedChain(chain, shouldAbort) {
    trapChain(window, chain, (current, owner) => {
      const store = holder(current, owner);
      return {
        get() {
          if (shouldAbort()) abort();
          return store.read();
        },
        set(newValue) {
          if (shouldAbort()) abort();
          store.write(newValue);
        }
      };
    });
  }

  // Rutas de json-prune: a.b, [] (cada elemento) y [-] (quita el elemento
  // del array si contiene el resto de la ruta).
  function prune(object, parts) {
    if (!object || typeof object !== "object") return false;
    const [part, ...rest] = parts;
    if (part === "[]") {
      if (!Array.isArray(object)) return false;
      let changed = false;
      object.forEach((item) => { changed = prune(item, rest) || changed; });
      return changed;
    }
    if (part === "[-]") {
      if (!Array.isArray(object)) return false;
      let changed = false;
      for (let index = object.length - 1; index >= 0; index--) {
        if (hasPath(object[index], rest)) {
          object.splice(index, 1);
          changed = true;
        }
      }
      return changed;
    }
    if (!rest.length) {
      if (!(part in object)) return false;
      delete object[part];
      return true;
    }
    return prune(object[part], rest);
  }

  function hasPath(object, parts) {
    let current = object;
    for (const part of parts) {
      if (part === "[]" || part === "[-]") {
        return Array.isArray(current) && current.some((item) => hasPath(item, parts.slice(parts.indexOf(part) + 1)));
      }
      if (!current || typeof current !== "object" || !(part in current)) return false;
      current = current[part];
    }
    return true;
  }

  function pruner(prunePaths = "", neededPaths = "") {
    const toPrune = prunePaths.split(/\s+/).filter(Boolean).map((path) => path.split("."));
    const needed = neededPaths.split(/\s+/).filter(Boolean).map((path) => path.split("."));
    return (value) => {
      if (value && typeof value === "object" && needed.every((path) => hasPath(value, path))) {
        toPrune.forEach((path) => prune(value, path));
      }
      return value;
    };
  }

  // Argumentos "propsToMatch, valor" al final de algunos scriptlets.
  function propsToMatch(args) {
    const index = args.indexOf("propsToMatch");
    return index >= 0 ? args[index + 1] || "" : "";
  }

  // "url:x method:POST" o simplemente "x" (que se compara con la URL).
  function requestMatcher(needle = "") {
    if (!needle || needle === "*") return () => true;
    const tests = needle.split(/\s+/).filter(Boolean).map((part) => {
      const colon = part.indexOf(":");
      const known = colon > 0 && ["url", "method", "body", "headers", "mode", "credentials"].includes(part.slice(0, colon));
      const key = known ? part.slice(0, colon) : "url";
      return [key, matcher(known ? part.slice(colon + 1) : part)];
    });
    return (details) => tests.every(([key, test]) => test(details[key] ?? ""));
  }

  function fetchDetails(args) {
    const [resource, init = {}] = args;
    const isRequest = typeof Request === "function" && resource instanceof Request;
    return {
      url: String(isRequest ? resource.url : resource),
      method: String(init.method || (isRequest ? resource.method : "GET")).toUpperCase(),
      body: typeof init.body === "string" ? init.body : ""
    };
  }

  function rebuildResponse(original, text) {
    const response = new Response(text, {
      status: original.status, statusText: original.statusText, headers: original.headers
    });
    try {
      defineProperty(response, "url", { value: original.url });
      defineProperty(response, "redirected", { value: original.redirected });
      defineProperty(response, "type", { value: original.type });
    } catch {}
    return response;
  }

  const fetchFilters = [];
  function hookFetch() {
    if (hookFetch.done || typeof fetch !== "function") return;
    hookFetch.done = true;
    window.fetch = new Proxy(window.fetch, {
      apply(target, thisArg, args) {
        const details = fetchDetails(args);
        for (const filter of fetchFilters) {
          if (filter.block && filter.matches(details)) {
            return Promise.resolve(new Response(filter.body || "", { status: 200, statusText: "OK" }));
          }
        }
        const editors = fetchFilters.filter((filter) => !filter.block && filter.matches(details));
        const result = apply(target, thisArg, args);
        if (!editors.length) return result;
        return result.then((response) => response.clone().text().then((text) => {
          let edited = text;
          for (const editor of editors) edited = editor.edit(edited);
          return edited === text ? response : rebuildResponse(response, edited);
        }).catch(() => response));
      }
    });
  }

  const xhrFilters = [];
  const xhrState = new WeakMap();
  function hookXhr() {
    if (hookXhr.done || typeof XMLHttpRequest !== "function") return;
    hookXhr.done = true;
    const proto = XMLHttpRequest.prototype;
    const open = proto.open;
    const send = proto.send;
    proto.open = function scutumadOpen(method, url, ...rest) {
      xhrState.set(this, { method: String(method).toUpperCase(), url: String(url) });
      return apply(open, this, [method, url, ...rest]);
    };
    proto.send = function scutumadSend(...args) {
      const state = xhrState.get(this);
      const blocked = state && xhrFilters.find((filter) => filter.block && filter.matches(state));
      if (!blocked) return apply(send, this, args);
      const xhr = this;
      defineProperty(xhr, "readyState", { value: 4, configurable: true });
      defineProperty(xhr, "status", { value: 200, configurable: true });
      defineProperty(xhr, "statusText", { value: "OK", configurable: true });
      defineProperty(xhr, "responseText", { value: blocked.body || "", configurable: true });
      defineProperty(xhr, "response", { value: blocked.body || "", configurable: true });
      setTimeout(() => {
        for (const type of ["readystatechange", "load", "loadend"]) xhr.dispatchEvent(new Event(type));
      }, 1);
      return undefined;
    };
    for (const name of ["response", "responseText"]) {
      const descriptor = getDescriptor(proto, name);
      if (!descriptor?.get) continue;
      defineProperty(proto, name, {
        ...descriptor,
        get() {
          const value = apply(descriptor.get, this, []);
          const state = xhrState.get(this);
          if (!state || this.readyState !== 4 || typeof value !== "string" && name === "responseText") return value;
          const editors = xhrFilters.filter((filter) => !filter.block && filter.matches(state));
          if (!editors.length) return value;
          if (state.cache && state.cache.source === value) return state.cache.result;
          let text = typeof value === "string" ? value : value && typeof value === "object" ? JSON.stringify(value) : value;
          if (typeof text !== "string") return value;
          for (const editor of editors) text = editor.edit(text);
          const result = typeof value === "string" ? text : JSON.parse(text);
          state.cache = { source: value, result };
          return result;
        }
      });
    }
  }

  function jsonEditor(prunePaths, neededPaths) {
    const prunePaths_ = pruner(prunePaths, neededPaths);
    return (text) => {
      try {
        const object = JSON.parse(text);
        prunePaths_(object);
        return JSON.stringify(object);
      } catch {
        return text;
      }
    };
  }

  function textEditor(pattern, replacement = "") {
    const target = regexOrText(pattern);
    if (target === null || target === "") return (text) => text;
    return (text) => (typeof target === "string" ? text.split(target).join(replacement) : text.replace(target, replacement));
  }

  function timerFilter(name, needle, delayArg, transform) {
    const test = matcher(needle);
    const delayTest = delayArg === undefined || delayArg === "" || delayArg === "*"
      ? () => true
      : (delay) => {
        const negate = delayArg.startsWith("!");
        const expected = Number(negate ? delayArg.slice(1) : delayArg);
        return (Number(delay) === expected) !== negate;
      };
    const native = window[name];
    window[name] = new Proxy(native, {
      apply(target, thisArg, args) {
        const [callback, delay] = args;
        if (test(String(callback)) && delayTest(delay)) {
          const next = transform(args);
          if (!next) return 0;
          return apply(target, thisArg, next);
        }
        return apply(target, thisArg, args);
      }
    });
  }

  function onDomReady(callback) {
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", callback, { once: true });
    else callback();
  }

  function domEditor(selector, edit, behavior = "") {
    const run = () => {
      try {
        document.querySelectorAll(selector).forEach(edit);
      } catch {}
    };
    if (behavior.includes("asap")) run();
    onDomReady(run);
    if (behavior.includes("stay") || behavior.includes("complete")) {
      const start = () => {
        run();
        if (behavior.includes("stay")) {
          new MutationObserver(run).observe(document.documentElement, { childList: true, subtree: true, attributes: true });
        }
      };
      if (behavior.includes("complete")) window.addEventListener("load", start, { once: true });
      else onDomReady(start);
    }
  }

  function storageItem(storageName, key, rawValue) {
    if (!key) return;
    let storage;
    try {
      storage = window[storageName];
    } catch {
      return;
    }
    if (rawValue === "$remove$") {
      try { storage.removeItem(key); } catch {}
      return;
    }
    const allowed = { undefined: "undefined", false: "false", true: "true", null: "null", "": "", emptyArr: "[]", emptyObj: "{}", yes: "yes", no: "no", on: "on", off: "off" };
    let value = allowed[rawValue];
    if (value === undefined && /^\d+$/.test(rawValue) && Number(rawValue) <= 0x7fff) value = rawValue;
    if (value === undefined) return;
    try { storage.setItem(key, value); } catch {}
  }

  function noAdBlockDetector() {
    class Detector {
      constructor() { this.callbacks = []; }
      setOption() { return this; }
      check() { this.callbacks.forEach((callback) => { try { callback(); } catch {} }); return true; }
      emitEvent() { return this; }
      clearEvent() {}
      on(detected, callback) { if (!detected) this.onNotDetected(callback); return this; }
      onDetected() { return this; }
      onNotDetected(callback) {
        if (typeof callback === "function") {
          this.callbacks.push(callback);
          setTimeout(() => { try { callback(); } catch {} }, 1);
        }
        return this;
      }
    }
    for (const name of ["FuckAdBlock", "BlockAdBlock", "SniffAdBlock"]) {
      try {
        defineProperty(window, name, { value: Detector, configurable: true, writable: true });
        defineProperty(window, name.charAt(0).toLowerCase() + name.slice(1), { value: new Detector(), configurable: true, writable: true });
      } catch {}
    }
  }

  const scriptlets = {
    "abort-on-property-read"(chain) {
      trapChain(window, chain, () => ({ get: abort, set() {} }));
    },
    "abort-on-property-write"(chain) {
      trapChain(window, chain, (current, owner) => ({ get: holder(current, owner).read, set: abort }));
    },
    "abort-current-script"(chain, needle, inlineOnly) {
      const test = matcher(needle);
      guardedChain(chain, () => {
        const script = document.currentScript;
        if (!(script instanceof HTMLScriptElement)) return false;
        if (script.src) return inlineOnly !== "inline" && test(script.src);
        return test(script.textContent || "");
      });
    },
    "abort-on-stack-trace"(chain, needle) {
      const test = matcher(needle);
      guardedChain(chain, () => test(new Error().stack || ""));
    },
    "set-constant"(chain, raw, ...extra) {
      const constant = constantValue(raw, extra);
      if (!constant.ok) return;
      trapChain(window, chain, () => ({ get: () => constant.value, set() {} }));
    },
    "no-setTimeout-if"(needle, delay) {
      timerFilter("setTimeout", needle, delay, () => null);
    },
    "no-setInterval-if"(needle, delay) {
      timerFilter("setInterval", needle, delay, () => null);
    },
    "nano-setTimeout-booster"(needle, delay = "1000", boost = "0.05") {
      const factor = Math.min(50, Math.max(0.001, Number(boost) || 0.05));
      timerFilter("setTimeout", needle, delay, ([callback, wait, ...rest]) => [callback, (Number(wait) || 0) * factor, ...rest]);
    },
    "nano-setInterval-booster"(needle, delay = "1000", boost = "0.05") {
      const factor = Math.min(50, Math.max(0.001, Number(boost) || 0.05));
      timerFilter("setInterval", needle, delay, ([callback, wait, ...rest]) => [callback, (Number(wait) || 0) * factor, ...rest]);
    },
    "addEventListener-defuser"(type, needle) {
      const typeTest = matcher(type);
      const test = matcher(needle);
      const native = EventTarget.prototype.addEventListener;
      EventTarget.prototype.addEventListener = new Proxy(native, {
        apply(target, thisArg, args) {
          const [eventType, handler] = args;
          if (typeTest(eventType) && test(String(handler))) return undefined;
          return apply(target, thisArg, args);
        }
      });
    },
    "window.open-defuser"(needle) {
      const test = matcher(needle);
      const decoy = () => ({ closed: false, close: noop, focus: noop, blur: noop, postMessage: noop,
        document: { write: noop, writeln: noop, close: noop, open: noop }, location: {} });
      window.open = new Proxy(window.open, {
        apply(target, thisArg, args) {
          if (test(String(args[0] ?? ""))) return decoy();
          return apply(target, thisArg, args);
        }
      });
    },
    "no-fetch-if"(needle, body) {
      fetchFilters.push({ block: true, matches: requestMatcher(needle), body: body === "emptyObj" ? "{}" : body === "emptyArr" ? "[]" : "" });
      hookFetch();
    },
    "no-xhr-if"(needle, body) {
      xhrFilters.push({ block: true, matches: requestMatcher(needle), body: body === "emptyObj" ? "{}" : body === "emptyArr" ? "[]" : "" });
      hookXhr();
    },
    "json-prune"(prunePaths, neededPaths) {
      const run = pruner(prunePaths, neededPaths);
      JSON.parse = new Proxy(JSON.parse, {
        apply: (target, thisArg, args) => run(apply(target, thisArg, args))
      });
      Response.prototype.json = new Proxy(Response.prototype.json, {
        apply: (target, thisArg, args) => apply(target, thisArg, args).then(run)
      });
    },
    "json-prune-fetch-response"(prunePaths, neededPaths, ...rest) {
      fetchFilters.push({ matches: requestMatcher(propsToMatch(rest)), edit: jsonEditor(prunePaths, neededPaths) });
      hookFetch();
    },
    "json-prune-xhr-response"(prunePaths, neededPaths, ...rest) {
      xhrFilters.push({ matches: requestMatcher(propsToMatch(rest)), edit: jsonEditor(prunePaths, neededPaths) });
      hookXhr();
    },
    "trusted-replace-fetch-response"(pattern, replacement, needle) {
      fetchFilters.push({ matches: requestMatcher(needle), edit: textEditor(pattern, replacement) });
      hookFetch();
    },
    "trusted-replace-xhr-response"(pattern, replacement, needle) {
      xhrFilters.push({ matches: requestMatcher(needle), edit: textEditor(pattern, replacement) });
      hookXhr();
    },
    "remove-attr"(attributes, selector, behavior) {
      const names = String(attributes || "").split("|").filter(Boolean);
      if (!names.length) return;
      domEditor(selector || names.map((name) => `[${CSS.escape(name)}]`).join(","),
        (element) => names.forEach((name) => element.removeAttribute(name)), behavior);
    },
    "remove-class"(classes, selector, behavior) {
      const names = String(classes || "").split("|").filter(Boolean);
      if (!names.length) return;
      domEditor(selector || names.map((name) => `.${CSS.escape(name)}`).join(","),
        (element) => element.classList.remove(...names), behavior);
    },
    "remove-cookie"(needle) {
      const test = matcher(needle);
      const remove = () => {
        document.cookie.split(";").forEach((cookie) => {
          const name = cookie.split("=")[0].trim();
          if (!name || !test(name)) return;
          const domains = ["", location.hostname, `.${location.hostname}`];
          for (const domain of domains) {
            document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/${domain ? `; domain=${domain}` : ""}`;
          }
        });
      };
      remove();
      window.addEventListener("beforeunload", remove);
    },
    "set-local-storage-item"(key, value) {
      storageItem("localStorage", key, value);
    },
    "set-session-storage-item"(key, value) {
      storageItem("sessionStorage", key, value);
    },
    "noeval-if"(needle) {
      const test = matcher(needle);
      window.eval = new Proxy(window.eval, {
        apply(target, thisArg, args) {
          if (test(String(args[0]))) return undefined;
          return apply(target, thisArg, args);
        }
      });
    },
    "nowebrtc"() {
      const stub = function RTCPeerConnection() {
        return { close: noop, createDataChannel: noop, createOffer: () => Promise.resolve({}),
          setLocalDescription: () => Promise.resolve(), addEventListener: noop, removeEventListener: noop };
      };
      for (const name of ["RTCPeerConnection", "webkitRTCPeerConnection", "mozRTCPeerConnection"]) {
        if (name in window) {
          try { defineProperty(window, name, { value: stub, configurable: true, writable: true }); } catch {}
        }
      }
    },
    "nobab": noAdBlockDetector
  };

  // Alias de uBlock Origin y Adblock Plus.
  const aliases = {
    aopr: "abort-on-property-read", aopw: "abort-on-property-write",
    acs: "abort-current-script", "abort-current-inline-script": "abort-current-script",
    aost: "abort-on-stack-trace", set: "set-constant", "override-property-read": "set-constant",
    nostif: "no-setTimeout-if", "prevent-setTimeout": "no-setTimeout-if",
    nosiif: "no-setInterval-if", "prevent-setInterval": "no-setInterval-if",
    "nano-stb": "nano-setTimeout-booster", "nano-sib": "nano-setInterval-booster",
    aeld: "addEventListener-defuser", "prevent-addEventListener": "addEventListener-defuser", "prevent-listener": "addEventListener-defuser",
    nowoif: "window.open-defuser", "no-window-open-if": "window.open-defuser", "prevent-window-open": "window.open-defuser",
    "prevent-fetch": "no-fetch-if", "prevent-xhr": "no-xhr-if",
    "trusted-rpfr": "trusted-replace-fetch-response", "replace-fetch-response": "trusted-replace-fetch-response",
    ra: "remove-attr", rc: "remove-class", "cookie-remover": "remove-cookie",
    noeval: "noeval-if", "silent-noeval": "noeval-if", nofab: "nobab", "bab-defuser": "nobab"
  };

  for (const [rawName, ...args] of rules) {
    const name = aliases[rawName] || rawName;
    try {
      scriptlets[name]?.(...args);
    } catch {
      // Un scriptlet fallido no debe impedir los demás.
    }
  }
})({"rules":{"5299.tv":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"8tracks.com":[["set","App.views.adsView.adblock","false"]],"aalah.me":[["aopw","adBlockDetected"]],"accuweather.com":[["set","Navigator.prototype.globalPrivacyControl","false"],["set","navigator.globalPrivacyControl","false"]],"aihumanizer.ai":[["set-local-storage-item","/__anon_id|browserId/","$remove$"]],"airsextube.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"akhbara24.news":[["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"]],"allafricangirls.net":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"ambonkita.com":[["aopw","adBlockDetected"]],"aniworld.to":[["abort-current-inline-script","JSON.parse","/atob|break/"]],"autofrage.net":[["set-local-storage-item","adshield-analytics-uuid","$remove$"],["set-local-storage-item","/_fa_bGFzdF9iZmFfYXQ=$/","$remove$"],["set-local-storage-item","/_fa_dXVpZA==$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWNjZXB0YWJsZV9hZHM=$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWRz$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfYWRibG9ja19jaXJjdW12ZW50X3Njb3Jl$/","$remove$"]],"avoiderrors.com":[["nostif","css_class.show"]],"babeporn.org":[["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"]],"beatvn.online":[["abort-current-inline-script","document.addEventListener","Redirect"]],"beaumontenterprise.com":[["cookie-remover","realm.cookiesAndJavascript"]],"betteranime.net":[["abort-current-inline-script","document.createElement","_mdttdpu"]],"betterbuttchallenge.com":[["acs","Date","='\\x"],["acs","document.head.appendChild","='\\x"],["aopr","__eiPb"]],"bezpolitickekorektnosti.cz":[["aopr","sc_adv_out"]],"big12sports.com":[["set","blockAdBlock","trueFunc"]],"bigten.org":[["set","blockAdBlock","trueFunc"]],"bollywoodshaadis.com":[["aopr","Debugger"],["aopw","adBlockDetected"]],"bradleybraves.com":[["set","blockAdBlock","trueFunc"]],"burlington-record.com":[["set-session-storage-item","nxt_is_incognito","false"]],"canaltdt.es":[["aeld","load","showModal"]],"cheline.com.ua":[["abort-current-inline-script","document.createElement","/ru-n4p|ua-n4p|загрузка.../"]],"clicknupload.co":[["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"],["abort-current-inline-script","String.fromCharCode","shift"]],"dadyflix.co":[["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"]],"dailybulletin.com":[["set","CnnXt.Event.fire","noopFunc"],["set-session-storage-item","nxt_is_incognito","false"]],"damconuong.win":[["abort-current-inline-script","WebAssembly","instantiate"]],"decompiler.com":[["set","OffscreenCanvas.prototype.getContext","undefined"],["aost","Image",".js"],["aost","Element.prototype.removeChild","/blocked|tick/"]],"dudestream2.com":[["abort-on-property-write","window.open"],["abort-current-inline-script","EventTarget.prototype.addEventListener","delete window"]],"elitegoltv.me":[["abort-on-property-read","smrtSB"],["abort-on-property-read","smrtSP"]],"enfieldindependent.co.uk":[["abort-current-inline-script","document.createElement","/data-sdk|last_bfa_at/"],["abort-on-property-read","__as_ready_resolve"]],"extreme-d0wn.net":[["abort-on-property-read","smrtSB"],["abort-on-property-read","smrtSP"]],"fastconverter.net":[["abort-on-property-read","afScript"]],"fautsy.com":[["nano-sib","seconds"]],"fedpress.ru":[["abort-current-inline-script","document.createElement","/ru-n4p|ua-n4p|загрузка.../"]],"femdomporntubes.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"festyy.com":[["set","globalThis","null"],["aopr","NREUM"]],"fgcuathletics.com":[["set","blockAdBlock","trueFunc"]],"fickenporno.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"fifisex.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"firstasianpussy.com":[["aopr","popit"],["aeld","popstate","noPop"]],"flyfrontier.com":[["set","Navigator.prototype.globalPrivacyControl","false"],["set","navigator.globalPrivacyControl","false"]],"freegamescasual.com":[["nostif","adblock_popup","500"]],"freetubegalore.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"french-streams.com":[["abort-on-property-read","open"]],"freshebonytubes.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"frprn.com":[["nosiif","readyState"],["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"funimg.net":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"funzen.net":[["nostif","mdpDeBlocker"],["nowoif"]],"fussball.news":[["aopr","adBlockDetected"]],"gamecocksonline.com":[["set","blockAdBlock","trueFunc"]],"gamefile.news":[["rc","has-intro-popup","html","stay"],["rc","modal-in","html","stay"],["rc","show-intro-popup","html","stay"]],"games.wkb.jp":[["set","gWkbAdVert","true"],["set","noblock","true"]],"gay-boys-xxx.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"generate.plus":[["nostif","checkStopBlock"]],"getfreesmsnumber.com":[["acs","document.getElementById","undefined"]],"godtube.com":[["aopr","googletag"]],"gometrostate.com":[["set","blockAdBlock","trueFunc"]],"gousfbulls.com":[["set","blockAdBlock","trueFunc"]],"grannypornpicture.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"greatnass.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"greeleytribune.com":[["set-session-storage-item","nxt_is_incognito","false"]],"gsm1x.xyz":[["aopw","downloadJSAtOnload"],["nano-stb","run"]],"gulf-up.com":[["aopr","AaDetector"]],"guyswithiphones.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"hagerty.com":[["set","MT","{}"],["set","MT.track","noopFunc"]],"hard-tubesex.com":[["aopr","Aloader.serve"],["noeval"]],"hdbraze.com":[["acs","Math.floor","hilltop"]],"hentaila.com":[["abort-current-inline-script","document.querySelectorAll","popMagic"]],"hentaiporno.xxx":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"hudebniskupiny.cz":[["prevent-listener","beforeunload","()"],["cookie-remover","/^_?adb/"]],"idealhentai.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"igetintopc.com":[["abort-on-property-read","window.open"]],"imgmaze.pw":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"imgur.com":[["set","Object.prototype.has_opted_out_tracking","trueFunc"]],"inkworldmagazine.com":[["acs","$","#pageWrapper"]],"inporn.com":[["abort-current-inline-script","mz"]],"iogames.space":[["set","ramp","undefined"]],"isohunt.lol":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","Math","zfgloaded"],["abort-on-property-write","_pop"],["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"]],"itmedia.co.jp":[["remove-cookie","/cX_P|_pc/"],["set-local-storage-item","/^_cX_/","$remove$"]],"japanesepornvideos.net":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"japanxxxworld.com":[["aopr","popit"],["aeld","popstate","noPop"]],"javideo.net":[["abort-current-inline-script","WebAssembly","atob"]],"javmix.tv":[["abort-current-inline-script","WebAssembly","atob"]],"jigsawexplorer.com":[["cookie-remover","/adblocker/","true"]],"kiiitv.com":[["replace-fetch-response","/^{\"[/][0-9]+[/][^]*/","","\"html\","],["acs","document.getElementsByTagName",".pubads"]],"kijolifehack.com":[["set-local-storage-item","adshield-analytics-uuid","$remove$"],["set-local-storage-item","/_fa_bGFzdF9iZmFfYXQ=$/","$remove$"],["set-local-storage-item","/_fa_dXVpZA==$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWNjZXB0YWJsZV9hZHM=$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWRz$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfYWRibG9ja19jaXJjdW12ZW50X3Njb3Jl$/","$remove$"]],"komikav.com":[["abort-current-inline-script","document.createElement","script"]],"kompoz2.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"kr.ua":[["abort-current-inline-script","document.createElement","/ru-n4p|ua-n4p|загрузка.../"]],"ktmx.pro":[["aeld","load","2000"]],"lebahmovie.com":[["aopr","decodeURI"]],"lesbianfantasyxxx.com":[["aopr","Aloader.serve"],["noeval"]],"lesoir.be":[["nostif","adb"]],"libertyvf.co":[["abort-current-inline-script","Math","zfgloaded"]],"limetorrents.lol":[["abort-current-inline-script","document.createElement","script"]],"livecricket.is":[["abort-current-inline-script","Math","zfgloaded"]],"liveforums.ru":[["abort-on-property-read","tnAdditionalParams"]],"m.viptube.com":[["aopw","mobilePop"]],"mamisamateur.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"manhwax.com":[["abort-on-property-read","localStorage"]],"masslive.com":[["aopr","_sp_._networkListenerData"],["acs","document.getElementsByTagName",".pubads"]],"matometemitatta.com":[["set-local-storage-item","adshield-analytics-uuid","$remove$"],["set-local-storage-item","/_fa_bGFzdF9iZmFfYXQ=$/","$remove$"],["set-local-storage-item","/_fa_dXVpZA==$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWNjZXB0YWJsZV9hZHM=$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWRz$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfYWRibG9ja19jaXJjdW12ZW50X3Njb3Jl$/","$remove$"]],"maturepornjungle.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"mazdausa.com":[["set","Navigator.prototype.globalPrivacyControl","false"],["set","navigator.globalPrivacyControl","false"]],"mediaindonesia.com":[["set-local-storage-item","adshield-analytics-uuid","$remove$"],["set-local-storage-item","/_fa_bGFzdF9iZmFfYXQ=$/","$remove$"],["set-local-storage-item","/_fa_dXVpZA==$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWNjZXB0YWJsZV9hZHM=$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWRz$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfYWRibG9ja19jaXJjdW12ZW50X3Njb3Jl$/","$remove$"]],"mentalfloss.com":[["override-property-read","Navigator.prototype.userAgent","AdsBot-Google"],["override-property-read","Navigator.prototype.userAgentData","undefined"],["set-local-storage-item","adshield-analytics-uuid","$remove$"],["set-local-storage-item","/_fa_bGFzdF9iZmFfYXQ=$/","$remove$"],["set-local-storage-item","/_fa_dXVpZA==$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWNjZXB0YWJsZV9hZHM=$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWRz$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfYWRibG9ja19jaXJjdW12ZW50X3Njb3Jl$/","$remove$"]],"milfjam.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"mistosumy.com":[["abort-current-inline-script","document.createElement","/ru-n4p|ua-n4p|загрузка.../"]],"moika78.ru":[["abort-on-property-read","td_ad_background_click_target"]],"money.com":[["rc","open-pw","body","stay"]],"moneyhouse.ch":[["nostif","bait"]],"morganhillwebcam.com":[["nostif","innerHTML"]],"mtlurb.com":[["nostif","purple_box"]],"musify.club":[["abort-current-inline-script","$","get_ya_browser"],["abort-on-property-read","get_ya_browser"]],"myfreemoms.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"netfapx.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"],["abort-current-inline-script","WebAssembly","atob"]],"newser.com":[["aeld","load","Object"],["prevent-listener","load","object"]],"nicematureporn.com":[["aopr","popit"],["aeld","popstate","noPop"]],"nmb48-mtm.com":[["set-local-storage-item","adshield-analytics-uuid","$remove$"],["set-local-storage-item","/_fa_bGFzdF9iZmFfYXQ=$/","$remove$"],["set-local-storage-item","/_fa_dXVpZA==$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWNjZXB0YWJsZV9hZHM=$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWRz$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfYWRibG9ja19jaXJjdW12ZW50X3Njb3Jl$/","$remove$"]],"npb-news.com":[["set-local-storage-item","adshield-analytics-uuid","$remove$"],["set-local-storage-item","/_fa_bGFzdF9iZmFfYXQ=$/","$remove$"],["set-local-storage-item","/_fa_dXVpZA==$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWNjZXB0YWJsZV9hZHM=$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWRz$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfYWRibG9ja19jaXJjdW12ZW50X3Njb3Jl$/","$remove$"]],"ntv.cx":[["abort-on-property-write","ZpQw9XkLmN8c3vR3"],["abort-current-inline-script","document.createElement","/\\.settings\\s*=\\s*\\w+\\s*\\|\\|/"]],"nudistbeach-pics.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"nylonglamourlegs.com":[["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"omavs.com":[["set","blockAdBlock","trueFunc"]],"ondemandkorea.com":[["set-local-storage-item","adshield-analytics-uuid","$remove$"],["set-local-storage-item","/_fa_bGFzdF9iZmFfYXQ=$/","$remove$"],["set-local-storage-item","/_fa_dXVpZA==$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWNjZXB0YWJsZV9hZHM=$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWRz$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfYWRibG9ja19jaXJjdW12ZW50X3Njb3Jl$/","$remove$"]],"onemanhua.com":[["aeld","/.?/","popMagic"],["nostif","checkSiteNormalLoad"]],"ooo-maturesex.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"openloadmov.net":[["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"]],"pcgamez-download.com":[["aost","Math","inlineScript"]],"peliculasio.com":[["abort-on-property-read","smrtSB"],["abort-on-property-read","smrtSP"]],"pewresearch.org":[["set","ga","noopFunc"]],"pezporn.com":[["acs","document.querySelectorAll","popMagic"],["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-on-property-read","decodeURI"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"picclick.ru":[["abort-current-inline-script","JSON.parse"]],"player.321movies.xyz":[["prevent-window-open","!abyss.to","1000"]],"plumpxxxtube.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"porncomics.me":[["aopr","open"],["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"pornditt.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"porngirlstube.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"pornhat.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-on-property-read","open"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"pornrox.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"porntry.com":[["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"pornvideohunter.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"porsche.com":[["set","Navigator.prototype.globalPrivacyControl","false"],["set","navigator.globalPrivacyControl","false"]],"pravda.com.ua":[["abort-on-property-read","as_retry"],["set-local-storage-item","adshield-analytics-uuid","$remove$"],["set-local-storage-item","/_fa_bGFzdF9iZmFfYXQ=$/","$remove$"],["set-local-storage-item","/_fa_dXVpZA==$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWNjZXB0YWJsZV9hZHM=$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWRz$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfYWRibG9ja19jaXJjdW12ZW50X3Njb3Jl$/","$remove$"]],"pro100hobbi.ru":[["abort-on-property-read","XMLHttpRequest"]],"read.perspectiveship.com":[["rc","has-intro-popup","html","stay"],["rc","modal-in","html","stay"],["rc","show-intro-popup","html","stay"]],"redsexhub.com":[["aopr","popit"],["aeld","popstate","noPop"]],"rexporn.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"romfordrecorder.co.uk":[["abort-current-inline-script","document.createElement","/data-sdk|last_bfa_at/"],["abort-on-property-read","__as_ready_resolve"]],"s1p1cd.com":[["abort-on-property-write","window.open"],["abort-current-inline-script","EventTarget.prototype.addEventListener","delete window"],["override-property-read","b4ec4795de7e51b370809da193ce1a7d","trueFunc"]],"sankaku.app":[["no-xhr-if","googlesyndication"]],"scandichotels.com":[["set","datalayer","[]"]],"scopateitaliane.it":[["aopr","document.dispatchEvent"]],"scrapywar.com":[["acs","eval","replace"]],"series9.fun":[["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"]],"seuseriado.com":[["abort-on-property-read","smrtSB"],["abort-on-property-read","smrtSP"]],"sexgay18.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"seznam.cz":[["cookie-remover","/adb$|adb\\.key|^[a-z]{5,11}/"],["cookie-remover","qusnyQusny"],["override-property-read","sssp","emptyObj"]],"shemalepower.xyz":[["nobab"],["nowoif"]],"shemalestreet.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"skidrowcodex.net":[["prevent-listener","DOMContentLoaded"]],"smarturl.it":[["set","linkfire.tracking","{}"]],"smsonline.cloud":[["no-fetch-if","-load.com/script/","length:101"],["nostif",")](this,...","3000-6000"],["nostif","(new Error(","3000-6000"],["set-local-storage-item","adshield-analytics-uuid","$remove$"],["set-local-storage-item","/_fa_bGFzdF9iZmFfYXQ=$/","$remove$"],["set-local-storage-item","/_fa_dXVpZA==$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWNjZXB0YWJsZV9hZHM=$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWRz$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfYWRibG9ja19jaXJjdW12ZW50X3Njb3Jl$/","$remove$"]],"socialmediagirls.com":[["abort-on-property-read","ExoVideoSlider.init"],["abort-on-property-read","localStorage"]],"softfully.com":[["no-fetch-if","ads"]],"sotemnovinhas.com":[["nofab"]],"spaste.com":[["nofab"]],"splinternews.com":[["set","ga","noopFunc"]],"sportsplays.com":[["nostif","abDetected"]],"stalkerbt.ru":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"stream.nbcsports.com":[["set","adBlockEnabled","false"]],"streamporn.cc":[["acs","decodeURI","decodeURIComponent"],["aopr","exoJsPop101"],["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"sumaburayasan.com":[["set-local-storage-item","adshield-analytics-uuid","$remove$"],["set-local-storage-item","/_fa_bGFzdF9iZmFfYXQ=$/","$remove$"],["set-local-storage-item","/_fa_dXVpZA==$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWNjZXB0YWJsZV9hZHM=$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWRz$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfYWRibG9ja19jaXJjdW12ZW50X3Njb3Jl$/","$remove$"]],"supforums.com":[["set","adsBlocked","false"],["aopr","htaUrl"]],"svadba.expert":[["abort-on-property-read","XMLHttpRequest"]],"sweettwinks.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"techacrobat.com":[["aopw","adBlockDetected"]],"teenskitten.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"telemagazyn.pl":[["aeld","","show"]],"theavtimes.com":[["acs","Date","='\\x"],["acs","document.head.appendChild","='\\x"],["aopr","__eiPb"],["abort-on-property-read","g00gletag"],["abort-on-property-read","advads_passive_ads"]],"thotchicks.com":[["abort-current-inline-script","WebAssembly","atob"],["abort-current-inline-script","document.createElement","/l\\.parentNode\\.insertBefore\\(s/"]],"thuglink.com":[["set","adblockEnabled","false"]],"tojav.net":[["abort-current-inline-script","WebAssembly","atob"]],"tranny6.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"trendsderzukunft.de":[["aopr","onload"]],"ts-mpegs.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"tvporinternet2.com":[["abort-on-property-write","window.open"],["abort-on-property-read","aclib.runPop"]],"twatis.com":[["aopr","ExoLoader.addZone"],["aopr","document.dispatchEvent"],["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"ucirvinesports.com":[["set","blockAdBlock","trueFunc"]],"ultra-sexe.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"unblockit.boo":[["abort-current-inline-script","s2ss45"]],"unlvrebels.com":[["set","blockAdBlock","trueFunc"]],"utrockets.com":[["set","blockAdBlock","trueFunc"]],"vectorizer.io":[["nostif","modal"]],"vidaextra.com":[["set","hasAdblocker","true"]],"videosputas.xxx":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"vidnext.net":[["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"]],"vipbox.biz":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"vndoc.com":[["override-property-read","seconds","0"]],"voyeurblog.net":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"vsd.fr":[["nostif","checkPub","6000"]],"watcho.com":[["nano-stb","isPeriodic","*"]],"weatherzone.com":[["override-property-read","Navigator.prototype.userAgent","AdsBot-Google"],["override-property-read","Navigator.prototype.userAgentData","undefined"]],"webmail.wiki":[["acs","document.createElement","admiral"]],"webworm.co":[["rc","has-intro-popup","html","stay"],["rc","modal-in","html","stay"],["rc","show-intro-popup","html","stay"]],"wetpussy.sexy":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"windsorstar.com":[["set","Object.prototype.adService.initialize","noopFunc"],["acs","document.getElementsByTagName",".pubads"]],"wkusports.com":[["set","blockAdBlock","trueFunc"]],"word-grabber.com":[["set-local-storage-item","adshield-analytics-uuid","$remove$"],["set-local-storage-item","/_fa_bGFzdF9iZmFfYXQ=$/","$remove$"],["set-local-storage-item","/_fa_dXVpZA==$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWNjZXB0YWJsZV9hZHM=$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWRz$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfYWRibG9ja19jaXJjdW12ZW50X3Njb3Jl$/","$remove$"]],"wowescape.com":[["no-fetch-if","adsbygoogle"]],"xhamster-art.com":[["aopr","popit"],["aeld","popstate","noPop"]],"xmegadrive.com":[["abort-current-inline-script","document.createElement","/l\\.parentNode\\.insertBefore\\(s/"]],"xnxxvideoporn.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"xwhite-tube.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"xxx-hd-tube.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"xxxhothub.com":[["aopr","popit"],["aeld","popstate","noPop"]],"yesjavplease.fun":[["abort-current-inline-script","document.createElement","/l\\.parentNode\\.insertBefore\\(s/"]],"yourlocalguardian.co.uk":[["abort-current-inline-script","document.createElement","/data-sdk|last_bfa_at/"],["abort-on-property-read","__as_ready_resolve"]],"yumacs.com":[["set","blockAdBlock","trueFunc"]]},"exceptions":{"3igames.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"abczdrowie.pl":["aost\u0000WP.prebid\u0000onLoad"],"account.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"auto.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"away.vk.com":["abort-on-property-read\u0000vk__adsLight.adsShowed"],"away.vk.ru":["abort-on-property-read\u0000vk__adsLight.adsShowed"],"biz.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"blog.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"bonus.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"calendar.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"calls.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"cloud.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"connect.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"deti.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"dev.fingerprint.com":["no-xhr-if\u0000method:POST"],"dobro.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"docs.fingerprint.com":["no-xhr-if\u0000method:POST"],"dziennikbaltycki.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"dzienniklodzki.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"dziennikpolski24.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"dziennikzachodni.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"e.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"echodnia.eu":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"expressbydgoski.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"expressilustrowany.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"finance.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"gazetakrakowska.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"gazetalubuska.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"gazetawroclawska.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"gibdd.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"gk24.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"gloswielkopolski.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"gol24.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"gp24.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"gra.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"gs24.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"health.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"help.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"hi-tech.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"horo.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"job.mt.de":["nostif\u0000.call(null)\u000010"],"job.nw.de":["nostif\u0000.call(null)\u000010"],"kino.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"kurierlubelski.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"lady.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"love.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"mcs.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"minigames.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"mmminigames.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"motofakty.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"my.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"naszemiasto.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"new.fastpic.org":["abort-current-inline-script\u0000document.getElementById\u0000maybeShow","abort-on-property-read\u0000Date.prototype.toUTCString","abort-on-property-read\u0000Element.prototype.attachShadow","abort-on-property-write\u0000__BIM__"],"news.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"notes.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"nowiny24.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"nowosci.com.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"nto.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"o2.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"octavius.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"okminigames.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"otvet.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"pcgames.de":["set\u0000CustomEvent\u0000noopFunc"],"pets.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"pingit.com":["aopr\u0000AaDetector","aopr\u0000_pop","aopr\u0000open","aopr\u0000rmVideoPlay","aopw\u0000Fingerprint2","set\u0000blurred\u0000false"],"plans.rainbowplantlife.com":["abort-on-property-read\u0000Intl.DateTimeFormat\u0000false","abort-on-property-read\u0000as_1058949371\u0000true","await\u0000new ","json-override\u0000isUnregistered\u0000true\u0000isUnregistered","override-property-read\u0000Navigator.prototype.onLine\u0000false","override-property-read\u0000as_-1217724578\u0000true","override-property-read\u0000as_-1269284192\u0000true","override-property-read\u0000as_-1349200120\u0000true","override-property-read\u0000as_-1499012015\u0000true","override-property-read\u0000as_-1858225736\u0000true","override-property-read\u0000as_-690327166\u0000true","override-property-read\u0000as_-930335972\u0000true","override-property-read\u0000as_-977715772\u0000true","override-property-read\u0000as_-989986399\u0000true","override-property-read\u0000as_1026413243\u0000true","override-property-read\u0000as_1098238358\u0000true","override-property-read\u0000as_1327966181\u0000true","override-property-read\u0000as_348516803\u0000true","override-property-read\u0000as_447456217\u0000true","override-property-read\u0000as_687465023\u0000true","override-property-read\u0000as_720001151\u0000true","override-property-read\u0000as_739024637\u0000true","override-property-read\u0000as_759290138\u0000true","override-property-read\u0000as_818940565\u0000true","override-property-read\u0000as_989017961\u0000true","replace-argument\u0000Element.prototype.setAttribute\u00001\u0000","replace-xhr-response\u0000/[\\s\\S]*/\u0000\u0000/pub_300x250/"],"player-smotri.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"poczta.wp.pl":["hide-if-matches-xpath\u0000.//div[@class and @* and not (@id)]//a[@class and @* and not (@id)][string-length(@href)>1000]//div[@class]//img[@class and @* and not (@id)][string-length(@src)>100]/ancestor::div[@class and @* and not(@id)][3]","hide-if-matches-xpath\u0000//a[string-length(@href)>1000]/img[@class and @*[not(name() = \"class\")]][string-length(@src)>125]","hide-if-matches-xpath\u0000//a[string-length(@href)>1000]/img[@src]/ancestor::div[.//span[normalize-space(text())=\"REKLAMA\"]][1][string-length(normalize-space()) < 100]","hide-if-matches-xpath\u0000//div[@class and @*[not(@class)]=\"\"]/div[not(*) and not(normalize-space())][@class and @*[not(@class)]=\"\"]/ancestor::div[@class and @*[not(@class)]=\"\"][contains(@class,\" \")][contains(@*[not(@class)],\" \")][string-length(@*[not(@class)]) > 25][not(starts-with(@class,\"app-container\") or starts-with(@class,\"sticky-wrapper\"))]","hide-if-matches-xpath\u0000//ul[@class]/li[string-length(@class)<=25][contains(normalize-space(), \" \")]/img[string-length(@src) >140]/following-sibling::span/a[string-length(@href) > 2000]/ancestor::li"],"pogoda.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"polskatimes.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"pomorska.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"poranny.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"sportowefakty.wp.pl":["hide-if-matches-xpath\u0000//a[string-length(@href)>1000]/img[@src]/ancestor::div[.//span[normalize-space(text())=\"REKLAMA\"]][1][string-length(normalize-space()) < 100]","hide-if-matches-xpath\u0000//div[@class and @*[not(@class)]=\"\"]/div[not(*) and not(normalize-space())][@class and @*[not(@class)]=\"\"]/ancestor::div[@class and @*[not(@class)]=\"\"][contains(@class,\" \")][contains(@*[not(@class)],\" \")][string-length(@*[not(@class)]) > 25][not(starts-with(@class,\"app-container\") or starts-with(@class,\"sticky-wrapper\"))]"],"sportowy24.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"strefaagro.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"strefabiznesu.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"stronakobiet.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"t-online.de":["set\u0000CustomEvent\u0000noopFunc"],"telemagazyn.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"to.com.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"todo.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"top.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"touch.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"tv.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"uii.io":["noeval"],"uqload.co":["abort-current-script\u0000document.createElement\u0000break;case $."],"vfokuse.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"vr.pornhat.*":["aopr\u0000document.dispatchEvent"],"widgets.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"wspolczesna.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"www.hoyolab.com":["trusted-set-cookie\u0000DEVICEFP\u000000000000000\u0000\u0000\u0000domain\u0000.hoyolab.com","trusted-set-cookie\u0000DEVICEFP_SEED_ID\u0000\u00000\u0000\u0000domain\u0000.hoyolab.com","trusted-set-cookie\u0000DEVICEFP_SEED_TIME\u0000\u00000\u0000\u0000domain\u0000.hoyolab.com"],"www.hoyoverse.com":["trusted-set-cookie\u0000DEVICEFP\u000000000000000\u0000\u0000\u0000domain\u0000.hoyoverse.com","trusted-set-cookie\u0000DEVICEFP_SEED_ID\u0000\u00000\u0000\u0000domain\u0000.hoyoverse.com","trusted-set-cookie\u0000DEVICEFP_SEED_TIME\u0000\u00000\u0000\u0000domain\u0000.hoyoverse.com"],"yandex.*":["aopr\u0000Object.prototype.renderDirect):matches-path(/\\/(?:weather\\/|pogoda\\/|hava\\/)/"]}});
