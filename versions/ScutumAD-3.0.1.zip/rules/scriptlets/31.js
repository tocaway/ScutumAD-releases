// Generado por scripts/build-rules.mjs a partir de src/scriptlets/engine.js.
// Motor de scriptlets de ScutumAD (implementación propia, compatible con los
// nombres de uBlock Origin y Adblock Plus). Se ejecuta en el mundo MAIN antes
// que la página. RULES_PLACEHOLDER se sustituye por { rules, exceptions }:
// en la publicación (rules/scriptlets.js) o al actualizar las listas.
(function scutumadScriptlets(data) {
  "use strict";
  const hostname = location.hostname.toLowerCase().replace(/\.$/, "");
  if (!hostname) return;
  // Segunda defensa: nunca scriptlets de las listas en YouTube (detecta que
  // se reescriben sus respuestas y bloquea el vídeo).
  if (/(?:^|\.)youtube(?:-nocookie|kids)?\.com$/.test(hostname)) return;

  // Claves que aplican a este host: el dominio y sus padres, y las
  // entidades (ejemplo.*) cuando quedan como mucho dos etiquetas de TLD.
  const labels = hostname.split(".");
  const keys = [];
  for (let start = 0; start < labels.length; start++) {
    keys.push(labels.slice(start).join("."));
    for (let end = Math.max(start + 1, labels.length - 2); end < labels.length; end++) {
      keys.push(`${labels.slice(start, end).join(".")}.*`);
    }
  }
  const exceptions = new Set(keys.flatMap((key) => data.exceptions[key] || []));
  if (exceptions.has("*")) return;
  const seen = new Set();
  const rules = keys.flatMap((key) => data.rules[key] || []).filter((rule) => {
    const signature = rule.join("\u0000");
    if (seen.has(signature) || exceptions.has(signature)) return false;
    seen.add(signature);
    return true;
  });
  if (!rules.length) return;

  const MARKER = `scutumad-${Math.random().toString(36).slice(2)}`;
  const defineProperty = Object.defineProperty;
  const getDescriptor = Object.getOwnPropertyDescriptor;
  const apply = Reflect.apply;

  window.addEventListener("error", (event) => {
    if (typeof event.message === "string" && event.message.includes(MARKER)) event.preventDefault();
  }, true);
  const abort = () => {
    throw new ReferenceError(MARKER);
  };

  // Aguja: texto o /regex/flags; "!" delante invierte; vacía casa con todo.
  function matcher(needle = "") {
    let negate = false;
    let text = String(needle);
    if (text.startsWith("!")) {
      negate = true;
      text = text.slice(1);
    }
    if (!text) return () => !negate;
    const regex = /^\/(.+)\/([gimsu]*)$/.exec(text);
    let test;
    if (regex) {
      try {
        const pattern = new RegExp(regex[1], regex[2].replace("g", ""));
        test = (value) => pattern.test(value);
      } catch {
        return () => false;
      }
    } else {
      test = (value) => value.includes(text);
    }
    return (value) => test(String(value)) !== negate;
  }

  function regexOrText(value) {
    const regex = /^\/(.+)\/([gimsu]*)$/.exec(value);
    if (regex) {
      try {
        return new RegExp(regex[1], regex[2]);
      } catch {
        return null;
      }
    }
    return value;
  }

  const noop = () => {};
  function constantValue(raw, extra = []) {
    const factories = {
      undefined: () => undefined, false: () => false, true: () => true, null: () => null,
      "": () => "", emptyStr: () => "",
      noopFunc: () => noop, trueFunc: () => () => true, falseFunc: () => () => false,
      throwFunc: () => () => { throw new Error(); }, noopCallbackFunc: () => () => noop,
      emptyArray: () => [], "[]": () => [], emptyObj: () => ({}), "{}": () => ({}),
      yes: () => "yes", no: () => "no", on: () => "on", off: () => "off"
    };
    let value;
    if (Object.prototype.hasOwnProperty.call(factories, raw)) {
      value = factories[raw]();
    } else if (/^-?\d+(?:\.\d+)?$/.test(raw) && Math.abs(Number(raw)) <= 0x7fff) {
      value = Number(raw);
    } else {
      return { ok: false };
    }
    if (extra.includes("asFunction")) {
      const inner = value;
      value = () => inner;
    } else if (extra.includes("asCallback")) {
      const inner = value;
      value = () => () => inner;
    } else if (extra.includes("asResolved")) {
      value = Promise.resolve(value);
    } else if (extra.includes("asRejected")) {
      value = Promise.reject(value);
    }
    return { ok: true, value };
  }

  // Getter/setter en el último eslabón de `chain` (a.b.c). Si un eslabón aún
  // no existe, espera a que la página lo cree.
  function trapChain(owner, chain, makeDescriptor) {
    const dot = chain.indexOf(".");
    const name = dot < 0 ? chain : chain.slice(0, dot);
    const rest = dot < 0 ? "" : chain.slice(dot + 1);
    if (!rest) {
      const current = getDescriptor(owner, name);
      if (current && current.configurable === false) return;
      try {
        defineProperty(owner, name, { configurable: true, ...makeDescriptor(current, owner) });
      } catch {
        // Propiedad protegida.
      }
      return;
    }
    const next = owner[name];
    if (next && (typeof next === "object" || typeof next === "function")) {
      trapChain(next, rest, makeDescriptor);
      return;
    }
    let value = next;
    try {
      defineProperty(owner, name, {
        configurable: true,
        get: () => value,
        set(newValue) {
          value = newValue;
          if (newValue && (typeof newValue === "object" || typeof newValue === "function")) {
            trapChain(newValue, rest, makeDescriptor);
          }
        }
      });
    } catch {
      // Propiedad protegida.
    }
  }

  function holder(current, owner) {
    let value = current && "value" in current ? current.value : undefined;
    return {
      read: () => (current?.get ? apply(current.get, owner, []) : value),
      write: (newValue) => (current?.set ? apply(current.set, owner, [newValue]) : (value = newValue))
    };
  }

  function guardedChain(chain, shouldAbort) {
    trapChain(window, chain, (current, owner) => {
      const store = holder(current, owner);
      return {
        get() {
          if (shouldAbort()) abort();
          return store.read();
        },
        set(newValue) {
          if (shouldAbort()) abort();
          store.write(newValue);
        }
      };
    });
  }

  // Rutas de json-prune: a.b, [] (cada elemento) y [-] (quita el elemento
  // del array si contiene el resto de la ruta).
  function prune(object, parts) {
    if (!object || typeof object !== "object") return false;
    const [part, ...rest] = parts;
    if (part === "[]") {
      if (!Array.isArray(object)) return false;
      let changed = false;
      object.forEach((item) => { changed = prune(item, rest) || changed; });
      return changed;
    }
    if (part === "[-]") {
      if (!Array.isArray(object)) return false;
      let changed = false;
      for (let index = object.length - 1; index >= 0; index--) {
        if (hasPath(object[index], rest)) {
          object.splice(index, 1);
          changed = true;
        }
      }
      return changed;
    }
    if (!rest.length) {
      if (!(part in object)) return false;
      delete object[part];
      return true;
    }
    return prune(object[part], rest);
  }

  function hasPath(object, parts) {
    let current = object;
    for (const part of parts) {
      if (part === "[]" || part === "[-]") {
        return Array.isArray(current) && current.some((item) => hasPath(item, parts.slice(parts.indexOf(part) + 1)));
      }
      if (!current || typeof current !== "object" || !(part in current)) return false;
      current = current[part];
    }
    return true;
  }

  function pruner(prunePaths = "", neededPaths = "") {
    const toPrune = prunePaths.split(/\s+/).filter(Boolean).map((path) => path.split("."));
    const needed = neededPaths.split(/\s+/).filter(Boolean).map((path) => path.split("."));
    return (value) => {
      if (value && typeof value === "object" && needed.every((path) => hasPath(value, path))) {
        toPrune.forEach((path) => prune(value, path));
      }
      return value;
    };
  }

  // Argumentos "propsToMatch, valor" al final de algunos scriptlets.
  function propsToMatch(args) {
    const index = args.indexOf("propsToMatch");
    return index >= 0 ? args[index + 1] || "" : "";
  }

  // "url:x method:POST" o simplemente "x" (que se compara con la URL).
  function requestMatcher(needle = "") {
    if (!needle || needle === "*") return () => true;
    const tests = needle.split(/\s+/).filter(Boolean).map((part) => {
      const colon = part.indexOf(":");
      const known = colon > 0 && ["url", "method", "body", "headers", "mode", "credentials"].includes(part.slice(0, colon));
      const key = known ? part.slice(0, colon) : "url";
      return [key, matcher(known ? part.slice(colon + 1) : part)];
    });
    return (details) => tests.every(([key, test]) => test(details[key] ?? ""));
  }

  function fetchDetails(args) {
    const [resource, init = {}] = args;
    const isRequest = typeof Request === "function" && resource instanceof Request;
    return {
      url: String(isRequest ? resource.url : resource),
      method: String(init.method || (isRequest ? resource.method : "GET")).toUpperCase(),
      body: typeof init.body === "string" ? init.body : ""
    };
  }

  function rebuildResponse(original, text) {
    const response = new Response(text, {
      status: original.status, statusText: original.statusText, headers: original.headers
    });
    try {
      defineProperty(response, "url", { value: original.url });
      defineProperty(response, "redirected", { value: original.redirected });
      defineProperty(response, "type", { value: original.type });
    } catch {}
    return response;
  }

  const fetchFilters = [];
  function hookFetch() {
    if (hookFetch.done || typeof fetch !== "function") return;
    hookFetch.done = true;
    window.fetch = new Proxy(window.fetch, {
      apply(target, thisArg, args) {
        const details = fetchDetails(args);
        for (const filter of fetchFilters) {
          if (filter.block && filter.matches(details)) {
            return Promise.resolve(new Response(filter.body || "", { status: 200, statusText: "OK" }));
          }
        }
        const editors = fetchFilters.filter((filter) => !filter.block && filter.matches(details));
        const result = apply(target, thisArg, args);
        if (!editors.length) return result;
        return result.then((response) => response.clone().text().then((text) => {
          let edited = text;
          for (const editor of editors) edited = editor.edit(edited);
          return edited === text ? response : rebuildResponse(response, edited);
        }).catch(() => response));
      }
    });
  }

  const xhrFilters = [];
  const xhrState = new WeakMap();
  function hookXhr() {
    if (hookXhr.done || typeof XMLHttpRequest !== "function") return;
    hookXhr.done = true;
    const proto = XMLHttpRequest.prototype;
    const open = proto.open;
    const send = proto.send;
    proto.open = function scutumadOpen(method, url, ...rest) {
      xhrState.set(this, { method: String(method).toUpperCase(), url: String(url) });
      return apply(open, this, [method, url, ...rest]);
    };
    proto.send = function scutumadSend(...args) {
      const state = xhrState.get(this);
      const blocked = state && xhrFilters.find((filter) => filter.block && filter.matches(state));
      if (!blocked) return apply(send, this, args);
      const xhr = this;
      defineProperty(xhr, "readyState", { value: 4, configurable: true });
      defineProperty(xhr, "status", { value: 200, configurable: true });
      defineProperty(xhr, "statusText", { value: "OK", configurable: true });
      defineProperty(xhr, "responseText", { value: blocked.body || "", configurable: true });
      defineProperty(xhr, "response", { value: blocked.body || "", configurable: true });
      setTimeout(() => {
        for (const type of ["readystatechange", "load", "loadend"]) xhr.dispatchEvent(new Event(type));
      }, 1);
      return undefined;
    };
    for (const name of ["response", "responseText"]) {
      const descriptor = getDescriptor(proto, name);
      if (!descriptor?.get) continue;
      defineProperty(proto, name, {
        ...descriptor,
        get() {
          const value = apply(descriptor.get, this, []);
          const state = xhrState.get(this);
          if (!state || this.readyState !== 4 || typeof value !== "string" && name === "responseText") return value;
          const editors = xhrFilters.filter((filter) => !filter.block && filter.matches(state));
          if (!editors.length) return value;
          if (state.cache && state.cache.source === value) return state.cache.result;
          let text = typeof value === "string" ? value : value && typeof value === "object" ? JSON.stringify(value) : value;
          if (typeof text !== "string") return value;
          for (const editor of editors) text = editor.edit(text);
          const result = typeof value === "string" ? text : JSON.parse(text);
          state.cache = { source: value, result };
          return result;
        }
      });
    }
  }

  function jsonEditor(prunePaths, neededPaths) {
    const prunePaths_ = pruner(prunePaths, neededPaths);
    return (text) => {
      try {
        const object = JSON.parse(text);
        prunePaths_(object);
        return JSON.stringify(object);
      } catch {
        return text;
      }
    };
  }

  function textEditor(pattern, replacement = "") {
    const target = regexOrText(pattern);
    if (target === null || target === "") return (text) => text;
    return (text) => (typeof target === "string" ? text.split(target).join(replacement) : text.replace(target, replacement));
  }

  function timerFilter(name, needle, delayArg, transform) {
    const test = matcher(needle);
    const delayTest = delayArg === undefined || delayArg === "" || delayArg === "*"
      ? () => true
      : (delay) => {
        const negate = delayArg.startsWith("!");
        const expected = Number(negate ? delayArg.slice(1) : delayArg);
        return (Number(delay) === expected) !== negate;
      };
    const native = window[name];
    window[name] = new Proxy(native, {
      apply(target, thisArg, args) {
        const [callback, delay] = args;
        if (test(String(callback)) && delayTest(delay)) {
          const next = transform(args);
          if (!next) return 0;
          return apply(target, thisArg, next);
        }
        return apply(target, thisArg, args);
      }
    });
  }

  function onDomReady(callback) {
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", callback, { once: true });
    else callback();
  }

  function domEditor(selector, edit, behavior = "") {
    const run = () => {
      try {
        document.querySelectorAll(selector).forEach(edit);
      } catch {}
    };
    if (behavior.includes("asap")) run();
    onDomReady(run);
    if (behavior.includes("stay") || behavior.includes("complete")) {
      const start = () => {
        run();
        if (behavior.includes("stay")) {
          new MutationObserver(run).observe(document.documentElement, { childList: true, subtree: true, attributes: true });
        }
      };
      if (behavior.includes("complete")) window.addEventListener("load", start, { once: true });
      else onDomReady(start);
    }
  }

  function storageItem(storageName, key, rawValue) {
    if (!key) return;
    let storage;
    try {
      storage = window[storageName];
    } catch {
      return;
    }
    if (rawValue === "$remove$") {
      try { storage.removeItem(key); } catch {}
      return;
    }
    const allowed = { undefined: "undefined", false: "false", true: "true", null: "null", "": "", emptyArr: "[]", emptyObj: "{}", yes: "yes", no: "no", on: "on", off: "off" };
    let value = allowed[rawValue];
    if (value === undefined && /^\d+$/.test(rawValue) && Number(rawValue) <= 0x7fff) value = rawValue;
    if (value === undefined) return;
    try { storage.setItem(key, value); } catch {}
  }

  function noAdBlockDetector() {
    class Detector {
      constructor() { this.callbacks = []; }
      setOption() { return this; }
      check() { this.callbacks.forEach((callback) => { try { callback(); } catch {} }); return true; }
      emitEvent() { return this; }
      clearEvent() {}
      on(detected, callback) { if (!detected) this.onNotDetected(callback); return this; }
      onDetected() { return this; }
      onNotDetected(callback) {
        if (typeof callback === "function") {
          this.callbacks.push(callback);
          setTimeout(() => { try { callback(); } catch {} }, 1);
        }
        return this;
      }
    }
    for (const name of ["FuckAdBlock", "BlockAdBlock", "SniffAdBlock"]) {
      try {
        defineProperty(window, name, { value: Detector, configurable: true, writable: true });
        defineProperty(window, name.charAt(0).toLowerCase() + name.slice(1), { value: new Detector(), configurable: true, writable: true });
      } catch {}
    }
  }

  const scriptlets = {
    "abort-on-property-read"(chain) {
      trapChain(window, chain, () => ({ get: abort, set() {} }));
    },
    "abort-on-property-write"(chain) {
      trapChain(window, chain, (current, owner) => ({ get: holder(current, owner).read, set: abort }));
    },
    "abort-current-script"(chain, needle, inlineOnly) {
      const test = matcher(needle);
      guardedChain(chain, () => {
        const script = document.currentScript;
        if (!(script instanceof HTMLScriptElement)) return false;
        if (script.src) return inlineOnly !== "inline" && test(script.src);
        return test(script.textContent || "");
      });
    },
    "abort-on-stack-trace"(chain, needle) {
      const test = matcher(needle);
      guardedChain(chain, () => test(new Error().stack || ""));
    },
    "set-constant"(chain, raw, ...extra) {
      const constant = constantValue(raw, extra);
      if (!constant.ok) return;
      trapChain(window, chain, () => ({ get: () => constant.value, set() {} }));
    },
    "no-setTimeout-if"(needle, delay) {
      timerFilter("setTimeout", needle, delay, () => null);
    },
    "no-setInterval-if"(needle, delay) {
      timerFilter("setInterval", needle, delay, () => null);
    },
    "nano-setTimeout-booster"(needle, delay = "1000", boost = "0.05") {
      const factor = Math.min(50, Math.max(0.001, Number(boost) || 0.05));
      timerFilter("setTimeout", needle, delay, ([callback, wait, ...rest]) => [callback, (Number(wait) || 0) * factor, ...rest]);
    },
    "nano-setInterval-booster"(needle, delay = "1000", boost = "0.05") {
      const factor = Math.min(50, Math.max(0.001, Number(boost) || 0.05));
      timerFilter("setInterval", needle, delay, ([callback, wait, ...rest]) => [callback, (Number(wait) || 0) * factor, ...rest]);
    },
    "addEventListener-defuser"(type, needle) {
      const typeTest = matcher(type);
      const test = matcher(needle);
      const native = EventTarget.prototype.addEventListener;
      EventTarget.prototype.addEventListener = new Proxy(native, {
        apply(target, thisArg, args) {
          const [eventType, handler] = args;
          if (typeTest(eventType) && test(String(handler))) return undefined;
          return apply(target, thisArg, args);
        }
      });
    },
    "window.open-defuser"(needle) {
      const test = matcher(needle);
      const decoy = () => ({ closed: false, close: noop, focus: noop, blur: noop, postMessage: noop,
        document: { write: noop, writeln: noop, close: noop, open: noop }, location: {} });
      window.open = new Proxy(window.open, {
        apply(target, thisArg, args) {
          if (test(String(args[0] ?? ""))) return decoy();
          return apply(target, thisArg, args);
        }
      });
    },
    "no-fetch-if"(needle, body) {
      fetchFilters.push({ block: true, matches: requestMatcher(needle), body: body === "emptyObj" ? "{}" : body === "emptyArr" ? "[]" : "" });
      hookFetch();
    },
    "no-xhr-if"(needle, body) {
      xhrFilters.push({ block: true, matches: requestMatcher(needle), body: body === "emptyObj" ? "{}" : body === "emptyArr" ? "[]" : "" });
      hookXhr();
    },
    "json-prune"(prunePaths, neededPaths) {
      const run = pruner(prunePaths, neededPaths);
      JSON.parse = new Proxy(JSON.parse, {
        apply: (target, thisArg, args) => run(apply(target, thisArg, args))
      });
      Response.prototype.json = new Proxy(Response.prototype.json, {
        apply: (target, thisArg, args) => apply(target, thisArg, args).then(run)
      });
    },
    "json-prune-fetch-response"(prunePaths, neededPaths, ...rest) {
      fetchFilters.push({ matches: requestMatcher(propsToMatch(rest)), edit: jsonEditor(prunePaths, neededPaths) });
      hookFetch();
    },
    "json-prune-xhr-response"(prunePaths, neededPaths, ...rest) {
      xhrFilters.push({ matches: requestMatcher(propsToMatch(rest)), edit: jsonEditor(prunePaths, neededPaths) });
      hookXhr();
    },
    "trusted-replace-fetch-response"(pattern, replacement, needle) {
      fetchFilters.push({ matches: requestMatcher(needle), edit: textEditor(pattern, replacement) });
      hookFetch();
    },
    "trusted-replace-xhr-response"(pattern, replacement, needle) {
      xhrFilters.push({ matches: requestMatcher(needle), edit: textEditor(pattern, replacement) });
      hookXhr();
    },
    "remove-attr"(attributes, selector, behavior) {
      const names = String(attributes || "").split("|").filter(Boolean);
      if (!names.length) return;
      domEditor(selector || names.map((name) => `[${CSS.escape(name)}]`).join(","),
        (element) => names.forEach((name) => element.removeAttribute(name)), behavior);
    },
    "remove-class"(classes, selector, behavior) {
      const names = String(classes || "").split("|").filter(Boolean);
      if (!names.length) return;
      domEditor(selector || names.map((name) => `.${CSS.escape(name)}`).join(","),
        (element) => element.classList.remove(...names), behavior);
    },
    "remove-cookie"(needle) {
      const test = matcher(needle);
      const remove = () => {
        document.cookie.split(";").forEach((cookie) => {
          const name = cookie.split("=")[0].trim();
          if (!name || !test(name)) return;
          const domains = ["", location.hostname, `.${location.hostname}`];
          for (const domain of domains) {
            document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/${domain ? `; domain=${domain}` : ""}`;
          }
        });
      };
      remove();
      window.addEventListener("beforeunload", remove);
    },
    "set-local-storage-item"(key, value) {
      storageItem("localStorage", key, value);
    },
    "set-session-storage-item"(key, value) {
      storageItem("sessionStorage", key, value);
    },
    "noeval-if"(needle) {
      const test = matcher(needle);
      window.eval = new Proxy(window.eval, {
        apply(target, thisArg, args) {
          if (test(String(args[0]))) return undefined;
          return apply(target, thisArg, args);
        }
      });
    },
    "nowebrtc"() {
      const stub = function RTCPeerConnection() {
        return { close: noop, createDataChannel: noop, createOffer: () => Promise.resolve({}),
          setLocalDescription: () => Promise.resolve(), addEventListener: noop, removeEventListener: noop };
      };
      for (const name of ["RTCPeerConnection", "webkitRTCPeerConnection", "mozRTCPeerConnection"]) {
        if (name in window) {
          try { defineProperty(window, name, { value: stub, configurable: true, writable: true }); } catch {}
        }
      }
    },
    "nobab": noAdBlockDetector
  };

  // Alias de uBlock Origin y Adblock Plus.
  const aliases = {
    aopr: "abort-on-property-read", aopw: "abort-on-property-write",
    acs: "abort-current-script", "abort-current-inline-script": "abort-current-script",
    aost: "abort-on-stack-trace", set: "set-constant", "override-property-read": "set-constant",
    nostif: "no-setTimeout-if", "prevent-setTimeout": "no-setTimeout-if",
    nosiif: "no-setInterval-if", "prevent-setInterval": "no-setInterval-if",
    "nano-stb": "nano-setTimeout-booster", "nano-sib": "nano-setInterval-booster",
    aeld: "addEventListener-defuser", "prevent-addEventListener": "addEventListener-defuser", "prevent-listener": "addEventListener-defuser",
    nowoif: "window.open-defuser", "no-window-open-if": "window.open-defuser", "prevent-window-open": "window.open-defuser",
    "prevent-fetch": "no-fetch-if", "prevent-xhr": "no-xhr-if",
    "trusted-rpfr": "trusted-replace-fetch-response", "replace-fetch-response": "trusted-replace-fetch-response",
    ra: "remove-attr", rc: "remove-class", "cookie-remover": "remove-cookie",
    noeval: "noeval-if", "silent-noeval": "noeval-if", nofab: "nobab", "bab-defuser": "nobab"
  };

  for (const [rawName, ...args] of rules) {
    const name = aliases[rawName] || rawName;
    try {
      scriptlets[name]?.(...args);
    } catch {
      // Un scriptlet fallido no debe impedir los demás.
    }
  }
})({"rules":{"18doujin.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"20min.ch":[["aopr","_sp_._networkListenerData"],["nano-stb","readyPromise","5000","0.001"]],"4k2h4w04.xyz":[["nowoif"],["acs","Math","localStorage['\\x"]],"5movies.cloud":[["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"]],"9n8o.com":[["abort-on-property-write","window.open"],["abort-current-inline-script","EventTarget.prototype.addEventListener","delete window"]],"9news.com":[["replace-fetch-response","/^{\"[/][0-9]+[/][^]*/","","\"html\","],["acs","document.getElementsByTagName",".pubads"]],"a-o.ninja":[["set","showAds","true"]],"adblockstrtape.link":[["abort-on-property-write","_pop"]],"afreesms.com":[["abort-current-inline-script","document.getElementById","window.open"]],"akb48matomemory.com":[["set-local-storage-item","adshield-analytics-uuid","$remove$"],["set-local-storage-item","/_fa_bGFzdF9iZmFfYXQ=$/","$remove$"],["set-local-storage-item","/_fa_dXVpZA==$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWNjZXB0YWJsZV9hZHM=$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWRz$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfYWRibG9ja19jaXJjdW12ZW50X3Njb3Jl$/","$remove$"]],"aliexpress.ru":[["set","OfflineAudioContext","undefined"],["set","navigator.bluetooth","undefined"]],"allschoolboysecrets.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"anal-analsex-anal.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"arenabg.com":[["aopr","AaDetector"]],"bestjapaneseporn.net":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"bigforum4you.com":[["abort-on-property-read","document.body.style.backgroundPosition"]],"bigsouthsports.com":[["set","blockAdBlock","trueFunc"]],"bingespree.net":[["abort-current-inline-script","document.write","atob"]],"bitlk.com":[["aopr","open"],["set","blurred","false"]],"boyfriendtv.com":[["aopw","backgroundBanner"],["aeld","click","interstitial"],["aopr","popunder"]],"br.de":[["set","akamaiDisableServerIpLookup","noopFunc"]],"branitube.net":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"businessua.com":[["abort-current-inline-script","setInterval","reload"]],"carparts.com":[["set-local-storage-item","optimizely-vuid","$remove$"]],"charlessheimprove.com":[["override-property-read","window.sk","false"],["abort-current-inline-script","encodeURIComponent"]],"chicoscam.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"chron.com":[["cookie-remover","realm.cookiesAndJavascript"]],"citethisforme.com":[["aopr","SBMGlobal.run.gramCallback"]],"cnbc.com":[["set","cnbc.canShowAds","true"]],"codeproject.com":[["aopw","_sp_"],["aopr","retrievalService"]],"columbian.com":[["cookie-remover","/^blaize_/","when","scroll keydown"]],"convert-case.softbaba.com":[["aopr","adblockDetector"]],"cvnews.cv.ua":[["abort-current-inline-script","document.createElement","/ru-n4p|ua-n4p|загрузка.../"]],"cyclones.com":[["set","blockAdBlock","trueFunc"]],"dailynews.com":[["set","CnnXt.Event.fire","noopFunc"],["set-session-storage-item","nxt_is_incognito","false"]],"desihoes.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"discord.com":[["no-xhr-if","discord.com/api/v9/science"]],"docs.google.com":[["no-xhr-if","method:POST url:/logImpressions"]],"dollargeneral.com":[["set","Navigator.prototype.globalPrivacyControl","false"],["set","navigator.globalPrivacyControl","false"]],"dominantwifeporn.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"doramasmp4.com":[["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"]],"dzienniklodzki.pl":[["aeld","","show"]],"ebonyamateurphoto.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"economictimes.indiatimes.com":[["set","objVc.interstitial_web",""],["nosiif","adb"]],"egy-live.online":[["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"]],"epson.com.cn":[["set","_gsq","{}"],["set","_gsq.push","noopFunc"],["set","_gsDevice",""]],"erowall.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"espn.com":[["json-prune-xhr-response","stream.insertion","","propsToMatch","/video/auth/media"],["set","Navigator.prototype.globalPrivacyControl","false"],["set","navigator.globalPrivacyControl","false"]],"essen-und-trinken.de":[["aopr","_sp_.mms.startMsg"]],"eurogamer.pt":[["aopr","_sp_.mms.startMsg"]],"exgfamateurporn.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"extremotvplay.com":[["aopr","open"]],"fanproj.net":[["abort-current-inline-script","Math","zfgloaded"]],"faucetdump.com":[["acs","$","ads"]],"fcc.lc":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"fetishshrine.com":[["aopr","decodeURI"],["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"filmtelecharger.net":[["abort-current-inline-script","Math","zfgloaded"]],"firestream.site":[["abort-on-property-write","window.open"],["abort-current-inline-script","EventTarget.prototype.addEventListener","delete window"],["abort-on-property-read","Adcash"]],"fisting-thumbs.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"fmovies-co.net":[["abort-on-property-write","window.open"]],"fmovies2.org":[["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"]],"forpost.media":[["abort-current-inline-script","document.createElement","/ru-n4p|ua-n4p|загрузка.../"]],"freehat.cc":[["abort-on-property-read","open"],["abort-on-property-read","advFirstClickOpenNewTab"]],"freehqporn.net":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"fuck-xnxx.com":[["aopr","popit"],["aeld","popstate","noPop"]],"fuckdy.com":[["aopr","Popunder"]],"gamelopte.com":[["nano-sib","yuidea-","*"]],"gazeta.ru":[["trusted-rpfr","/#rcmrclid=[a-zA-Z0-9]+/g","","rcm.rambler.ru"]],"geoguessr.com":[["override-property-read","window.navigator.connection.rtt","2000"]],"gfsvideos.com":[["aopr","document.dispatchEvent"],["nowoif"]],"goexplorers.com":[["set","blockAdBlock","trueFunc"]],"gojacks.com":[["set","blockAdBlock","trueFunc"]],"gomo.to":[["aopr","glxopen"],["nowoif"]],"gophersports.com":[["set","blockAdBlock","trueFunc"]],"goshockers.com":[["set","blockAdBlock","trueFunc"]],"gp24.pl":[["aeld","","show"]],"hd-xxx.me":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"hopwtr.com":[["set","Navigator.prototype.globalPrivacyControl","false"],["set","navigator.globalPrivacyControl","false"]],"hotgirlhub.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"hotleak.vip":[["abort-on-property-read","advertising"]],"hotmovs.com":[["abort-on-property-write","ads_priv"],["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-on-property-read","open"],["abort-current-inline-script","mz"]],"hotnudegirlporn.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"https-xhamster.com":[["acs","fetch","_0x","/^data:/"],["aopw","ai_front"]],"ifreefuck.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"imagetwist.com":[["acs","document.getElementsByTagName","script"],["aeld","","checkTarget"]],"indianpornvideo.org":[["abort-on-property-read","decodeURI"]],"insider.fitt.co":[["rc","subscribe-pop-active","body","stay"]],"insuredhome.org":[["set","page_params.holiday_promo","true"]],"interssh.com":[["aeld","load","2000"]],"iowaconference.com":[["set","blockAdBlock","trueFunc"]],"ipswichstar.co.uk":[["abort-current-inline-script","document.createElement","/data-sdk|last_bfa_at/"],["abort-on-property-read","__as_ready_resolve"]],"itech.co.ua":[["abort-on-property-read","td_ad_background_click_target"]],"its-kids.ru":[["abort-on-property-read","XMLHttpRequest"]],"japanesemomsex.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"jav380.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"javenspanish.com":[["abort-current-inline-script","document.createElement","/l\\.parentNode\\.insertBefore\\(s/"]],"jetvid.top":[["prevent-window-open","!abyss.to","1000"]],"kak.xxx":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"kakoysegodnyaprazdnik.ru":[["abort-on-property-read","google_jobrunner"]],"kaztorka.org":[["abort-current-inline-script","document.createElement","Math.random"]],"kicaunews.com":[["aopw","adBlockDetected"]],"kop.net.ua":[["abort-current-inline-script","document.createElement","/ru-n4p|ua-n4p|загрузка.../"]],"krolmen.ru":[["abort-on-property-read","Object.prototype.clunduse"],["abort-on-property-read","k_init"],["abort-on-property-read","Object.prototype.u_vastplayer"]],"kstatewomenshoops.net":[["set","blockAdBlock","trueFunc"]],"ksusports.com":[["set","blockAdBlock","trueFunc"]],"last.fm":[["override-property-read","__as_e","true"]],"ldoceonline.com":[["set-local-storage-item","adshield-analytics-uuid","$remove$"],["set-local-storage-item","/_fa_bGFzdF9iZmFfYXQ=$/","$remove$"],["set-local-storage-item","/_fa_dXVpZA==$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWNjZXB0YWJsZV9hZHM=$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWRz$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfYWRibG9ja19jaXJjdW12ZW50X3Njb3Jl$/","$remove$"]],"leaderlive.co.uk":[["abort-current-inline-script","document.createElement","/data-sdk|last_bfa_at/"],["abort-on-property-read","__as_ready_resolve"]],"letmejerk3.com":[["aopr","ExoLoader"],["aeld","","_0x"]],"livedoor.biz":[["set-local-storage-item","adshield-analytics-uuid","$remove$"],["set-local-storage-item","/_fa_bGFzdF9iZmFfYXQ=$/","$remove$"],["set-local-storage-item","/_fa_dXVpZA==$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWNjZXB0YWJsZV9hZHM=$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWRz$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfYWRibG9ja19jaXJjdW12ZW50X3Njb3Jl$/","$remove$"]],"localmemphis.com":[["replace-fetch-response","/^{\"[/][0-9]+[/][^]*/","","\"html\","],["acs","document.getElementsByTagName",".pubads"]],"los40.com":[["ra","class|style","div[id^=\"los40_gpt\"]"],["set","huecosPBS.nstdX","null"],["no-fetch-if","googlesyndication"],["set","DTM.trackAsyncPV","noopFunc"]],"loyolaramblers.com":[["set","blockAdBlock","trueFunc"]],"mangatrend.org":[["abort-current-inline-script","document.createElement","/l\\.parentNode\\.insertBefore\\(s/"]],"mature-chicks.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"maturemompics.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"maturesinhd.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"mauiinvitational.com":[["set","blockAdBlock","trueFunc"]],"mendocinobeacon.com":[["set-session-storage-item","nxt_is_incognito","false"]],"michaels.com":[["set","Navigator.prototype.globalPrivacyControl","false"],["set","navigator.globalPrivacyControl","false"]],"mjsbigblog.com":[["aopr","__eiPb"],["acs","Date","='\\x"],["acs","document.head.appendChild","='\\x"],["abort-on-property-read","g00gletag"]],"moontruyen.com":[["abort-current-inline-script","$","window.open"]],"moredesi.com":[["abort-on-property-read","__formatsGetters"]],"muthead.com":[["aopr","_sp_._networkListenerData"]],"mybestxtube.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"nackte.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"nakedteenporn.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"neopets.com":[["acs","document.createElement","admiral"]],"newxxxvideos.net":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"nilopolisonline.com.br":[["nostif","blocker"]],"niu-pack.com":[["set","blockAdBlock","trueFunc"]],"nrj-play.fr":[["set","adBlockDetector.isEnabled","falseFunc"]],"ntv.st":[["abort-on-property-write","ZpQw9XkLmN8c3vR3"],["abort-current-inline-script","document.createElement","/\\.settings\\s*=\\s*\\w+\\s*\\|\\|/"]],"olx.ua":[["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){39})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){3}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!38,)39,40,41(?:,|\\])/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){39})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){2}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!38,)39,40\\]/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){39})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){1}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!38,)39\\]/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){38})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){3}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!37,)38,39,40(?:,|\\])/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){38})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){2}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!37,)38,39\\]/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){38})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){1}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!37,)38\\]/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){37})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){3}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!36,)37,38,39(?:,|\\])/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){37})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){2}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!36,)37,38\\]/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){37})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){1}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!36,)37\\]/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){36})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){3}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!35,)36,37,38(?:,|\\])/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){36})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){2}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!35,)36,37\\]/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){36})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){1}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!35,)36\\]/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){26})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){3}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!25,)26,27,28(?:,|\\])/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){26})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){2}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!25,)26,27\\]/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){26})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){1}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!25,)26\\]/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){25})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){3}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!24,)25,26,27(?:,|\\])/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){25})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){2}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!24,)25,26\\]/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){25})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){1}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!24,)25\\]/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){24})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){3}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!23,)24,25,26(?:,|\\])/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){24})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){2}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!23,)24,25\\]/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){24})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){1}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!23,)24\\]/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){23})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){3}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!22,)23,24,25(?:,|\\])/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){23})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){2}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!22,)23,24\\]/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){23})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){1}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!22,)23\\]/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){13})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){3}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!12,)13,14,15(?:,|\\])/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){13})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){2}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!12,)13,14\\]/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){13})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){1}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!12,)13\\]/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){12})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){3}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!11,)12,13,14(?:,|\\])/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){12})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){2}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!11,)12,13\\]/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){12})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){1}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!11,)12\\]/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){11})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){3}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!10,)11,12,13(?:,|\\])/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){11})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){2}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!10,)11,12\\]/"],["replace-fetch-response","/(ListingSuccess,data:\\[(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){11})(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){1}/","$1","/promoted:\\[(?:[0-9]+,)*(?<!10,)11\\]/"],["replace-fetch-response","/(ListingSuccess,data:\\[)(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){3}/ '$1' /promoted:\\[(?:[0-9]+,)*0,1,2(?:,|\\])/"],["replace-fetch-response","/(ListingSuccess,data:\\[)(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){2}/ '$1' /promoted:\\[(?:[0-9]+,)*0,1\\]/"],["replace-fetch-response","/(ListingSuccess,data:\\[)(?:\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj(?:(?!\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)[\\s\\S])*?\\},(?=\\{_nodeId:bGVnYWN5QWR2ZXJ0Oj)){1}/ '$1' /promoted:\\[(?:[0-9]+,)*0\\]/"],["replace-fetch-response","/promoted:\\[[0-9,]*\\]/","\"promoted\":[]"],["json-prune","listing.listing"]],"ombak700.org":[["abort-on-property-read","sp"]],"optifine.net":[["nostif","Math.round","1000"]],"opvid.net":[["abort-on-property-read","setInterval"],["abort-on-property-read","setTimeout"],["abort-on-property-read","Math.random"]],"ottawacitizen.com":[["set","Object.prototype.adService.initialize","noopFunc"],["prevent-listener","message","/data===/"],["abort-current-inline-script","eval","/xjpvwbhtz9dj/"],["override-property-read","xjpvwbhtz9dj","true"],["acs","document.getElementsByTagName",".pubads"]],"oyungibi.com":[["set","jQuery.adblock","false"]],"palimas.tv":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"peachytube.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"perverzija.com":[["abort-on-property-read","JSON.stringfy"],["abort-on-property-read","a3klsam"]],"pianetamountainbike.it":[["set","LoadThisScript","true"]],"picbank.tk":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"pipocamoderna.com.br":[["aopw","adBlockDetected"]],"play-force.ru":[["abort-on-property-read","Object.prototype.clunduse"],["abort-on-property-read","k_init"],["abort-on-property-read","Object.prototype.u_vastplayer"]],"plusone8.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"pompanobeachcam.com":[["nostif","innerHTML"]],"poranny.pl":[["aeld","","show"]],"porn3dx.com":[["prevent-window-open","_blank"]],"porn720.biz":[["abort-current-inline-script","document.querySelectorAll","popMagic"]],"pornchimp.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"pornflixhd.com":[["aopw","adBlockDetected"]],"pornloupe.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"pornluck.com":[["set","page_params.holiday_promo","true"]],"pornmom.net":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"porntrex.com":[["abort-on-property-write","preventDefault"]],"pronpic.org":[["aopr","document.createEvent"],["aopw","ShowAdbblock"],["nostif","style"]],"pstream.net":[["abort-on-property-write","adcashMacros"],["abort-on-property-read","decodeURIComponent"],["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"]],"rarbgunblock.com":[["abort-on-property-read","LieDetector"]],"readmanganato.com":[["abort-on-property-read","localStorage"]],"real-vin.com":[["abort-current-inline-script","document.createElement","/ru-n4p|ua-n4p|загрузка.../"]],"redd.tube":[["abort-on-property-read","config"]],"ringelnatz.net":[["abort-on-property-read","wpsite_clickable_data"]],"rvnews.rv.ua":[["abort-current-inline-script","document.createElement","/ru-n4p|ua-n4p|загрузка.../"]],"salisburyjournal.co.uk":[["aopw","_sp_"],["abort-current-inline-script","document.createElement","/data-sdk|last_bfa_at/"],["abort-on-property-read","__as_ready_resolve"]],"sawstory.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"sbanh.com":[["abort-on-property-read","__Y"],["abort-on-property-read","decodeURI"],["abort-on-property-read","mm"]],"scamalot.com":[["acs","$","#DontBloxMyAdZ"]],"scarletknights.com":[["set","blockAdBlock","trueFunc"]],"sesso-escort.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"sexhdtuber.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"sexhihi9x.me":[["abort-on-property-read","document.cookie"]],"sexoamadorcorno.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"sexydilia.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"sezonlukdizi.cc":[["abort-current-inline-script","document.createElement","/l\\.parentNode\\.insertBefore\\(s/"]],"sfchronicle.com":[["cookie-remover","realm.cookiesAndJavascript"]],"shelovesporn.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"shortearn.in":[["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"]],"siriusfiles.com":[["nano-stb"]],"slutdump.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"solidfiles.com":[["aopw","Fingerprint2"]],"stepsisterfuck.me":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"stronakobiet.pl":[["aeld","","show"]],"svipvids.com":[["aopw","KillAdBlock"]],"tastemade.com":[["set-local-storage-item","hide-cookbook-modal-0","true"]],"teenpornjpg.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"theankler.com":[["rc","has-intro-popup","html","stay"],["rc","modal-in","html","stay"],["rc","show-intro-popup","html","stay"]],"thefreedommatrix.blogspot.com":[["aeld","load","2000"],["nobab"]],"thehealthy.com":[["acs","document.getElementsByTagName",".pubads"]],"thepiratebay.vip":[["abort-on-property-write","_pop"],["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"],["abort-on-property-read","atob"]],"theproxy.how":[["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"]],"thestarphoenix.com":[["set","Object.prototype.adService.initialize","noopFunc"]],"tipranks.com":[["set","TRC","{}"],["set","TRC._taboolaClone","[]"]],"tram3d.my":[["abort-current-inline-script","eval","$._Eu"]],"tubeflv.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"tubous.com":[["aopr","popMagic.init"],["aopr","document.dispatchEvent"],["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"tuotromedico.com":[["set","jQuery.adblock","false"]],"turbo.cr":[["abort-current-inline-script","WebAssembly","atob"]],"tv2.no":[["json-prune","enabled","testhide"]],"tvparapobreskids.com":[["prevent-listener","click","/InstallTrigger/"],["override-property-read","aclib","emptyObject"],["abort-on-property-read","aclib.runPop"]],"twinksfuck.me":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"twitchnosub.com":[["abort-current-inline-script","WebAssembly","atob"]],"uclabruins.com":[["set","blockAdBlock","trueFunc"]],"uii.io":[["noeval"],["nowebrtc"],["nowoif"],["aeld","mouseup","_blank"]],"ultimate-catch.eu":[["nostif","undefined"]],"umterps.com":[["set","blockAdBlock","trueFunc"]],"unchartedterritories.tomaspueyo.com":[["rc","has-intro-popup","html","stay"],["rc","modal-in","html","stay"],["rc","show-intro-popup","html","stay"]],"uncwsports.com":[["set","blockAdBlock","trueFunc"]],"uniquesexymoms.com":[["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"unito.life":[["acs","KeenTracking"]],"upmedia.mg":[["set-local-storage-item","adshield-analytics-uuid","$remove$"],["set-local-storage-item","/_fa_bGFzdF9iZmFfYXQ=$/","$remove$"],["set-local-storage-item","/_fa_dXVpZA==$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWNjZXB0YWJsZV9hZHM=$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWRz$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfYWRibG9ja19jaXJjdW12ZW50X3Njb3Jl$/","$remove$"]],"versii.if.ua":[["abort-on-property-read","weekCallbacks"],["abort-current-inline-script","document.createElement","/ru-n4p|ua-n4p|загрузка.../"]],"video.sports.ru":[["json-prune","data.sponsorCampaign"]],"vidply.com":[["abort-current-inline-script","String.fromCharCode","2147483647"]],"vidspace.io":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"vidtube.xxx":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"vikiporn.com":[["aeld","getexoloader"],["aopr","decodeURI"],["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"volyninfa.com.ua":[["abort-current-inline-script","document.createElement","/ru-n4p|ua-n4p|загрузка.../"]],"vortez.net":[["nowoif"],["acs","$","Adblock"]],"wallpaperflare.com":[["abort-current-inline-script","document.write"],["abort-on-property-read","window.open"]],"watchkobestreams.info":[["aost","atob","inlineScript"]],"watchporn.to":[["cookie-remover","kt_ips"]],"wemakesites.net":[["acs","$","adBlockChecker"]],"whtimes.co.uk":[["abort-current-inline-script","document.createElement","/data-sdk|last_bfa_at/"],["abort-on-property-read","__as_ready_resolve"]],"worldaide.fr":[["aopr","adblock"]],"wowjapangirls.net":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"wowskill.ru":[["abort-on-property-read","open"]],"www.diendancauduong.com":[["abort-on-property-read","antiAdBlockerHandler"]],"xnnxfree.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"xvideos-full.com":[["prevent-window-open","/overloadenjoy/","2","iframe"]],"yayanimes.net":[["abort-current-inline-script","document.createElement","_wtxnqkt"]],"young-ass.com":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"youvideoporno.mobi":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"zehnporn.com":[["aopr","loadTool"]],"zseek.ru":[["abort-on-property-read","adOnClick"]]},"exceptions":{"3igames.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"abczdrowie.pl":["aost\u0000WP.prebid\u0000onLoad"],"account.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"auto.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"away.vk.com":["abort-on-property-read\u0000vk__adsLight.adsShowed"],"away.vk.ru":["abort-on-property-read\u0000vk__adsLight.adsShowed"],"biz.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"blog.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"bonus.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"calendar.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"calls.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"cloud.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"connect.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"deti.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"dev.fingerprint.com":["no-xhr-if\u0000method:POST"],"dobro.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"docs.fingerprint.com":["no-xhr-if\u0000method:POST"],"dziennikbaltycki.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"dzienniklodzki.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"dziennikpolski24.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"dziennikzachodni.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"e.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"echodnia.eu":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"expressbydgoski.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"expressilustrowany.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"finance.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"gazetakrakowska.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"gazetalubuska.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"gazetawroclawska.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"gibdd.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"gk24.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"gloswielkopolski.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"gol24.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"gp24.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"gra.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"gs24.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"health.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"help.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"hi-tech.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"horo.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"job.mt.de":["nostif\u0000.call(null)\u000010"],"job.nw.de":["nostif\u0000.call(null)\u000010"],"kino.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"kurierlubelski.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"lady.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"love.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"mcs.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"minigames.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"mmminigames.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"motofakty.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"my.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"naszemiasto.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"new.fastpic.org":["abort-current-inline-script\u0000document.getElementById\u0000maybeShow","abort-on-property-read\u0000Date.prototype.toUTCString","abort-on-property-read\u0000Element.prototype.attachShadow","abort-on-property-write\u0000__BIM__"],"news.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"notes.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"nowiny24.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"nowosci.com.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"nto.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"o2.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"octavius.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"okminigames.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"otvet.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"pcgames.de":["set\u0000CustomEvent\u0000noopFunc"],"pets.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"pingit.com":["aopr\u0000AaDetector","aopr\u0000_pop","aopr\u0000open","aopr\u0000rmVideoPlay","aopw\u0000Fingerprint2","set\u0000blurred\u0000false"],"plans.rainbowplantlife.com":["abort-on-property-read\u0000Intl.DateTimeFormat\u0000false","abort-on-property-read\u0000as_1058949371\u0000true","await\u0000new ","json-override\u0000isUnregistered\u0000true\u0000isUnregistered","override-property-read\u0000Navigator.prototype.onLine\u0000false","override-property-read\u0000as_-1217724578\u0000true","override-property-read\u0000as_-1269284192\u0000true","override-property-read\u0000as_-1349200120\u0000true","override-property-read\u0000as_-1499012015\u0000true","override-property-read\u0000as_-1858225736\u0000true","override-property-read\u0000as_-690327166\u0000true","override-property-read\u0000as_-930335972\u0000true","override-property-read\u0000as_-977715772\u0000true","override-property-read\u0000as_-989986399\u0000true","override-property-read\u0000as_1026413243\u0000true","override-property-read\u0000as_1098238358\u0000true","override-property-read\u0000as_1327966181\u0000true","override-property-read\u0000as_348516803\u0000true","override-property-read\u0000as_447456217\u0000true","override-property-read\u0000as_687465023\u0000true","override-property-read\u0000as_720001151\u0000true","override-property-read\u0000as_739024637\u0000true","override-property-read\u0000as_759290138\u0000true","override-property-read\u0000as_818940565\u0000true","override-property-read\u0000as_989017961\u0000true","replace-argument\u0000Element.prototype.setAttribute\u00001\u0000","replace-xhr-response\u0000/[\\s\\S]*/\u0000\u0000/pub_300x250/"],"player-smotri.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"poczta.wp.pl":["hide-if-matches-xpath\u0000.//div[@class and @* and not (@id)]//a[@class and @* and not (@id)][string-length(@href)>1000]//div[@class]//img[@class and @* and not (@id)][string-length(@src)>100]/ancestor::div[@class and @* and not(@id)][3]","hide-if-matches-xpath\u0000//a[string-length(@href)>1000]/img[@class and @*[not(name() = \"class\")]][string-length(@src)>125]","hide-if-matches-xpath\u0000//a[string-length(@href)>1000]/img[@src]/ancestor::div[.//span[normalize-space(text())=\"REKLAMA\"]][1][string-length(normalize-space()) < 100]","hide-if-matches-xpath\u0000//div[@class and @*[not(@class)]=\"\"]/div[not(*) and not(normalize-space())][@class and @*[not(@class)]=\"\"]/ancestor::div[@class and @*[not(@class)]=\"\"][contains(@class,\" \")][contains(@*[not(@class)],\" \")][string-length(@*[not(@class)]) > 25][not(starts-with(@class,\"app-container\") or starts-with(@class,\"sticky-wrapper\"))]","hide-if-matches-xpath\u0000//ul[@class]/li[string-length(@class)<=25][contains(normalize-space(), \" \")]/img[string-length(@src) >140]/following-sibling::span/a[string-length(@href) > 2000]/ancestor::li"],"pogoda.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"polskatimes.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"pomorska.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"poranny.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"sportowefakty.wp.pl":["hide-if-matches-xpath\u0000//a[string-length(@href)>1000]/img[@src]/ancestor::div[.//span[normalize-space(text())=\"REKLAMA\"]][1][string-length(normalize-space()) < 100]","hide-if-matches-xpath\u0000//div[@class and @*[not(@class)]=\"\"]/div[not(*) and not(normalize-space())][@class and @*[not(@class)]=\"\"]/ancestor::div[@class and @*[not(@class)]=\"\"][contains(@class,\" \")][contains(@*[not(@class)],\" \")][string-length(@*[not(@class)]) > 25][not(starts-with(@class,\"app-container\") or starts-with(@class,\"sticky-wrapper\"))]"],"sportowy24.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"strefaagro.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"strefabiznesu.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"stronakobiet.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"t-online.de":["set\u0000CustomEvent\u0000noopFunc"],"telemagazyn.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"to.com.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"todo.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"top.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"touch.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"tv.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"uii.io":["noeval"],"uqload.co":["abort-current-script\u0000document.createElement\u0000break;case $."],"vfokuse.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"vr.pornhat.*":["aopr\u0000document.dispatchEvent"],"widgets.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"wspolczesna.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"www.hoyolab.com":["trusted-set-cookie\u0000DEVICEFP\u000000000000000\u0000\u0000\u0000domain\u0000.hoyolab.com","trusted-set-cookie\u0000DEVICEFP_SEED_ID\u0000\u00000\u0000\u0000domain\u0000.hoyolab.com","trusted-set-cookie\u0000DEVICEFP_SEED_TIME\u0000\u00000\u0000\u0000domain\u0000.hoyolab.com"],"www.hoyoverse.com":["trusted-set-cookie\u0000DEVICEFP\u000000000000000\u0000\u0000\u0000domain\u0000.hoyoverse.com","trusted-set-cookie\u0000DEVICEFP_SEED_ID\u0000\u00000\u0000\u0000domain\u0000.hoyoverse.com","trusted-set-cookie\u0000DEVICEFP_SEED_TIME\u0000\u00000\u0000\u0000domain\u0000.hoyoverse.com"],"yandex.*":["aopr\u0000Object.prototype.renderDirect):matches-path(/\\/(?:weather\\/|pogoda\\/|hava\\/)/"]}});
