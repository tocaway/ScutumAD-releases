// Sustituto local vacío para scripts bloqueados.
(() => {})();
