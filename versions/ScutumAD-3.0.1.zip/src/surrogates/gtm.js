// Sustituto local de Google Tag Manager (gtm.js): llama a eventCallback de
// lo que la web añade a dataLayer, sin cargar etiquetas.
(() => {
  "use strict";
  const layer = Array.isArray(window.dataLayer) ? window.dataLayer : (window.dataLayer = []);
  const runCallback = (entry) => {
    if (entry && typeof entry.eventCallback === "function") {
      setTimeout(() => {
        try { entry.eventCallback(); } catch {}
      }, 0);
    }
  };
  layer.forEach(runCallback);
  const push = layer.push.bind(layer);
  layer.push = (...entries) => {
    entries.forEach(runCallback);
    return push(...entries);
  };
  window.google_tag_manager = window.google_tag_manager || {};
})();
