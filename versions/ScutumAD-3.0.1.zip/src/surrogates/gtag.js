// Sustituto local de gtag.js: conserva dataLayer y llama a event_callback.
(() => {
  "use strict";
  window.dataLayer = Array.isArray(window.dataLayer) ? window.dataLayer : [];
  window.gtag = function gtag(...args) {
    const options = args[args.length - 1];
    if (options && typeof options.event_callback === "function") {
      setTimeout(() => {
        try { options.event_callback(); } catch {}
      }, 0);
    }
  };
})();
