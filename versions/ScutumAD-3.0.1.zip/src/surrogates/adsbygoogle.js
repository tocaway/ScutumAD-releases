// Sustituto local de adsbygoogle.js: acepta los push de la web sin mostrar
// anuncios para que sus scripts no fallen.
(() => {
  "use strict";
  const queued = Array.isArray(window.adsbygoogle) ? window.adsbygoogle : [];
  window.adsbygoogle = { loaded: true, push() {} };
  void queued;
})();
