// Sustituto local de Google Publisher Tag (gpt.js): los métodos existen y
// no hacen nada, y la cola googletag.cmd se ejecuta para no romper la web.
(() => {
  "use strict";
  const chain = (target) => new Proxy(target, {
    get(object, key) {
      if (key in object) return object[key];
      return () => proxy;
    }
  });
  const slot = chain({
    getSlotElementId: () => "",
    getAdUnitPath: () => "",
    getTargeting: () => [],
    getTargetingKeys: () => [],
    getResponseInformation: () => null
  });
  const pubads = chain({
    getSlots: () => [],
    getTargeting: () => [],
    getTargetingKeys: () => [],
    isInitialLoadDisabled: () => false
  });
  const proxy = chain({});
  const command = (fn) => {
    if (typeof fn === "function") {
      try { fn(); } catch {}
    }
  };
  const previous = window.googletag?.cmd;
  const googletag = {
    apiReady: true,
    pubadsReady: true,
    cmd: { push: (...fns) => { fns.forEach(command); return 0; } },
    defineSlot: () => slot,
    defineOutOfPageSlot: () => slot,
    destroySlots: () => true,
    display() {},
    enableServices() {},
    getVersion: () => "",
    pubads: () => pubads,
    companionAds: () => proxy,
    content: () => proxy,
    sizeMapping: () => chain({ build: () => [] }),
    setAdIframeTitle() {}
  };
  window.googletag = googletag;
  if (Array.isArray(previous)) previous.forEach(command);
})();
