// Sustituto local de FuckAdBlock / BlockAdBlock: la comprobación siempre
// informa de que no hay bloqueador, así la web no muestra su aviso.
(() => {
  "use strict";
  class NoAdBlockDetector {
    constructor() {
      this.notDetected = [];
    }
    setOption() { return this; }
    check() {
      this.notDetected.forEach((callback) => {
        try { callback(); } catch {}
      });
      return true;
    }
    emitEvent() { return this; }
    clearEvent() {}
    on(detected, callback) {
      if (!detected) this.onNotDetected(callback);
      return this;
    }
    onDetected() { return this; }
    onNotDetected(callback) {
      if (typeof callback === "function") {
        this.notDetected.push(callback);
        setTimeout(() => {
          try { callback(); } catch {}
        }, 1);
      }
      return this;
    }
  }
  for (const name of ["FuckAdBlock", "BlockAdBlock", "SniffAdBlock"]) {
    window[name] = NoAdBlockDetector;
    const instance = name.charAt(0).toLowerCase() + name.slice(1);
    window[instance] = new NoAdBlockDetector();
  }
})();
