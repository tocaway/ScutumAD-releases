// Sustituto local de Google Analytics (analytics.js): no envía nada y
// ejecuta los callbacks para que la web no se quede esperando.
(() => {
  "use strict";
  const queue = window.ga?.q || [];
  const tracker = { get() {}, set() {}, send() {} };
  function ga(...args) {
    const last = args[args.length - 1];
    if (typeof args[0] === "function") {
      try { args[0](tracker); } catch {}
    } else if (last && typeof last.hitCallback === "function") {
      try { last.hitCallback(); } catch {}
    }
  }
  ga.create = () => tracker;
  ga.getByName = () => tracker;
  ga.getAll = () => [tracker];
  ga.remove = () => {};
  ga.loaded = true;
  window.ga = ga;
  window[window.GoogleAnalyticsObject || "ga"] = ga;
  queue.forEach((args) => ga(...args));
})();
