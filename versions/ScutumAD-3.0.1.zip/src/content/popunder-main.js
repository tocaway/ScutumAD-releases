(() => {
  const policy = globalThis.ScutumADPopupPolicy;
  if (!policy) return;
  let protectionEnabled = true;
  let linkIntent = null;
  let mediaGesture = false;
  let blockedPopupDomains = [];
  let learningPicking = false;
  const isBlockedAd = (value, base = sourceUrl()) => policy.isBlockedAdUrl(value, base)
    || policy.isBlockedPopupUrl(value, base, blockedPopupDomains);

  function sourceUrl() {
    if (policy.http(location.href)) return location.href;
    return document.referrer || location.ancestorOrigins?.[0] || "";
  }
  function isStreamingPage() { return policy.isStreamingUrl(sourceUrl()); }
  function isPlayerPage() { return policy.isPlayerUrl(sourceUrl()); }
  let strictSite = false;
  function isStrictPage() { return strictSite || isStreamingPage() || isPlayerPage(); }
  function eventTargetElement(event) {
    return event.composedPath?.().find((node) => node instanceof Element)
      || (event.target instanceof Element ? event.target : null);
  }
  function isInteractiveMediaControl(element, anchor) {
    const control = element?.closest("button,[role='button'],video,audio,input,select,textarea,summary,[contenteditable='true']");
    return Boolean(control && control !== anchor);
  }
  function shouldBlockWindowOpen(value) {
    if (learningPicking) return true;
    if (!protectionEnabled) return false;
    if (isBlockedAd(value)) return true;
    if (!isStrictPage()) return false;
    // Activar audio/reproducción nunca autoriza una ventana, ni vacía ni interna.
    if (mediaGesture) return true;
    const destination = policy.http(value, sourceUrl());
    if (linkIntent && destination?.href === linkIntent.href && performance.now() < linkIntent.until) return false;
    return !policy.isTrustedDestination(value, sourceUrl());
  }

  const nativeOpen = window.open;
  if (typeof nativeOpen === "function") {
    try {
      // Un Proxy de la función nativa: window.open.toString() sigue diciendo
      // «[native code]», así que la web no ve que la ha cambiado un bloqueador.
      Object.defineProperty(window, "open", {
        configurable: true,
        writable: true,
        value: new Proxy(nativeOpen, {
          apply(original, thisArg, args) {
            const [url, target, features] = args;
            // _self/_top/_parent no crean ventanas: conservar la navegación normal.
            if (["_self", "_top", "_parent"].includes(String(target).toLowerCase())
                && !learningPicking
                && !(protectionEnabled && isStrictPage() && mediaGesture)
                && !isBlockedAd(url)) {
              return original.call(window, url, target, features);
            }
            if (shouldBlockWindowOpen(url)) return null;
            return original.call(window, url, target, features);
          }
        })
      });
    } catch {
      // El worker comprueba también ventanas creadas por rutas alternativas.
    }
  }

  function blockPopupAnchor(event) {
    // Mantener el clic para el selector aislado, sin navegar al anuncio.
    if (learningPicking) { event.preventDefault(); return; }
    if (!protectionEnabled) return;
    const element = eventTargetElement(event);
    const anchor = element?.closest("a[href],area[href]");
    const control = isInteractiveMediaControl(element, anchor);
    mediaGesture = control;
    linkIntent = null;
    // Mantener el contexto durante el despacho nativo y sus microtareas.
    setTimeout(() => { mediaGesture = false; }, 0);
    if (!anchor) return;
    const destination = policy.http(anchor.href, sourceUrl());
    const external = !policy.isTrustedDestination(anchor.href, sourceUrl());
    const blocked = isBlockedAd(anchor.href)
      || (isStrictPage() && external && (control || !event.isTrusted || !policy.hasExplicitLink(anchor)));
    if (blocked) {
      event.preventDefault();
      // Cancelar la navegación de la capa SIN cancelar el control de audio.
      if (!control) event.stopImmediatePropagation();
      return;
    }
    if (event.isTrusted && !control && destination) {
      linkIntent = { href: destination.href, until: performance.now() + 800 };
    }
  }

  // El estado llega por un MessagePort que entrega el content script antes de
  // que se ejecute la página. Un CustomEvent lo podría falsificar la web.
  const bridgeListener = (event) => {
    if (event.source !== window || event.data?.scutumadBridge !== "popunder" || !event.ports?.[0]) return;
    event.stopImmediatePropagation();
    window.removeEventListener("message", bridgeListener, true);
    event.ports[0].onmessage = ({ data }) => {
      if (data?.type === "state") {
        protectionEnabled = data.enabled !== false;
        strictSite = data.strict === true;
        blockedPopupDomains = Array.isArray(data.blockedPopupDomains) ? data.blockedPopupDomains : [];
      } else if (data?.type === "learning-pick") {
        learningPicking = data.enabled === true;
      }
    };
  };
  window.addEventListener("message", bridgeListener, true);
  window.addEventListener("click", blockPopupAnchor, true);
  window.addEventListener("auxclick", blockPopupAnchor, true);
  // No cambiar muted, volume, play() ni el estado interno del reproductor.
})();
