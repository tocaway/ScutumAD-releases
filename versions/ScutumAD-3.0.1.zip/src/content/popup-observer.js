(() => {
  const policy = globalThis.ScutumADPopupPolicy;
  if (!policy) return;
  function recordIntent(event) {
    // content.js publica el estado del selector en este mundo aislado.
    if (!event.isTrusted || globalThis.ScutumADLearningPicking) return;
    const element = event.composedPath().find((node) => node instanceof Element);
    const anchor = element?.closest("a[href],area[href]");
    if (!policy.hasExplicitLink(anchor)) return;
    const control = element.closest("button,[role='button'],video,audio,input,select,textarea,summary,[contenteditable='true']");
    if (control && control !== anchor) return;
    const destination = policy.http(anchor.href, location.href);
    if (!destination || policy.isBlockedAdUrl(destination.href)) return;
    chrome.runtime.sendMessage({ type: "POPUP_LINK_INTENT", url: destination.href }).catch(() => {});
  }
  window.addEventListener("click", recordIntent, true);
  window.addEventListener("auxclick", recordIntent, true);
})();
