(() => {
  const { DEFAULT_SETTINGS, KEYS: SETTINGS_KEYS } = globalThis.ScutumADSettings;

  // Nombres aleatorios en cada página: una web no puede buscar un id o una
  // clase fija para saber que ScutumAD está instalado.
  const PAGE_TOKEN = `_${Math.random().toString(36).slice(2, 9)}`;
  const COSMETIC_STYLE_ID = `${PAGE_TOKEN}c`;
  const LEARNED_HIDDEN_CLASS = `${PAGE_TOKEN}h`;
  const LEARNING_CANDIDATE_CLASS = `${PAGE_TOKEN}k`;
  const LEARNING_STYLE_ID = `${PAGE_TOKEN}s`;
  const LEARNING_HOST_ID = `${PAGE_TOKEN}g`;
  let ownsLearningGuide = window.top === window.self;
  const learnedModals = new Set();
  let guideModalObserver = null;
  // Deliberadamente no se incluyen selectores genéricos como [id~='ad'] o
  // [class~='ad']: suelen coincidir con partes legítimas de una noticia.
  const LEARNING_CANDIDATE_SELECTORS = [
    "[data-ad-slot]",
    "[data-ad-client]",
    "[data-advertisement]",
    "[data-sponsored]",
    "ins.adsbygoogle",
    "iframe[src*='doubleclick.net']",
    "iframe[src*='googlesyndication.com']",
    "iframe[src*='adservice.google.com']",
    "iframe[src*='ad.apl601.online']",
    "iframe[src*='ad.apl602.online']",
    "iframe[src*='ads.livetv903.me']",
    "iframe[src*='ads.livetv904.me']",
    "iframe[src*='track.adform.net']",
    "iframe[src*='diligenceshaped.com']",
    "a[href*='diligenceshaped.com']",
    "[id*='advertisement' i]",
    "[id*='sponsored' i]",
    "[id*='promoted' i]",
    "[class*='ad-banner' i]",
    "[class*='ad-container' i]",
    "[class*='advertisement' i]",
    "[class*='advertising' i]",
    "[class*='sponsored' i]",
    "[class*='promoted' i]",
    "[class*='interstitial-ad' i]",
    "[class*='popup-ad' i]",
    "[class*='overlay-ad' i]",
    "[class*='outbrain' i]",
    "[class*='taboola' i]",
    "[aria-label*='Publicidad' i]",
    "[aria-label*='Advertisement' i]",
    "[aria-label*='Sponsored' i]"
  ];

  const YOUTUBE_HOSTS = new Set([
    "youtube.com",
    "www.youtube.com",
    "m.youtube.com",
    "music.youtube.com",
    "tv.youtube.com",
    "youtube-nocookie.com",
    "www.youtube-nocookie.com",
    "youtubekids.com",
    "www.youtubekids.com"
  ]);
  const LEARNING_CANDIDATE_SELECTOR_TEXT = LEARNING_CANDIDATE_SELECTORS.join(",");
  let learnedObserver = null;
  let learningHost = null;
  let learningShadow = null;
  let learningCandidate = null;
  let learningPickerActive = false;
  let learningMessage = "";
  let learningMessageTimer = null;
  let remoteSelection = null;
  let guideDismissed = false;
  const learnedHidden = new Set();
  const ignoredLearningElements = new WeakSet();
  const candidateHistory = [];
  let settings = { ...DEFAULT_SETTINGS };
  let cosmeticSignature = "";
  let cosmeticRequest = 0;

  // Canal privado con los scripts del mundo MAIN. Se crea al arrancar, antes
  // de que se ejecute la página: un CustomEvent en window lo podría imitar la
  // propia web para desactivar la protección.
  const mainPorts = {};
  for (const name of YOUTUBE_HOSTS.has(location.hostname.toLowerCase()) ? ["popunder", "youtube"] : ["popunder"]) {
    const channel = new MessageChannel();
    mainPorts[name] = channel.port1;
    window.postMessage({ scutumadBridge: name }, "*", [channel.port2]);
  }
  function sendToMain(name, message) {
    mainPorts[name]?.postMessage(message);
  }
  function setLearningPickState(enabled) {
    // popup-observer.js comparte este mundo aislado; la página no lo ve.
    globalThis.ScutumADLearningPicking = enabled === true;
    sendToMain("popunder", { type: "learning-pick", enabled: enabled === true });
  }

  // Agrupa las mutaciones de un observer: cada nodo se revisa una vez por
  // lote y se omiten los que ya están dentro de otro nodo pendiente.
  function batchedObserver(inspect, afterBatch) {
    const pending = new Set();
    let scheduled = false;
    const flush = () => {
      scheduled = false;
      const nodes = [...pending].filter((node) => node.isConnected);
      pending.clear();
      nodes
        .filter((node) => !nodes.some((other) => other !== node && other.contains(node)))
        .forEach(inspect);
      afterBatch?.();
    };
    return new MutationObserver((records) => {
      records.forEach((record) => {
        if (record.target instanceof Element) pending.add(record.target);
      });
      if (!scheduled && pending.size) {
        scheduled = true;
        setTimeout(flush, 0);
      }
    });
  }

  function isTopFrame() {
    try {
      return window.top === window.self;
    } catch {
      return true;
    }
  }

  function getHostname() {
    try {
      return location.hostname.toLowerCase().replace(/\.$/, "");
    } catch {
      return "";
    }
  }

  function isYouTube() {
    return YOUTUBE_HOSTS.has(getHostname());
  }

  function normalizeDomain(value) {
    if (typeof value !== "string" || !value.trim()) {
      return null;
    }

    try {
      const candidate = value.includes("://") ? value : `https://${value}`;
      const hostname = new URL(candidate).hostname.toLowerCase().replace(/^\.+|\.+$/g, "");
      return /^[a-z0-9.-]+$/i.test(hostname) ? hostname : null;
    } catch {
      return null;
    }
  }

  function frameHostnames() {
    return [getHostname(), ...Array.from(location.ancestorOrigins || [])
      .map((origin) => normalizeDomain(origin))].filter(Boolean);
  }

  function currentSiteMode() {
    return globalThis.ScutumADSettings.siteModeFor(frameHostnames(), settings);
  }

  function isWhitelisted() {
    const hostnames = frameHostnames();
    const whitelist = Array.isArray(settings.whitelist) ? settings.whitelist : [];
    return whitelist.some((domain) => {
      const normalized = normalizeDomain(domain);
      return normalized && hostnames.some((hostname) => hostname === normalized || hostname.endsWith(`.${normalized}`));
    });
  }

  function isPageContentContainer(element, learned = false) {
    if (element.localName === "iframe" && !isAdvertisingFrame(element)) return true;
    if (element.matches("html, body, main, article, h1, h2, h3, h4, h5, h6, [role='heading'], [itemprop='headline'], [role='main'], [itemprop='articleBody']")) {
      return true;
    }
    // Un párrafo o fotografía dentro de una noticia sigue siendo contenido,
    // aunque una antigua regla coincida con su clase de maquetación.
    const withinArticle = element.closest("article,[itemprop='articleBody']");
    const dedicatedAd = element.matches("[data-ad-slot],[data-ad-client],[data-advertisement],ins.adsbygoogle")
      || (element.localName === "iframe" && isAdvertisingFrame(element));
    if (withinArticle && !dedicatedAd) return true;

    // Una clase o capa publicitaria nunca justifica ocultar el vídeo ni sus
    // controles. Las capas independientes se ocultan por separado.
    const mediaSelector = "video,audio,#unmuteBtn,[aria-label*='unmute' i],.jw-controls,.vjs-control-bar";
    if (element.matches(mediaSelector)
      || element.querySelectorAll(mediaSelector).length > 0
      || Array.from(element.querySelectorAll("iframe[src]")).some((frame) => (
        !isAdvertisingFrame(frame)
      ))) return true;

    const articleCount = element.querySelectorAll("article").length;
    const headingCount = element.querySelectorAll("h1,h2,h3,h4,h5,h6,[role='heading'],[itemprop='headline']").length;
    const linkCount = element.querySelectorAll("a[href]").length;
    const textLength = (element.textContent || "").trim().length;

    return articleCount > 0
      || (headingCount > 0 && !(learned && element.matches("dialog,[role='dialog']") && textLength <= 2400))
      || linkCount >= 20
      || (headingCount > 0 && textLength > 1200);
  }

  function installLearningStyle() {
    if (document.getElementById(LEARNING_STYLE_ID)) {
      return;
    }

    const style = document.createElement("style");
    style.id = LEARNING_STYLE_ID;
    style.textContent = `
      .${LEARNED_HIDDEN_CLASS} {
        display: none !important;
        visibility: hidden !important;
      }
      .${LEARNING_CANDIDATE_CLASS} {
        outline: 2px dashed #ffbd4a !important;
        outline-offset: 3px !important;
      }
    `;
    (document.documentElement || document.head || document).appendChild(style);
  }

  function removeLearnedHides() {
    document.querySelectorAll(`.${LEARNED_HIDDEN_CLASS}`).forEach((element) => {
      element.classList.remove(LEARNED_HIDDEN_CLASS);
    });
    learnedHidden.clear();
    learnedModals.forEach(restoreLearnedModal);
  }

  function restoreLearnedModal(element) {
    if (element.classList.contains(LEARNED_HIDDEN_CLASS)) return;
    learnedModals.delete(element);
    if (element.isConnected && !element.open) {
      try { element.showModal(); } catch { /* El sitio puede haberlo retirado. */ }
    }
  }

  function learnedRulesForCurrentHost() {
    const hostnames = [getHostname(), ...Array.from(location.ancestorOrigins || [])
      .map((origin) => normalizeDomain(origin))].filter(Boolean);
    return Array.isArray(settings.learnedRules)
      ? settings.learnedRules.filter((rule) => !rule.disabled && rule.action !== "block-popup" && hostnames.includes(rule?.domain)
          && (!rule.frameDomain || rule.frameDomain === getHostname()))
      : [];
  }

  function learnedTarget(element) {
    if (!(element instanceof Element) || isPageContentContainer(element, true)) return element;
    // Las reglas antiguas podían señalar solo un párrafo de un banner modal.
    // Usa el mismo destino seguro que una selección nueva para cerrar su fondo.
    const dialog = element.closest("dialog,[role='dialog']");
    return dialog && isLearningSafeTarget(dialog) ? dialog : element;
  }

  function learnedRuleApplies(element, rule) {
    if (element.matches(rule.selector) && learnedTarget(element) === element) return true;
    return element.matches("dialog,[role='dialog']")
      && [...element.querySelectorAll(rule.selector)].some(source => learnedTarget(source) === element);
  }

  function hideLearnedElement(element) {
    element = learnedTarget(element);
    if (!(element instanceof Element)
      || isPageContentContainer(element, true)) {
      return 0;
    }
    if (element.classList.contains(LEARNED_HIDDEN_CLASS)) {
      if (element.matches("dialog:modal")) { learnedModals.add(element); element.close(); }
      return 0;
    }

    element.classList.add(LEARNED_HIDDEN_CLASS);
    learnedHidden.add(element);
    if (element.matches("dialog:modal")) {
      learnedModals.add(element);
      element.close(); // Retira también el backdrop y la inercia del documento.
    }
    return 1;
  }

  function inspectLearnedNode(node) {
    if (!(node instanceof Element)) {
      return;
    }

    learnedRulesForCurrentHost().forEach((rule) => {
      try {
        if (node.matches(rule.selector)) {
          hideLearnedElement(node);
        }
        node.querySelectorAll(rule.selector).forEach((element) => hideLearnedElement(element));
      } catch {
        // Una regla dañada no debe detener la protección de la página.
      }
    });
    inspectBannerContainers(node, true);
  }

  function revalidateLearnedHides() {
    learnedHidden.forEach((element) => {
      if (!element.isConnected) { learnedHidden.delete(element); learnedModals.delete(element); return; }
      if (isPageContentContainer(element, true) || (!learnedRulesForCurrentHost().some(rule => {
        try { return learnedRuleApplies(element, rule); } catch { return false; }
      })
          && !isBannerContainer(element, true))) {
        learnedHidden.delete(element);
        element.classList.remove(LEARNED_HIDDEN_CLASS);
        restoreLearnedModal(element);
      }
    });
  }

  function startLearnedRules() {
    learnedObserver?.disconnect(); learnedObserver = null;
    if (!(settings.protectionEnabled && !isWhitelisted()) || !learnedRulesForCurrentHost().length) {
      stopLearnedRules();
      return;
    }

    installLearningStyle();
    inspectLearnedNode(document.documentElement);
    revalidateLearnedHides();
    learnedObserver = batchedObserver(inspectLearnedNode, revalidateLearnedHides);
    learnedObserver.observe(document.documentElement || document, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["id", "class", "src", "href", "open", "aria-label", "data-ad", "data-ad-slot", "data-sponsored"]
    });
  }

  function stopLearnedRules() {
    learnedObserver?.disconnect();
    learnedObserver = null;
    removeLearnedHides();
    if (!learningHost) {
      document.getElementById(LEARNING_STYLE_ID)?.remove();
    }
  }

  function cssEscape(value) {
    if (globalThis.CSS?.escape) {
      return globalThis.CSS.escape(value);
    }
    return String(value).replace(/[^a-z0-9_-]/gi, (character) => `\\${character}`);
  }

  function selectorMatchesOnly(selector, element) {
    if (!selector || selector.length > 700 || /[{};<>]/.test(selector)) {
      return false;
    }

    try {
      const matches = document.querySelectorAll(selector);
      return matches.length === 1 && matches[0] === element && !isPageContentContainer(element, true);
    } catch {
      return false;
    }
  }

  function learnedAdFrameSelector(element) {
    if (!(element instanceof Element) || element.localName !== "iframe") {
      return null;
    }

    const source = element.getAttribute("src") || element.src || "";
    try {
      const parsed = new URL(source, location.href);
      const hostname = parsed.hostname.toLowerCase();
      const isAdFrame = isAdvertisingFrame(element);
      if (!isAdFrame || !hostname) {
        return null;
      }

      // Estos proveedores generan una URL distinta en cada recarga. La regla
      // se guarda por proveedor y oculta todos sus marcos de banner, no solo
      // el identificador efímero de una carga concreta.
      // Anclado al host: el nombre del proveedor en un parámetro de otro
      // iframe nunca debe ocultar un vídeo o enlace legítimo.
      const selector = ["https://", "http://", "//"].map(prefix => `iframe[src^=${JSON.stringify(prefix + hostname + "/")}]`).join(",");
      return document.querySelector(selector) ? selector : null;
    } catch {
      return null;
    }
  }

  function stableClassTokens(element) {
    return [...element.classList]
      .filter((token) => !token.startsWith("scutumad-") && !token.startsWith(PAGE_TOKEN))
      .filter((token) => /^[a-z_-][a-z0-9_-]{0,49}$/i.test(token))
      .filter((token) => !/(?:^|[-_])(active|selected|visible|hidden|open|closed)(?:$|[-_])/i.test(token))
      .filter((token) => !/\d{6,}/.test(token))
      .slice(0, 3);
  }

  function buildLearnedSelector(element) {
    if (!(element instanceof Element)
      || element === document.documentElement
      || element === document.body
      || !isLearningSafeTarget(element)) {
      return null;
    }

    const adFrameSelector = learnedAdFrameSelector(element)
      || (isBannerContainer(element, false) && learnedAdFrameSelector(element.querySelector("iframe")));
    if (adFrameSelector) {
      return adFrameSelector;
    }

    if (element.id && element.id.length <= 100) {
      const idSelector = `#${cssEscape(element.id)}`;
      if (selectorMatchesOnly(idSelector, element)) {
        return idSelector;
      }
    }

    for (const attribute of ["data-ad-slot", "data-ad-client", "data-advertisement", "data-sponsored", "aria-label"]) {
      const value = element.getAttribute(attribute);
      if (!value || value.length > 120) {
        continue;
      }
      const attributeSelector = `[${attribute}=${JSON.stringify(value)}]`;
      if (selectorMatchesOnly(attributeSelector, element)) {
        return attributeSelector;
      }
    }

    const classes = stableClassTokens(element);
    for (let count = Math.min(classes.length, 3); count > 0; count -= 1) {
      const classSelector = `${element.localName}${classes.slice(0, count).map((token) => `.${cssEscape(token)}`).join("")}`;
      if (selectorMatchesOnly(classSelector, element)) {
        return classSelector;
      }
    }

    const path = [];
    let current = element;
    let depth = 0;
    while (current && current !== document.body && depth < 5) {
      const tokens = stableClassTokens(current).slice(0, 1);
      let part = current.localName || "div";
      if (tokens.length) {
        part += `.${cssEscape(tokens[0])}`;
      } else if (current.parentElement) {
        const sameTag = [...current.parentElement.children]
          .filter((child) => child.localName === current.localName);
        const position = sameTag.indexOf(current) + 1;
        if (position > 0 && sameTag.length > 1) {
          part += `:nth-of-type(${position})`;
        }
      }
      path.unshift(part);
      const pathSelector = path.join(" > ");
      if (selectorMatchesOnly(pathSelector, element)) {
        return pathSelector;
      }
      current = current.parentElement;
      depth += 1;
    }

    return null;
  }

  function isLearningSafeTarget(element) {
    if (!(element instanceof Element)
      || element === document.documentElement
      || element === document.body
      || ["html", "body", "main", "article", "h1", "h2", "h3", "h4", "h5", "h6", "video", "audio"].includes(element.localName)
      || element.matches("[role='main'], [itemprop='articleBody']")
      || isPageContentContainer(element, true)) {
      return false;
    }

    const textLength = (element.textContent || "").trim().length;
    return textLength <= 2400;
  }

  function isAdvertisingFrame(frame) {
    if (!(frame instanceof Element) || frame.localName !== "iframe") return false;
    const policy = globalThis.ScutumADPopupPolicy;
    const url = policy?.http(frame.getAttribute("src") || frame.src, location.href);
    return Boolean(url && (policy.isBlockedAdUrl(url.href)
      || ["doubleclick.net", "googlesyndication.com", "adservice.google.com", "track.adform.net", "adserver.com"]
        .some(host => policy.matchesHost(policy.hostname(url), host))
      || (policy.isStreamingUrl(location.href) && /\/getbanner\.php$/i.test(url.pathname))));
  }

  function isBannerContainer(element, learned) {
    if (!element.matches(".adv-ad, #adbtm")) return false;
    const frames = [...element.querySelectorAll("iframe")];
    if (!frames.length || !frames.every(frame => isAdvertisingFrame(frame)
        && (!learned || frame.classList.contains(LEARNED_HIDDEN_CLASS)))) return false;
    // Cajas observadas: banner(s), scripts y un cierre. Ante un vídeo,
    // noticia, enlace o contenido desconocido se conserva el contenedor.
    const allowed = node => {
      if (!(node instanceof Element)) return node.nodeType !== Node.TEXT_NODE || !node.textContent.trim();
      if (node.matches("iframe")) return isAdvertisingFrame(node);
      if (node.matches("style,script,template")) return true;
      if (node.matches("a.close") && !node.hasAttribute("href") && /^(?:x|×)$/i.test(node.textContent.trim())) return true;
      if (node.matches("img#xa2") && /\/img\/x\.gif(?:[?#]|$)/i.test(node.getAttribute("src") || "")) return true;
      return node.localName === "div" && [...node.childNodes].every(allowed);
    };
    return [...element.childNodes].every(allowed) && !isPageContentContainer(element);
  }

  function inspectBannerContainers(node, learned) {
    // Los contenedores de banners no aprendidos se ocultan con filtros
    // cosméticos (filters/scutumad.txt); aquí solo se aplican las reglas aprendidas.
    if (!learned) return;
    const containers = new Set(node.querySelectorAll(".adv-ad, #adbtm"));
    for (let parent = node; parent; parent = parent.parentElement) {
      if (parent.matches(".adv-ad, #adbtm")) containers.add(parent);
    }
    containers.forEach(element => {
      if (isBannerContainer(element, learned)) hideLearnedElement(element);
    });
  }

  function eventIsLearningInterface(event) {
    const path = event.composedPath?.() || [];
    return path.includes(learningHost)
      || (event.target instanceof Node && learningHost?.contains(event.target));
  }

  function panelQuery(selector) {
    return learningShadow?.querySelector(selector) || null;
  }

  function setLearningMessage(message) {
    learningMessage = message || "";
    const element = panelQuery("#scutumad-learning-message");
    if (element) {
      element.textContent = learningMessage;
    }
  }

  function currentLearnedRuleCount() {
    return learnedRulesForCurrentHost().length;
  }

  function updateLearningPanel(message) {
    if (!learningShadow) {
      return;
    }
    if (message !== undefined) {
      setLearningMessage(message);
    }
    const panel = panelQuery(".panel");
    const count = panelQuery("#scutumad-learning-count");
    const pickButton = panelQuery("#scutumad-learning-pick");
    const blockButton = panelQuery("#scutumad-learning-block");
    const ignoreButton = panelQuery("#scutumad-learning-ignore");
    const cancelButton = panelQuery("#scutumad-learning-cancel");
    const widerButton = panelQuery("#scutumad-learning-wider");
    const narrowerButton = panelQuery("#scutumad-learning-narrower");
    const zapButton = panelQuery("#scutumad-learning-zap");
    const filterPreview = panelQuery("#scutumad-learning-filter");
    // Ampliar/Reducir y la vista previa solo sirven con un elemento de este
    // marco; una selección de otro marco se confirma tal cual.
    const localCandidate = Boolean(learningCandidate) && !learningPickerActive;
    if (widerButton) {
      const parent = learningCandidate?.parentElement;
      widerButton.hidden = !localCandidate;
      widerButton.disabled = !parent || !isLearningSafeTarget(parent);
    }
    if (narrowerButton) {
      narrowerButton.hidden = !localCandidate;
      narrowerButton.disabled = !candidateHistory.length;
    }
    if (zapButton) zapButton.hidden = !localCandidate;
    if (filterPreview) {
      const selector = localCandidate ? buildLearnedSelector(learningCandidate) : "";
      filterPreview.hidden = !localCandidate;
      filterPreview.textContent = selector ? `${getHostname()}##${selector}` : "No hay un filtro seguro para este elemento.";
    }
    const ruleCount = currentLearnedRuleCount();
    if (count) {
      count.textContent = String(ruleCount);
      count.title = `${ruleCount} regla${ruleCount === 1 ? "" : "s"} local${ruleCount === 1 ? "" : "es"} en este sitio`;
    }
    if (pickButton) {
      pickButton.textContent = learningPickerActive ? "Seleccionando…" : "Seleccionar";
      pickButton.hidden = learningPickerActive;
    }
    if (blockButton) {
      blockButton.hidden = (!learningCandidate && !remoteSelection) || learningPickerActive;
    }
    if (ignoreButton) {
      ignoreButton.hidden = (!learningCandidate && !remoteSelection) || learningPickerActive;
    }
    if (cancelButton) {
      cancelButton.hidden = !learningPickerActive;
    }
    panel?.classList.toggle("has-message", Boolean(learningMessage));
    panel?.classList.toggle("is-picking", learningPickerActive);
  }

  function clearLearningCandidate() {
    learningCandidate?.classList.remove(LEARNING_CANDIDATE_CLASS);
    learningCandidate = null;
    remoteSelection = null;
    candidateHistory.length = 0;
  }

  function showLearningMessage(message, duration = 0) {
    clearTimeout(learningMessageTimer);
    learningMessageTimer = null;
    updateLearningPanel(message);
    if (duration > 0) {
      learningMessageTimer = window.setTimeout(() => {
        learningMessageTimer = null;
        if (!learningCandidate && !learningPickerActive) {
          updateLearningPanel("");
        }
      }, duration);
    }
  }

  function ensureLearningPanel() {
    if (learningHost?.isConnected) {
      return;
    }

    const root = document.documentElement || document.body;
    if (!root) {
      return;
    }
    learningHost = document.createElement("div");
    learningHost.id = LEARNING_HOST_ID;
    learningHost.style.position = "fixed";
    learningHost.style.right = "16px";
    learningHost.style.bottom = "16px";
    learningHost.style.zIndex = "2147483647";
    learningHost.style.fontFamily = "system-ui, -apple-system, sans-serif";
    // La capa superior evita que un anuncio con z-index máximo tape la guía.
    // Una sola guía en el documento superior también cubre marcos anidados.
    learningHost.setAttribute("popover", "manual");
    learningHost.style.inset = "auto 16px 16px auto";
    learningHost.style.margin = "0";
    learningHost.style.padding = "0";
    learningHost.style.border = "0";
    learningHost.style.background = "transparent";
    learningHost.style.overflow = "visible";
    learningShadow = learningHost.attachShadow({ mode: "open" });
    learningShadow.innerHTML = `
      <style>
        :host { all: initial; }
        .panel { width: max-content; min-width: 112px; max-width: 236px; padding: 6px 8px; border: 1px solid rgba(255,255,255,.16); border-radius: 999px; background: #101722; color: #edf2f8; box-shadow: 0 8px 24px rgba(0,0,0,.28); font: 12px/1.3 system-ui, sans-serif; transition: border-radius .12s ease, box-shadow .12s ease, border-color .12s ease; }
        .panel.has-message { width: 220px; border-radius: 12px; box-shadow: 0 10px 28px rgba(0,0,0,.32); }
        .panel.is-picking { border-color: #5ba5ff; }
        .header { display: flex; align-items: center; gap: 6px; min-height: 22px; }
        strong { font-size: 11px; white-space: nowrap; }
        .count { min-width: 16px; color: #9cabc0; font-size: 10px; text-align: center; }
        p { display: none; margin: 7px 2px 8px; color: #bac5d4; font-size: 10px; }
        .has-message p { display: block; }
        .actions { display: flex; flex-wrap: wrap; gap: 5px; }
        button { padding: 5px 7px; border: 1px solid rgba(255,255,255,.15); border-radius: 7px; background: #1c2939; color: #f4f7fb; cursor: pointer; font: 10px system-ui, sans-serif; }
        button:hover { background: #293b53; }
        #scutumad-learning-block { border-color: #e84b6e; background: #6f1832; }
        #scutumad-learning-ignore, #scutumad-learning-cancel { background: transparent; }
        code { display: block; margin: 0 2px 7px; padding: 4px 6px; border-radius: 6px; background: #0a0f17; color: #9fc9ff; font: 10px/1.35 ui-monospace, monospace; word-break: break-all; }
        .close { margin-left: auto; width: 18px; height: 18px; padding: 0; border: 0; border-radius: 50%; background: transparent; color: #8e9bae; font-size: 14px; line-height: 16px; }
        .close:hover { background: rgba(255,255,255,.12); }
      </style>
      <div class="panel" role="dialog" aria-label="Aprendizaje local de ScutumAD">
        <div class="header">
          <strong>Aprender</strong>
          <span id="scutumad-learning-count" aria-label="Reglas locales">0</span>
          <button class="close" id="scutumad-learning-close" type="button" title="Cerrar guía" aria-label="Cerrar guía">×</button>
        </div>
        <p id="scutumad-learning-message"></p>
        <code id="scutumad-learning-filter" hidden></code>
        <div class="actions">
          <button id="scutumad-learning-pick" type="button" title="Seleccionar un elemento de la página">Seleccionar</button>
          <button id="scutumad-learning-block" type="button" hidden>Bloquear elemento</button>
          <button id="scutumad-learning-wider" type="button" hidden title="Seleccionar el bloque que lo contiene">Ampliar</button>
          <button id="scutumad-learning-narrower" type="button" hidden title="Volver al bloque anterior">Reducir</button>
          <button id="scutumad-learning-zap" type="button" hidden title="Quitarlo sin guardar ninguna regla">Quitar solo ahora</button>
          <button id="scutumad-learning-ignore" type="button" hidden>No es publicidad</button>
          <button id="scutumad-learning-cancel" type="button" hidden>Cancelar</button>
        </div>
      </div>
    `;
    root.appendChild(learningHost);

    panelQuery("#scutumad-learning-pick")?.addEventListener("click", () => {
      learningPickerActive = true;
      clearLearningCandidate();
      showLearningMessage("Mueve el cursor sobre el anuncio y haz clic para seleccionarlo.");
      void coordinatePicker(true);
    });
    panelQuery("#scutumad-learning-block")?.addEventListener("click", () => {
      void saveLearningCandidate();
    });
    panelQuery("#scutumad-learning-wider")?.addEventListener("click", () => {
      const parent = learningCandidate?.parentElement;
      if (!parent || !isLearningSafeTarget(parent)) return;
      candidateHistory.push(learningCandidate);
      setLearningCandidate(parent, "Bloque ampliado. Revisa el filtro antes de bloquear.", true);
    });
    panelQuery("#scutumad-learning-narrower")?.addEventListener("click", () => {
      const previous = candidateHistory.pop();
      if (previous?.isConnected) setLearningCandidate(previous, "Bloque reducido.", true);
      else updateLearningPanel();
    });
    panelQuery("#scutumad-learning-zap")?.addEventListener("click", () => {
      // Se oculta solo en esta visita: no se guarda ninguna regla.
      const element = learningCandidate;
      clearLearningCandidate();
      element?.style.setProperty("display", "none", "important");
      void coordinatePicker(false);
      showLearningMessage("Quitado hasta que recargues la página. No se ha guardado ninguna regla.", 3000);
    });
    panelQuery("#scutumad-learning-ignore")?.addEventListener("click", () => {
      if (learningCandidate) {
        ignoredLearningElements.add(learningCandidate);
      }
      clearLearningCandidate();
      void coordinatePicker(false);
      showLearningMessage("No se bloqueará ese elemento durante esta visita.", 2600);
    });
    panelQuery("#scutumad-learning-cancel")?.addEventListener("click", () => {
      learningPickerActive = false;
      clearLearningCandidate();
      void coordinatePicker(false);
      showLearningMessage("Selección cancelada.", 2200);
    });
    panelQuery("#scutumad-learning-close")?.addEventListener("click", () => {
      guideDismissed = true;
      learningHost.hidePopover?.();
      learningHost.hidden = true;
      learningPickerActive = false;
      clearLearningCandidate();
      void coordinatePicker(false);
      showLearningMessage("");
    });
  }

  // keepHistory: el cambio viene de Ampliar/Reducir y conserva el recorrido.
  function setLearningCandidate(element, message = "Elemento seleccionado. Pulsa «Bloquear elemento» para ocultarlo.", keepHistory = false) {
    if (!isLearningSafeTarget(element) || ignoredLearningElements.has(element)) {
      return;
    }
    if (!keepHistory) candidateHistory.length = 0;
    if (learningCandidate && learningCandidate !== element) {
      learningCandidate.classList.remove(LEARNING_CANDIDATE_CLASS);
    }
    learningCandidate = element;
    learningCandidate.classList.add(LEARNING_CANDIDATE_CLASS);
    showLearningMessage(message);
  }

  function learningCandidateFromTarget(target) {
    if (!(target instanceof Element) || eventIsLearningInterface({ composedPath: () => [target] })) {
      return null;
    }
    try {
      const candidate = target.closest(LEARNING_CANDIDATE_SELECTOR_TEXT);
      return candidate && isLearningSafeTarget(candidate) ? candidate : null;
    } catch {
      return null;
    }
  }

  function learningTargetFromTarget(target) {
    const knownCandidate = learningCandidateFromTarget(target);
    if (knownCandidate) {
      return knownCandidate;
    }
    if (!(target instanceof Element)) {
      return null;
    }
    const dialog = target.closest("dialog,[role='dialog']");
    if (dialog) return isLearningSafeTarget(dialog) ? dialog : null;

    const inlineTags = new Set([
      "a", "b", "button", "em", "i", "img", "input", "label", "option",
      "select", "small", "span", "strong", "svg", "textarea"
    ]);
    let fallback = null;
    let current = target;
    let depth = 0;
    while (current && current !== document.body && depth < 7) {
      if (isLearningSafeTarget(current)) {
        const rect = current.getBoundingClientRect?.();
        if (!rect || (rect.width >= 24 && rect.height >= 12)) {
          fallback ||= current;
          if (!inlineTags.has(current.localName) || current.children.length > 0) {
            return current;
          }
        }
      }
      current = current.parentElement;
      depth += 1;
    }
    return fallback;
  }

  function cancelLearningPicker(message = "Selección cancelada.") {
    learningPickerActive = false;
    clearLearningCandidate();
    showLearningMessage(message, 2200);
    if (ownsLearningGuide || isTopFrame()) void coordinatePicker(false);
  }

  function handleLearningPointerOver(event) {
    if (!settings.learningEnabled || (!ownsLearningGuide && !learningPickerActive) || eventIsLearningInterface(event)) {
      return;
    }
    const candidate = learningPickerActive
      ? learningTargetFromTarget(event.target)
      : learningCandidateFromTarget(event.target);
    if (candidate) {
      setLearningCandidate(candidate, learningPickerActive
        ? "Este bloque está bajo el cursor. Haz clic para seleccionarlo."
        : "Elemento detectado. Pulsa «Bloquear elemento» para ocultarlo.");
    } else if (learningPickerActive && learningCandidate) {
      clearLearningCandidate();
      showLearningMessage("Coloca el cursor sobre un bloque concreto de la página.");
    }
  }

  function handleLearningClick(event) {
    if (!settings.learningEnabled || !learningPickerActive || eventIsLearningInterface(event)) {
      return;
    }
    const target = event.target instanceof Element ? event.target : null;
    const candidate = learningTargetFromTarget(target);
    if (!candidate) {
      event.preventDefault();
      event.stopImmediatePropagation();
      showLearningMessage("Ese bloque es demasiado amplio. Elige el banner o marco concreto.");
      return;
    }
    event.preventDefault();
    event.stopImmediatePropagation();
    learningPickerActive = false;
    setLearningCandidate(candidate, "Elemento seleccionado. Pulsa «Bloquear elemento» para ocultarlo.");
    const selector = buildLearnedSelector(candidate);
    if (!selector) {
      showLearningMessage("No se puede crear una regla segura para ese bloque. Selecciona el banner completo.");
      return;
    }
    void chrome.runtime.sendMessage({ type: "LEARNING_SELECTED", selector }).then(result => {
      if (!result?.ok && isTopFrame()) showLearningMessage("No se pudo seleccionar el marco. Pulsa «Seleccionar» de nuevo.");
    }).catch(() => {});
  }

  function handleLearningKeydown(event) {
    if (event.key === "Escape" && learningPickerActive) {
      event.preventDefault();
      event.stopImmediatePropagation();
      cancelLearningPicker();
    }
  }

  async function saveLearningCandidate() {
    if (!learningCandidate && !remoteSelection) {
      return;
    }
    const selector = learningCandidate && buildLearnedSelector(learningCandidate);
    if (!selector && !remoteSelection) {
      setLearningMessage("No se ha podido crear una regla segura para ese elemento.");
      return;
    }

    try {
      const result = await chrome.runtime.sendMessage(remoteSelection
        ? { type: "LEARN_RULE", selectionToken: remoteSelection.selectionToken }
        : { type: "LEARN_RULE", selector });
      if (!result?.ok) {
        setLearningMessage(result?.error || "No se pudo guardar la regla local.");
        return;
      }
      settings.learnedRules = Array.isArray(result.learnedRules) ? result.learnedRules : settings.learnedRules;
      clearLearningCandidate();
      startLearnedRules();
      showLearningMessage(result.duplicate
        ? "La regla ya estaba guardada en este dispositivo."
        : "Regla guardada solo en este dispositivo.", 3000);
    } catch {
      setLearningMessage("No se pudo guardar la regla local.");
    }
  }

  function startLearningMode() {
    installLearningStyle();
    if (ownsLearningGuide) {
      ensureLearningPanel();
      showLearningGuide();
      updateLearningPanel();
    }
    document.addEventListener("pointerover", handleLearningPointerOver, true);
    document.addEventListener("click", handleLearningClick, true);
    document.addEventListener("keydown", handleLearningKeydown, true);
    if (!guideModalObserver) {
      guideModalObserver = new MutationObserver(records => {
        if (records.some(record => record.target.localName === "dialog")) showLearningGuide();
      });
      guideModalObserver.observe(document.documentElement, {subtree:true,attributes:true,attributeFilter:["open"]});
    }
  }

  async function coordinatePicker(enabled) {
    setLearningPickState(enabled);
    try {
      const result = await chrome.runtime.sendMessage({ type: "LEARNING_PICKER", enabled });
      if (!result?.ok && enabled) cancelLearningPicker("No se pudo iniciar la selección. Recarga ScutumAD y esta página.");
    } catch {
      learningPickerActive = false;
      setLearningPickState(false);
      showLearningMessage("Recarga ScutumAD y esta página para recuperar la selección.");
    }
  }

  function showLearningGuide() {
    if (!learningHost || guideDismissed) return;
    learningHost.hidden = false;
    try {
      const modal = document.querySelector("dialog:modal");
      const fullscreen = document.fullscreenElement;
      const parent = modal || (fullscreen && !fullscreen.matches("iframe,video,audio") ? fullscreen : document.documentElement);
      if (learningHost.parentElement !== parent) parent.appendChild(learningHost);
      learningHost.hidePopover?.();
      learningHost.showPopover?.();
    } catch { /* El z-index sirve de respaldo en Chromium sin popover. */ }
  }
  document.addEventListener("fullscreenchange", () => {
    if (!settings.learningEnabled) return;
    const fullscreen = document.fullscreenElement;
    void chrome.runtime.sendMessage({ type: "LEARNING_GUIDE_UPDATE", fullscreenActive: Boolean(fullscreen),
      childUrl: fullscreen?.localName === "iframe" ? fullscreen.src : null }).catch(() => {});
  });
  // Si una web abre un diálogo modal después de la guía, volver a situarla
  // en la capa superior. No se cambia el diálogo ni su contenido.
  document.addEventListener("toggle", event => {
    if (event.target !== learningHost && (event.newState === "open" || event.target?.localName === "dialog")) showLearningGuide();
  }, true);

  function stopLearningMode() {
    guideModalObserver?.disconnect(); guideModalObserver = null;
    setLearningPickState(false);
    document.removeEventListener("pointerover", handleLearningPointerOver, true);
    document.removeEventListener("click", handleLearningClick, true);
    document.removeEventListener("keydown", handleLearningKeydown, true);
    clearTimeout(learningMessageTimer);
    learningMessageTimer = null;
    learningMessage = "";
    learningPickerActive = false;
    clearLearningCandidate();
    learningHost?.remove();
    learningHost = null;
    learningShadow = null;
    guideDismissed = false;
    if (!learnedObserver) {
      document.getElementById(LEARNING_STYLE_ID)?.remove();
    }
  }

  // Ocultación cosmética de las listas: el worker devuelve solo el CSS que
  // corresponde a este marco y Chrome lo aplica sin recorrer el DOM.
  function isSameOriginAsTop() {
    try {
      return window.top === window.self || window.top.location.origin === location.origin;
    } catch {
      return false;
    }
  }

  function removeCosmeticStyle() {
    document.getElementById(COSMETIC_STYLE_ID)?.remove();
  }

  function applyCosmeticFilters(enabled) {
    const signature = enabled ? `${settings.blockAds}|${settings.blockAnnoyances}` : "";
    if (signature === cosmeticSignature) return;
    cosmeticSignature = signature;
    const request = ++cosmeticRequest;
    if (!signature) {
      removeCosmeticStyle();
      return;
    }
    // Los genéricos se aplican en la página y sus marcos del mismo origen;
    // los marcos publicitarios de terceros ya los corta el bloqueo de red.
    chrome.runtime.sendMessage({ type: "GET_COSMETIC", includeGeneric: isSameOriginAsTop() })
      .then((result) => {
        if (request !== cosmeticRequest) return;
        if (!result?.css) {
          removeCosmeticStyle();
          return;
        }
        let style = document.getElementById(COSMETIC_STYLE_ID);
        if (!style) {
          style = document.createElement("style");
          style.id = COSMETIC_STYLE_ID;
        }
        style.textContent = result.css;
        if (!style.isConnected) (document.documentElement || document).appendChild(style);
      })
      .catch(() => {});
  }

  function applySettings(nextSettings) {
    settings = {
      ...DEFAULT_SETTINGS,
      ...nextSettings,
      whitelist: Array.isArray(nextSettings?.whitelist) ? nextSettings.whitelist : [],
      learnedRules: Array.isArray(nextSettings?.learnedRules) ? nextSettings.learnedRules.map(rule => {
        if (rule.action === "block-popup") return rule;
        const normalized = globalThis.ScutumADLearningPolicy.normalizeSelector(rule.selector);
        return { ...rule, selector: normalized?.selector || "", disabled: rule.disabled || !normalized || normalized.disabled };
      }) : []
    };

    const allowedHere = isWhitelisted();
    const generalEnabled = settings.protectionEnabled
      && (settings.blockAds || settings.blockAnnoyances)
      && !allowedHere
      && currentSiteMode() !== "basic";
    const youtubeEnabled = settings.protectionEnabled && settings.youtubeProtection && !allowedHere;
    const learningEnabled = settings.protectionEnabled && settings.learningEnabled && !allowedHere;

    sendToMain("popunder", {
      type: "state",
      enabled: settings.protectionEnabled && (settings.blockAds || settings.blockAnnoyances || settings.learnedRules.length) && !allowedHere,
      strict: settings.protectionEnabled && currentSiteMode() === "strict",
      blockedPopupDomains: globalThis.ScutumADPopupPolicy?.learnedPopupDomains(settings.learnedRules,
        [location.href, ...Array.from(location.ancestorOrigins || [])]) || []
    });

    if (settings.protectionEnabled && !allowedHere) {
      startLearnedRules();
    } else {
      stopLearnedRules();
    }

    if (learningEnabled) {
      startLearningMode();
    } else {
      stopLearningMode();
    }

    if (isYouTube()) {
      sendToMain("youtube", { type: "state", enabled: youtubeEnabled });
    }

    // Solo se vuelve a pedir el CSS si cambia lo que lo afecta: guardar una
    // regla o tocar otro ajuste no recarga los estilos de todas las pestañas.
    applyCosmeticFilters(!isYouTube() && generalEnabled);

    if (isYouTube() && youtubeEnabled && globalThis.ScutumADYouTube) {
      globalThis.ScutumADYouTube.start();
    } else {
      globalThis.ScutumADYouTube?.stop();
    }
  }

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local") {
      return;
    }

    if (SETTINGS_KEYS.some((key) => key in changes)) {
      chrome.storage.local.get(DEFAULT_SETTINGS).then(applySettings).catch(() => {});
    }
  });

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type === "LEARNING_GUIDE_PROBE") {
      const fullscreen = document.fullscreenElement;
      sendResponse({ fullscreenActive: Boolean(fullscreen), childUrl: fullscreen?.localName === "iframe" ? fullscreen.src : null });
      return false;
    }
    if (message?.type === "LEARNING_GUIDE_OWNER") {
      ownsLearningGuide = message.visible === true;
      if (ownsLearningGuide && settings.learningEnabled && settings.protectionEnabled && !isWhitelisted()) {
        ensureLearningPanel(); showLearningGuide(); updateLearningPanel();
      } else {
        learningHost?.remove(); learningHost = null; learningShadow = null;
      }
      sendResponse({ ok: true }); return false;
    }
    if (message?.type === "LEARNING_PICK_MODE") {
      if (settings.learningEnabled && !isWhitelisted()) {
        learningPickerActive = message.enabled === true;
        setLearningPickState(learningPickerActive);
        clearLearningCandidate();
        updateLearningPanel();
      }
      sendResponse({ ok: true });
      return false;
    }
    if (message?.type === "LEARNING_SELECTION" && ownsLearningGuide) {
      learningPickerActive = false;
      remoteSelection = message;
      showLearningMessage(message.frameDomain
        ? "Banner del reproductor seleccionado. Pulsa «Bloquear elemento» para guardarlo."
        : "Elemento seleccionado. Pulsa «Bloquear elemento» para guardarlo.");
      showLearningGuide();
      sendResponse({ ok: true });
      return false;
    }
    if (message?.type !== "START_LEARNING_PICKER") {
      return false;
    }

    if (!settings.learningEnabled || isWhitelisted() || !isTopFrame()) {
      sendResponse({ ok: false, error: "Activa el modo aprendizaje y no uses la lista blanca en este sitio." });
      return false;
    }
    ensureLearningPanel();
    learningHost && (learningHost.hidden = false);
    learningPickerActive = true;
    guideDismissed = false;
    clearLearningCandidate();
    showLearningMessage("Mueve el cursor sobre el anuncio y haz clic para seleccionarlo.");
    showLearningGuide();
    void coordinatePicker(true);
    sendResponse({ ok: true });
    return false;
  });

  chrome.storage.local.get(DEFAULT_SETTINGS).then(applySettings).catch(() => {});
})();
