(() => {
  const themeQuery = window.matchMedia("(prefers-color-scheme: dark)");
  const iconUrl = chrome.runtime.getURL("icons/icon128.png");
  const iconSizes = [16, 32, 48, 128];
  let sourceImagePromise = null;

  function loadSourceImage() {
    if (!sourceImagePromise) {
      sourceImagePromise = new Promise((resolve, reject) => {
        const image = new Image();
        image.onload = () => resolve(image);
        image.onerror = reject;
        image.src = iconUrl;
      });
    }
    return sourceImagePromise;
  }

  async function sendThemeIcon() {
    try {
      const image = await loadSourceImage();
      const useLightPalette = themeQuery.matches;
      const iconPixels = {};

      iconSizes.forEach((size) => {
        const canvas = document.createElement("canvas");
        canvas.width = size;
        canvas.height = size;
        const context = canvas.getContext("2d", { willReadFrequently: true });
        context.imageSmoothingEnabled = true;
        context.imageSmoothingQuality = "high";
        context.filter = useLightPalette ? "invert(1) hue-rotate(180deg)" : "none";
        context.drawImage(image, 0, 0, size, size);
        iconPixels[String(size)] = Array.from(context.getImageData(0, 0, size, size).data);
      });

      await chrome.runtime.sendMessage({ type: "APPLY_THEME_ICON", iconPixels });
    } catch {
      // El icono declarado en manifest.json permanece como respaldo.
    }
  }

  const onThemeChange = () => { void sendThemeIcon(); };
  if (typeof themeQuery.addEventListener === "function") {
    themeQuery.addEventListener("change", onThemeChange);
  } else {
    themeQuery.addListener(onThemeChange);
  }

  void sendThemeIcon();
})();
