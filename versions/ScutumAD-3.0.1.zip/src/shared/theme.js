(() => {
  const themeQuery = window.matchMedia("(prefers-color-scheme: dark)");
  const iconUrl = chrome.runtime.getURL("icons/icon128.png");
  const iconSizes = [16, 32, 48, 128];
  let imagePromise = null;

  function loadIcon() {
    if (!imagePromise) {
      imagePromise = new Promise((resolve, reject) => {
        const image = new Image();
        image.onload = () => resolve(image);
        image.onerror = reject;
        image.src = iconUrl;
      });
    }
    return imagePromise;
  }

  async function syncActionIcon() {
    if (!chrome.action?.setIcon) {
      return;
    }

    try {
      const image = await loadIcon();
      const useLightPalette = themeQuery.matches;
      const imageData = {};

      iconSizes.forEach((size) => {
        const canvas = document.createElement("canvas");
        canvas.width = size;
        canvas.height = size;
        const context = canvas.getContext("2d");
        context.imageSmoothingEnabled = true;
        context.imageSmoothingQuality = "high";
        context.filter = useLightPalette ? "invert(1) hue-rotate(180deg)" : "none";
        context.drawImage(image, 0, 0, size, size);
        imageData[size] = context.getImageData(0, 0, size, size);
      });

      await chrome.action.setIcon({ imageData });
    } catch {
      // El icono declarado en manifest.json sigue siendo el respaldo seguro.
    }
  }

  const onThemeChange = () => { void syncActionIcon(); };
  if (typeof themeQuery.addEventListener === "function") {
    themeQuery.addEventListener("change", onThemeChange);
  } else {
    themeQuery.addListener(onThemeChange);
  }

  void syncActionIcon();
})();
