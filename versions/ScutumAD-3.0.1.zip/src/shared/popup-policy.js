// Política propia compartida por los dos mundos de Chrome y el worker local.
(() => {
  const streamingHosts = ["emb.apl601.online", "emb.apl602.online", "epiembeds.online", "abisnews.com", "livetv.sx", "livetv903.me", "livetv904.me"];
  const playerHosts = streamingHosts.slice(0, 3);
  const adHosts = ["fluxbrox.com", "ad.apl601.online", "ad.apl602.online", "ads.livetv903.me", "ads.livetv904.me", "diligenceshaped.com"];
  const matchesHost = (host, domain) => host === domain || host.endsWith(`.${domain}`);
  function parse(value, base) {
    try { return new URL(value, base); } catch { return null; }
  }
  function http(value, base) {
    const url = parse(value, base);
    return url && /^https?:$/.test(url.protocol) ? url : null;
  }
  const hostname = (url) => url?.hostname.toLowerCase().replace(/\.$/, "") || "";
  function isStreamingUrl(value) {
    return streamingHosts.some((host) => matchesHost(hostname(http(value)), host));
  }
  function isPlayerUrl(value) {
    const url = http(value);
    return Boolean(url && (playerHosts.some((host) => matchesHost(hostname(url), host))
      || /\/(?:embed|player|webplayer)(?:\/|\d*\.php(?:\/|$)|$)/i.test(url.pathname)));
  }
  function isBlockedAdUrl(value, base) {
    const url = http(value, base);
    if (!url) return false;
    return adHosts.some((host) => matchesHost(hostname(url), host))
      || (matchesHost(hostname(url), "tonybet.es") && url.pathname.startsWith("/registration")
        && ["clickid", "partner_id", "rdr", "utm_source", "utm_medium", "utm_campaign", "utm_term"]
          .some((key) => url.searchParams.has(key)));
  }
  function isTrustedDestination(value, source) {
    const destination = http(value, source);
    const origin = http(source);
    return Boolean(destination && !isBlockedAdUrl(destination.href)
      && (destination.origin === origin?.origin || isStreamingUrl(destination.href)));
  }
  function isBlockedPopupUrl(value, source, domains = []) {
    const host = hostname(http(value, source));
    return Boolean(host && domains.some(domain => typeof domain === "string" && matchesHost(host, domain)));
  }
  function learnedPopupDomains(rules, sources) {
    const hosts = sources.map(value => hostname(http(value))).filter(Boolean);
    return (Array.isArray(rules) ? rules : []).filter(rule => rule.action === "block-popup" && !rule.disabled && hosts.includes(rule.domain))
      .map(rule => rule.destinationDomain).filter(domain => typeof domain === "string");
  }
  function hasExplicitLink(anchor) {
    return Boolean(anchor && ((anchor.textContent || "").trim()
      || anchor.getAttribute?.("aria-label")?.trim() || anchor.getAttribute?.("title")?.trim()
      || anchor.querySelector?.("img[alt]:not([alt='']),svg[aria-label]")));
  }
  globalThis.ScutumADPopupPolicy = Object.freeze({ http, hostname, matchesHost,
    isStreamingUrl, isPlayerUrl, isBlockedAdUrl, isTrustedDestination,
    isBlockedPopupUrl, learnedPopupDomains, hasExplicitLink });
})();
