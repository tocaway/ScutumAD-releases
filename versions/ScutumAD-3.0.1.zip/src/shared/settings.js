// Ajustes por defecto compartidos por el worker, los content scripts y la
// página de configuración.
(() => {
  const DEFAULT_SETTINGS = Object.freeze({
    protectionEnabled: true,
    blockAds: true,
    blockTrackers: true,
    youtubeProtection: true,
    blockAnnoyances: true,
    blockMalware: true,
    learningEnabled: false,
    // Descarga y compila las listas de filtros cada 6 horas.
    autoUpdateLists: true,
    // Modo sigiloso: que las webs no detecten el bloqueador.
    stealthMode: true,
    learnedRules: [],
    whitelist: [],
    // Modo por sitio distinto del predeterminado (Óptimo). El modo
    // Desactivado se guarda en whitelist.
    siteModes: {}
  });
  // off: sin protección · basic: solo red · optimal: red, ocultación y
  // scriptlets · strict: además, cortafuegos de pop-ups estricto.
  const SITE_MODES = Object.freeze(["off", "basic", "optimal", "strict"]);

  function hostMatches(hostname, domain) {
    return hostname === domain || hostname.endsWith(`.${domain}`);
  }

  // Devuelve el modo del primer host que tenga uno: el dominio más concreto
  // gana, y la lista blanca (off) tiene prioridad.
  function siteModeFor(hostnames, settings) {
    const hosts = hostnames.filter(Boolean).map((host) => host.toLowerCase().replace(/\.$/, ""));
    const whitelist = Array.isArray(settings?.whitelist) ? settings.whitelist : [];
    if (hosts.some((host) => whitelist.some((domain) => hostMatches(host, domain)))) return "off";
    const modes = settings?.siteModes && typeof settings.siteModes === "object" ? settings.siteModes : {};
    for (const host of hosts) {
      const match = Object.keys(modes)
        .filter((domain) => hostMatches(host, domain) && SITE_MODES.includes(modes[domain]))
        .sort((a, b) => b.length - a.length)[0];
      if (match) return modes[match];
    }
    return "optimal";
  }
  globalThis.ScutumADSettings = Object.freeze({
    DEFAULT_SETTINGS,
    KEYS: Object.freeze(Object.keys(DEFAULT_SETTINGS)),
    SITE_MODES,
    siteModeFor
  });
})();
