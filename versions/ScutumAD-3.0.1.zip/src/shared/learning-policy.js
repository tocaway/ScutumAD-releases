// Validación local compartida. Nunca usa clases que ScutumAD añade al DOM.
(() => {
  const internalClass = /\.scutumad-(?:learning-candidate|learned-hidden|youtube-hidden|hidden)(?![a-z0-9_-])/gi;
  const protectedTarget = /^(?:html|body|main|article|h[1-6]|video|audio)(?=[.#\s[:]|$)/i;
  function normalizeSelector(value) {
    if (typeof value !== "string") return null;
    const original = value.trim();
    if (!original || original.length > 700 || /[{};<>]/.test(original)
        || /(?:javascript|data):/i.test(original)) return null;
    // Solo se migran selectores sencillos de las versiones anteriores. No se
    // modifican literales de atributos ni expresiones complejas.
    const contaminated = /\.scutumad-/.test(original);
    const simple = !/[\[\]"',:()]/.test(original);
    const selector = contaminated && simple ? original.replace(internalClass, "") : original;
    const disabled = protectedTarget.test(selector) || /^[a-z][a-z0-9-]*$/i.test(selector)
      || (contaminated && (!simple || selector === original || /^(?:[a-z][a-z0-9-]*)?$/i.test(selector)));
    return { selector, disabled };
  }
  globalThis.ScutumADLearningPolicy = Object.freeze({ normalizeSelector });
})();
