// Listas de filtros que usa ScutumAD. Las comparten el script de publicación
// (scripts/build-rules.mjs) y el actualizador del worker. Licencias en
// licenses/THIRD_PARTY_NOTICES.md.
(() => {
  // category: ruleset y ajuste que la activa. youtubeSafe: quitar de las
  // reglas de bloqueo lo que inicia YouTube (listas no mantenidas para él).
  const FILTER_LISTS = Object.freeze([
    { id: "easylist", title: "EasyList", category: "ads", youtubeSafe: true,
      url: "https://easylist.to/easylist/easylist.txt" },
    { id: "easylistspanish", title: "EasyList Spanish", category: "ads", youtubeSafe: true,
      url: "https://easylist-downloads.adblockplus.org/easylistspanish.txt" },
    { id: "ubo-filters", title: "uBlock filters", category: "ads",
      url: "https://ublockorigin.github.io/uAssets/filters/filters.txt" },
    { id: "ubo-quick-fixes", title: "uBlock filters – Quick fixes", category: "ads",
      url: "https://ublockorigin.github.io/uAssets/filters/quick-fixes.txt" },
    { id: "ubo-unbreak", title: "uBlock filters – Unbreak", category: "ads",
      url: "https://ublockorigin.github.io/uAssets/filters/unbreak.txt" },
    { id: "abp-anticv", title: "ABP Anti-Circumvention", category: "ads",
      url: "https://easylist-downloads.adblockplus.org/abp-filters-anti-cv.txt" },
    { id: "easyprivacy", title: "EasyPrivacy", category: "trackers", youtubeSafe: true,
      url: "https://easylist.to/easylist/easyprivacy.txt" },
    { id: "ubo-privacy", title: "uBlock filters – Privacy", category: "trackers",
      url: "https://ublockorigin.github.io/uAssets/filters/privacy.txt" },
    { id: "newsletters", title: "Fanboy's Newsletter List", category: "annoyances", youtubeSafe: true,
      url: "https://secure.fanboy.co.nz/fanboy-newsletter.txt" },
    { id: "notifications", title: "Fanboy's Notifications Blocking List", category: "annoyances", youtubeSafe: true,
      url: "https://easylist-downloads.adblockplus.org/fanboy-notifications.txt" },
    { id: "ubo-badware", title: "uBlock filters – Badware risks", category: "malware",
      url: "https://ublockorigin.github.io/uAssets/filters/badware.txt" },
    { id: "urlhaus", title: "Online Malicious Domains (urlhaus-filter)", category: "malware", format: "hosts",
      url: "https://malware-filter.gitlab.io/malware-filter/urlhaus-filter-domains-online.txt" },
    { id: "phishing", title: "Phishing Domains (phishing-filter)", category: "malware", format: "hosts",
      url: "https://malware-filter.gitlab.io/malware-filter/phishing-filter-domains.txt" }
  ]);
  // Filtros propios: van en su ruleset (scutumad) y admiten todo.
  const OWN_LIST = Object.freeze({ id: "scutumad", title: "ScutumAD", category: "scutumad", trusted: true });
  // Categorías y el ajuste que las activa.
  const CATEGORY_SETTINGS = Object.freeze({
    ads: "blockAds", scutumad: "blockAds", trackers: "blockTrackers", privacy: "blockTrackers",
    annoyances: "blockAnnoyances", malware: "blockMalware", stealth: "stealthMode"
  });
  globalThis.ScutumADFilterLists = Object.freeze({ FILTER_LISTS, OWN_LIST, CATEGORY_SETTINGS });
})();
