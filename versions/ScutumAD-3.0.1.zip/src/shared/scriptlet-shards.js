// Reparte las reglas de scriptlets en trozos para que Chrome inyecte en cada
// web solo el que le corresponde. Lo usan scripts/build-rules.mjs (archivos
// del paquete) y el worker (scripts de usuario tras actualizar las listas).
(() => {
  const SHARD_COUNT = 32;
  const ENGINE_CALL = "})(RULES_PLACEHOLDER);";

  function keyPattern(key) {
    return /^[a-z0-9.-]+$/.test(key) ? `*://*.${key}/*` : null;
  }

  function hash(text) {
    let value = 0;
    for (let index = 0; index < text.length; index++) value = (value * 31 + text.charCodeAt(index)) >>> 0;
    return value;
  }

  // Las entidades (ejemplo.*) no se pueden expresar como patrón de Chrome:
  // van en un trozo pequeño que se inyecta en todas las webs.
  function shardScriptlets({ rules, exceptions }) {
    const entities = {};
    const buckets = Array.from({ length: SHARD_COUNT }, () => ({}));
    for (const [key, list] of Object.entries(rules)) {
      if (key.endsWith(".*")) entities[key] = list;
      else if (keyPattern(key)) buckets[hash(key) % SHARD_COUNT][key] = list;
    }
    const shards = [];
    if (Object.keys(entities).length) {
      shards.push({ id: "entities", matches: ["*://*/*"], data: { rules: entities, exceptions } });
    }
    buckets.forEach((bucket, index) => {
      const keys = Object.keys(bucket);
      if (keys.length) {
        shards.push({ id: String(index).padStart(2, "0"), matches: keys.map(keyPattern), data: { rules: bucket, exceptions } });
      }
    });
    return shards;
  }

  function shardCode(engine, data) {
    if (!engine.includes(ENGINE_CALL)) throw new Error("engine.js sin la llamada final con RULES_PLACEHOLDER");
    return engine.replace(ENGINE_CALL, () => `})(${JSON.stringify(data)});`);
  }

  globalThis.ScutumADScriptletShards = Object.freeze({ shardScriptlets, shardCode });
})();
