// Compilador de listas de filtros (sintaxis Adblock Plus y uBlock Origin) a
// reglas declarativeNetRequest, CSS cosmético y scriptlets. Lo usan
// scripts/build-rules.mjs al publicar y el actualizador del worker.
(() => {
  // YouTube bloquea el reproductor si detecta peticiones interceptadas: las
  // reglas de bloqueo nunca actúan sobre lo que inicia YouTube ni sobre sus
  // dominios. Su protección vive en src/youtube/.
  const YOUTUBE_DOMAINS = ["youtube.com", "youtube-nocookie.com", "youtubekids.com"];
  const YOUTUBE_RELATED = /(?:^|[.|/])(?:youtube(?:-nocookie|kids)?\.com|googlevideo\.com|ytimg\.com|ggpht\.com)(?:[/^:|]|$)/;

  // `youtube.*` (entidad uBlock) cuenta como youtube.com.
  function isYoutubeDomain(domain) {
    const host = domain.endsWith(".*") ? `${domain.slice(0, -2)}.com` : domain;
    return YOUTUBE_DOMAINS.some((yt) => host === yt || host.endsWith(`.${yt}`));
  }

  const PRIORITY = { block: 100, redirect: 250, allow: 300, important: 400, importantAllow: 500 };
  // Chrome limita las reglas regex a 1.000 por conjunto.
  const MAX_REGEX_RULES = 900;
  const ALL_TYPES = ["main_frame", "sub_frame", "stylesheet", "script", "image", "font", "object",
    "xmlhttprequest", "ping", "media", "websocket", "other"];
  const TYPE_MAP = {
    script: ["script"], image: ["image"], stylesheet: ["stylesheet"], css: ["stylesheet"],
    object: ["object"], xmlhttprequest: ["xmlhttprequest"], xhr: ["xmlhttprequest"],
    subdocument: ["sub_frame"], frame: ["sub_frame"], ping: ["ping"], beacon: ["ping"],
    media: ["media"], font: ["font"], websocket: ["websocket"], other: ["other"],
    document: ["main_frame"], doc: ["main_frame"], all: ALL_TYPES
  };
  const IGNORED_OPTIONS = new Set(["reason"]);
  const COSMETIC_EXCEPTION_OPTIONS = {
    elemhide: "all", ehide: "all", generichide: "generic", ghide: "generic", specifichide: "specific", shide: "specific"
  };
  // Recursos de uBlock (`$redirect=`) que ScutumAD tiene como sustitutos propios.
  const REDIRECT_RESOURCES = {
    noopjs: "noop.js", "noop.js": "noop.js",
    "1x1.gif": "1x1.gif", "1x1-transparent.gif": "1x1.gif", "2x2.png": "1x1.gif", "2x2-transparent.png": "1x1.gif",
    "3x2.png": "1x1.gif", "3x2-transparent.png": "1x1.gif", "32x32.png": "1x1.gif", "32x32-transparent.png": "1x1.gif",
    nooptext: "noop.txt", "noop.txt": "noop.txt", empty: "noop.txt",
    noopframe: "noop.html", "noop.html": "noop.html",
    "googletagmanager_gtm.js": "gtm.js", "googletagmanager.com/gtm.js": "gtm.js",
    "google-analytics_analytics.js": "analytics.js", "google-analytics.com/analytics.js": "analytics.js",
    "google-analytics.com": "analytics.js",
    "googlesyndication_adsbygoogle.js": "adsbygoogle.js", "googlesyndication.com/adsbygoogle.js": "adsbygoogle.js",
    "googletagservices_gpt.js": "gpt.js", "googletagservices.com/gpt.js": "gpt.js",
    "nobab.js": "nobab.js", "nofab.js": "nobab.js", "fuckadblock.js-3.2.0": "nobab.js", "blockadblock.js": "nobab.js"
  };
  // Scriptlets que entiende src/scriptlets/engine.js (nombres y alias).
  // Mantener sincronizado: tests/scriptlets.mjs lo comprueba.
  const SCRIPTLETS = new Set([
    "abort-on-property-read", "aopr", "abort-on-property-write", "aopw",
    "abort-current-script", "acs", "abort-current-inline-script", "abort-on-stack-trace", "aost",
    "set-constant", "set", "override-property-read",
    "no-setTimeout-if", "nostif", "prevent-setTimeout", "no-setInterval-if", "nosiif", "prevent-setInterval",
    "nano-setTimeout-booster", "nano-stb", "nano-setInterval-booster", "nano-sib",
    "addEventListener-defuser", "aeld", "prevent-addEventListener", "prevent-listener",
    "window.open-defuser", "nowoif", "no-window-open-if", "prevent-window-open",
    "no-fetch-if", "prevent-fetch", "no-xhr-if", "prevent-xhr",
    "json-prune", "json-prune-fetch-response", "json-prune-xhr-response",
    "trusted-replace-fetch-response", "trusted-rpfr", "replace-fetch-response", "trusted-replace-xhr-response",
    "remove-attr", "ra", "remove-class", "rc", "remove-cookie", "cookie-remover",
    "set-local-storage-item", "set-session-storage-item",
    "noeval-if", "noeval", "silent-noeval", "nowebrtc", "nobab", "nofab", "bab-defuser"
  ]);
  const PROCEDURAL = /:-abp-(?!has\()|:has-text\(|:contains\(|:xpath\(|:upward\(|:matches-|:min-text-length|:watch-attr|:others\(|:if\(|:if-not\(|:remove-attr|:remove-class|:spath\(|:shadow\(/;

  function normalizeDomain(value) {
    const raw = String(value || "").trim().toLowerCase().replace(/^\.+|\.+$/g, "");
    if (!raw || /[^a-z0-9.\- -￿]/.test(raw)) return null;
    let domain;
    try {
      domain = new URL(`http://${raw}`).hostname;
    } catch {
      return null;
    }
    return /^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9-]{2,63}$/.test(domain) ? domain : null;
  }

  // Entidad uBlock: "ejemplo.*" (cualquier TLD).
  function normalizeEntity(value) {
    const match = /^([a-z0-9.-]+)\.\*$/.exec(String(value || "").trim().toLowerCase());
    return match && /^[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$/.test(match[1]) ? `${match[1]}.*` : null;
  }

  // droppedInclude: algún dominio positivo no se pudo usar. Si no queda
  // ninguno, el filtro no debe convertirse en global.
  function parseDomainList(value, separator, allowEntities) {
    const include = [];
    const exclude = [];
    let droppedInclude = false;
    for (const raw of value.split(separator)) {
      const item = raw.trim();
      const negated = item.startsWith("~");
      const name = negated ? item.slice(1) : item;
      if (!name) continue;
      const domain = name.endsWith(".*") ? (allowEntities ? normalizeEntity(name) : null) : normalizeDomain(name);
      if (!domain) {
        if (name.endsWith(".*") || name.startsWith("/")) {
          if (!negated) droppedInclude = true;
          continue; // entidad o regex: se ignora ese dominio
        }
        return null;
      }
      (negated ? exclude : include).push(domain);
    }
    if (droppedInclude && !include.length) return null;
    return { include, exclude };
  }

  // urlFilter de DNR: ASCII, `||` solo al inicio y `|` solo en los extremos.
  function validUrlFilter(pattern) {
    if (!/^[\x21-\x7e]+$/.test(pattern) || pattern.startsWith("||*")) return false;
    const body = pattern.replace(/^\|\|?/, "").replace(/\|$/, "");
    return body.length > 0 && !body.includes("|");
  }

  function addTo(map, key, value) {
    if (!map.has(key)) map.set(key, new Set());
    map.get(key).add(value);
  }

  function createCategory() {
    return {
      rules: [],
      groups: new Map(),
      regexCount: 0,
      malware: new Set(),
      cosmetic: {
        generic: new Set(), genericExceptions: new Set(),
        specific: new Map(), exceptions: new Map(),
        hideExceptions: { generic: new Set(), specific: new Set(), all: new Set() }
      }
    };
  }

  function createCompiler(options = {}) {
    const stats = {};
    const count = (key) => { stats[key] = (stats[key] || 0) + 1; };
    const categories = new Map();
    const scriptlets = { rules: new Map(), exceptions: new Map(), unsupported: new Set() };
    // `$removeparam=x` genéricos: se suman a la limpieza propia de parámetros.
    const trackingParams = new Set();
    let badfilters = new Set();
    const category = (name) => {
      if (!categories.has(name)) categories.set(name, createCategory());
      return categories.get(name);
    };

    function splitNetwork(text) {
      if (text.startsWith("/")) {
        const end = text.lastIndexOf("/$");
        if (end > 0) return { pattern: text.slice(0, end + 1), optionText: text.slice(end + 2), isRegex: true };
        if (text.length > 2 && text.endsWith("/")) return { pattern: text, optionText: "", isRegex: true };
      }
      const dollar = text.lastIndexOf("$");
      if (dollar >= 0 && !/[/^|]/.test(text.slice(dollar + 1).split(",")[0].split("=")[0])) {
        return { pattern: text.slice(0, dollar), optionText: text.slice(dollar + 1), isRegex: false };
      }
      return { pattern: text, optionText: "", isRegex: false };
    }

    function splitOptions(optionText) {
      const parts = [];
      let current = "";
      for (let index = 0; index < optionText.length; index++) {
        const char = optionText[index];
        if (char === "\\" && optionText[index + 1] === ",") {
          current += ",";
          index++;
        } else if (char === ",") {
          parts.push(current);
          current = "";
        } else {
          current += char;
        }
      }
      if (current) parts.push(current);
      return parts;
    }

    function parseNetwork(line, list) {
      if (badfilters.has(line)) return count("anulado por badfilter");
      let text = line;
      const exception = text.startsWith("@@");
      if (exception) text = text.slice(2);
      let { pattern, optionText, isRegex } = splitNetwork(text);
      const target = category(list.category);
      const condition = {};
      let resourceTypes = [];
      const excludedResourceTypes = [];
      let important = false;
      let redirect = null;
      let removeParam = null;
      const cosmeticExceptions = [];

      for (const option of optionText ? splitOptions(optionText) : []) {
        const equals = option.indexOf("=");
        const rawName = (equals >= 0 ? option.slice(0, equals) : option).trim();
        const value = equals >= 0 ? option.slice(equals + 1) : "";
        const negated = rawName.startsWith("~");
        const name = (negated ? rawName.slice(1) : rawName).toLowerCase();
        if (TYPE_MAP[name]) {
          (negated ? excludedResourceTypes : resourceTypes).push(...TYPE_MAP[name]);
        } else if (name === "third-party" || name === "3p" || name === "strict3p" || name === "strict-third-party") {
          condition.domainType = negated ? "firstParty" : "thirdParty";
        } else if (name === "first-party" || name === "1p" || name === "strict1p" || name === "strict-first-party") {
          condition.domainType = negated ? "thirdParty" : "firstParty";
        } else if (name === "domain" || name === "from") {
          const domains = parseDomainList(value, "|", false);
          if (!domains || (!domains.include.length && !domains.exclude.length)) return count("omitido: dominio no soportado");
          if (domains.include.length) condition.initiatorDomains = domains.include;
          if (domains.exclude.length) condition.excludedInitiatorDomains = domains.exclude;
        } else if (name === "to") {
          const domains = parseDomainList(value, "|", false);
          if (!domains || (!domains.include.length && !domains.exclude.length)) return count("omitido: dominio no soportado");
          if (domains.include.length) condition.requestDomains = domains.include;
          if (domains.exclude.length) condition.excludedRequestDomains = domains.exclude;
        } else if (name === "denyallow") {
          const domains = parseDomainList(value, "|", false);
          if (!domains?.include.length) return count("omitido: dominio no soportado");
          condition.excludedRequestDomains = [...(condition.excludedRequestDomains || []), ...domains.include];
        } else if (name === "method") {
          const methods = value.toLowerCase().split("|");
          const include = methods.filter((method) => !method.startsWith("~"));
          const exclude = methods.filter((method) => method.startsWith("~")).map((method) => method.slice(1));
          const valid = ["connect", "delete", "get", "head", "options", "patch", "post", "put", "other"];
          if (![...include, ...exclude].every((method) => valid.includes(method))) return count("omitido: método");
          if (include.length) condition.requestMethods = include;
          if (exclude.length) condition.excludedRequestMethods = exclude;
        } else if (name === "match-case") {
          condition.isUrlFilterCaseSensitive = true;
        } else if (name === "important") {
          important = true;
        } else if (name === "redirect" && !exception) {
          const resource = REDIRECT_RESOURCES[value.split(":")[0]];
          if (!resource) return count("omitido: recurso de redirect");
          redirect = resource;
        } else if (name === "removeparam" && !exception) {
          if (!/^[A-Za-z0-9_.\-[\]]+$/.test(value)) return count("omitido: removeparam complejo");
          removeParam = value;
        } else if (exception && COSMETIC_EXCEPTION_OPTIONS[name]) {
          cosmeticExceptions.push(COSMETIC_EXCEPTION_OPTIONS[name]);
        } else if (IGNORED_OPTIONS.has(name)) {
          continue;
        } else {
          return count(`omitido: opción ${name}`);
        }
      }

      if (cosmeticExceptions.length) {
        const host = /^\|\|([a-z0-9.-]+)\^?\|?$/.exec(pattern)?.[1];
        const domain = host && normalizeDomain(host);
        const domains = domain ? [domain] : condition.initiatorDomains || [];
        if (!domains.length || (pattern && !domain)) return count("omitido: excepción cosmética compleja");
        for (const kind of cosmeticExceptions) {
          for (const entry of domains) target.cosmetic.hideExceptions[kind].add(entry);
        }
        return count("excepción cosmética");
      }

      if (isRegex) {
        const regex = pattern.slice(1, -1);
        if (!/^[\x20-\x7e]+$/.test(regex) || /\(\?[=!<]|\\[1-9]/.test(regex)) return count("omitido: regex no RE2");
        if (target.regexCount >= MAX_REGEX_RULES) return count("omitido: límite de regex");
        target.regexCount++;
        condition.regexFilter = regex;
      } else {
        pattern = pattern.replace(/^\*+/, "").replace(/\*+$/, "");
        if (pattern && !validUrlFilter(pattern)) return count("omitido: patrón no válido para DNR");
      }

      resourceTypes = [...new Set(resourceTypes)];
      if (!resourceTypes.length && excludedResourceTypes.length) {
        condition.excludedResourceTypes = [...new Set(excludedResourceTypes)];
      }

      const action = { type: exception ? "allow" : "block" };
      let priority = exception ? (important ? PRIORITY.importantAllow : PRIORITY.allow)
        : (important ? PRIORITY.important : PRIORITY.block);
      if (exception && resourceTypes.includes("main_frame")) {
        // @@...$document permite la página entera y lo que cargue.
        action.type = "allowAllRequests";
        resourceTypes = resourceTypes.filter((type) => type === "main_frame" || type === "sub_frame");
      }
      if (redirect) {
        action.type = "redirect";
        action.redirect = { extensionPath: `/src/surrogates/${redirect}` };
        priority = PRIORITY.redirect;
      }
      if (removeParam) {
        // Sin patrón ni dominio se une a la regla propia, que solo actúa si la
        // URL lleva el parámetro. Con patrón, la redirección se evaluaría en
        // cada petición del sitio aunque no lo lleve: se descarta.
        const generic = !pattern && !condition.initiatorDomains && !condition.requestDomains && !resourceTypes.length;
        if (generic && /^[A-Za-z0-9_.-]+$/.test(removeParam)) {
          trackingParams.add(removeParam);
          return count("removeparam genérico");
        }
        return count("omitido: removeparam específico");
      }
      if (resourceTypes.length) condition.resourceTypes = resourceTypes;

      if (action.type === "block" || action.type === "redirect") {
        if (YOUTUBE_RELATED.test(pattern) || condition.requestDomains?.some((domain) => YOUTUBE_RELATED.test(`.${domain}`))
            || condition.initiatorDomains?.some((domain) => YOUTUBE_DOMAINS.some((yt) => domain === yt || domain.endsWith(`.${yt}`)))) {
          return count("omitido: afecta a YouTube");
        }
        condition.excludedInitiatorDomains = [...new Set([...(condition.excludedInitiatorDomains || []), ...YOUTUBE_DOMAINS])];
      }

      // `||dominio^` sin más: se agrupa en una sola regla con requestDomains.
      const pureDomain = /^\|\|([a-z0-9.-]+)\^?\|?$/.exec(pattern);
      const groupable = pureDomain && action.type === "block" && !condition.requestDomains && !condition.initiatorDomains
        && !condition.excludedRequestDomains && !condition.isUrlFilterCaseSensitive
        && !condition.excludedInitiatorDomains?.some((value) => !YOUTUBE_DOMAINS.includes(value));
      const domain = groupable ? normalizeDomain(pureDomain[1]) : null;
      if (domain) {
        const key = JSON.stringify({ action, priority, condition });
        if (!target.groups.has(key)) target.groups.set(key, { action, priority, condition, domains: new Set() });
        target.groups.get(key).domains.add(domain);
        return count("regla de dominio");
      }

      if (pattern && !isRegex) condition.urlFilter = pattern;
      target.rules.push({ action, priority, condition });
      count(isRegex ? "regla regex" : "regla de patrón");
    }

    // Argumentos de `+js(nombre, a, b)`: comas separan; `\,` es una coma
    // literal; comillas envolventes se quitan.
    function splitUboArgs(text) {
      const args = [];
      let current = "";
      for (let index = 0; index < text.length; index++) {
        const char = text[index];
        if (char === "\\" && text[index + 1] === ",") {
          current += ",";
          index++;
        } else if (char === ",") {
          args.push(current);
          current = "";
        } else {
          current += char;
        }
      }
      args.push(current);
      return args.map((arg) => {
        const trimmed = arg.trim();
        const quoted = /^(['"`])([\s\S]*)\1$/.exec(trimmed);
        return quoted ? quoted[2] : trimmed;
      });
    }

    // Argumentos de `#$#nombre a 'b c'` (Adblock Plus).
    function splitAbpArgs(text) {
      const args = [];
      let current = "";
      let quote = null;
      let started = false;
      for (let index = 0; index < text.length; index++) {
        const char = text[index];
        if (char === "\\" && index + 1 < text.length) {
          current += text[++index];
          started = true;
        } else if (quote) {
          if (char === quote) quote = null;
          else current += char;
        } else if (char === "'" || char === "\"") {
          quote = char;
          started = true;
        } else if (/\s/.test(char)) {
          if (started) args.push(current);
          current = "";
          started = false;
        } else {
          current += char;
          started = true;
        }
      }
      if (started) args.push(current);
      return args;
    }

    function addScriptlet(domains, args, exception) {
      args[0] = args[0].replace(/\.js$/, "");
      if (exception) {
        const signature = args[0] ? args.join("\u0000") : "*";
        for (const domain of domains.include) addTo(scriptlets.exceptions, domain, signature);
        return count("excepción de scriptlet");
      }
      if (!domains.include.length) return count("omitido: scriptlet genérico");
      // YouTube detecta que se reescriben sus respuestas y bloquea el vídeo:
      // nunca recibe scriptlets de las listas (su protección vive en src/youtube/).
      const include = domains.include.filter((domain) => !isYoutubeDomain(domain));
      if (include.length < domains.include.length) count("omitido: scriptlet en YouTube");
      if (!include.length) return;
      for (const domain of include) {
        if (!SCRIPTLETS.has(args[0])) {
          scriptlets.unsupported.add(domain);
          continue;
        }
        if (!scriptlets.rules.has(domain)) scriptlets.rules.set(domain, new Map());
        scriptlets.rules.get(domain).set(args.join("\u0000"), args);
      }
      for (const domain of domains.exclude) addTo(scriptlets.exceptions, domain, args.join("\u0000"));
      count(SCRIPTLETS.has(args[0]) ? "scriptlet" : "scriptlet no soportado");
    }

    // Convierte `:style(...)` y `:remove()` de uBlock; descarta lo procedural.
    function cosmeticSelector(selector) {
      let text = selector.replace(/:-abp-has\(/g, ":has(");
      let style = null;
      const styleMatch = /:style\((.+)\)$/.exec(text);
      if (styleMatch) {
        style = styleMatch[1];
        text = text.slice(0, styleMatch.index);
        if (/[{}]|url\(|expression|@import/i.test(style)) return null;
      } else if (text.endsWith(":remove()")) {
        text = text.slice(0, -":remove()".length);
      }
      if (!text || PROCEDURAL.test(text) || /[{}]/.test(text)) return null;
      return style ? `${text}\u0000${style}` : text;
    }

    function parseCosmetic(line, list) {
      const match = /^([^#/|"!$@]*?)(#@?[?$%]?#)(.*)$/.exec(line);
      if (!match) return false;
      const [, domainText, separator, body] = match;
      const exception = separator.includes("@");
      const domains = domainText ? parseDomainList(domainText, ",", true) : { include: [], exclude: [] };
      if (!domains) {
        count("omitido: dominio no soportado");
        return true;
      }
      if (body.startsWith("+js(") && body.endsWith(")") && (separator === "##" || separator === "#@#")) {
        addScriptlet(domains, splitUboArgs(body.slice(4, -1)), exception);
        return true;
      }
      if (separator === "#$#" || separator === "#@$#") {
        if (/\{.*\}\s*$/.test(body)) {
          count("omitido: inyección CSS");
          return true;
        }
        for (const snippet of body.split(";").map((part) => part.trim()).filter(Boolean)) {
          addScriptlet(domains, splitAbpArgs(snippet), exception);
        }
        return true;
      }
      if (body.startsWith("^") || separator.includes("%")) {
        count("omitido: filtro HTML o script");
        return true;
      }
      const selector = cosmeticSelector(body);
      if (!selector) {
        count("omitido: cosmético avanzado");
        return true;
      }
      const { cosmetic } = category(list.category);
      if (exception) {
        for (const domain of domains.include) addTo(cosmetic.exceptions, domain, selector);
        if (!domains.include.length) cosmetic.genericExceptions.add(selector);
        count("excepción cosmética");
        return true;
      }
      if (domains.include.length) {
        for (const domain of domains.include) addTo(cosmetic.specific, domain, selector);
      } else {
        cosmetic.generic.add(selector);
      }
      for (const domain of domains.exclude) addTo(cosmetic.exceptions, domain, selector);
      count(domains.include.length ? "cosmético específico" : "cosmético genérico");
      return true;
    }

    function parseHosts(text, list) {
      const target = category(list.category);
      for (const raw of text.split(/\r?\n/)) {
        const line = raw.replace(/#.*$/, "").trim();
        if (!line) continue;
        const domain = normalizeDomain(line.replace(/^(?:0\.0\.0\.0|127\.0\.0\.1)\s+/, ""));
        if (domain && !YOUTUBE_RELATED.test(`.${domain}`)) target.malware.add(domain);
      }
    }

    function lines(text) {
      return text.split(/\r?\n/).map((line) => line.trim())
        .filter((line) => line && !line.startsWith("!") && !line.startsWith("[") && !line.startsWith("# "));
    }

    return {
      // Primero se registran los `$badfilter` de todas las listas.
      collectBadfilters(text) {
        for (const line of lines(text)) {
          if (!/\$.*\bbadfilter\b/.test(line)) continue;
          const cleaned = line.replace(/([$,])badfilter(?=,|$)/, "$1").replace(/[$,]$/, "").replace(/,,/, ",");
          badfilters.add(cleaned);
        }
      },
      addList(text, list) {
        if (list.format === "hosts") {
          parseHosts(text, list);
          return;
        }
        for (const line of lines(text)) {
          if (/\$.*\bbadfilter\b/.test(line)) continue;
          if (parseCosmetic(line, list)) continue;
          parseNetwork(line, list);
        }
      },
      addRules(categoryName, rules) {
        category(categoryName).rules.push(...rules);
      },
      finish() {
        const rulesets = {};
        for (const [name, data] of categories) {
          const rules = [...data.rules];
          for (const group of data.groups.values()) {
            rules.push({ action: group.action, priority: group.priority,
              condition: { requestDomains: [...group.domains].sort(), ...group.condition } });
          }
          if (data.malware.size) {
            rules.push({ action: { type: "block" }, priority: PRIORITY.important,
              condition: { requestDomains: [...data.malware].sort(), resourceTypes: ["main_frame", "sub_frame"] } });
          }
          const seen = new Set();
          rulesets[name] = rules.filter((rule) => {
            const key = JSON.stringify(rule);
            return !seen.has(key) && seen.add(key);
          });
        }
        const toArray = (set) => [...set].sort();
        const toObject = (map) => Object.fromEntries([...map].sort(([a], [b]) => (a < b ? -1 : 1)).map(([key, set]) => [key, toArray(set)]));
        const cosmetic = {};
        for (const [name, data] of categories) {
          const { generic, genericExceptions, specific, exceptions, hideExceptions } = data.cosmetic;
          if (!generic.size && !specific.size) continue;
          cosmetic[name] = {
            generic: toArray(generic).filter((selector) => !genericExceptions.has(selector)),
            specific: toObject(specific),
            exceptions: toObject(exceptions),
            genericHide: toArray(new Set([...hideExceptions.generic, ...hideExceptions.all])),
            specificHide: toArray(new Set([...hideExceptions.specific, ...hideExceptions.all]))
          };
        }
        // Un sitio con algún scriptlet no soportado no recibe ninguno: aplicar
        // solo parte de un conjunto de defensas puede romper la web.
        const scriptletRules = {};
        for (const [domain, map] of [...scriptlets.rules].sort(([a], [b]) => (a < b ? -1 : 1))) {
          if (scriptlets.unsupported.has(domain)) {
            count("sitio sin scriptlets (alguno no soportado)");
            continue;
          }
          scriptletRules[domain] = [...map.values()];
        }
        return {
          rulesets,
          trackingParams: [...trackingParams].sort(),
          cosmetic,
          scriptlets: { rules: scriptletRules, exceptions: toObject(scriptlets.exceptions) },
          stats
        };
      }
    };
  }

  // Reglas propias de privacidad: limpieza de parámetros de rastreo (sin
  // regex: Chrome descarta en silencio las que superan 2 KB compiladas).
  const TRACKING_PARAMS = ["utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content", "utm_id",
    "fbclid", "gclid", "dclid", "gbraid", "wbraid", "msclkid", "yclid", "twclid", "igshid", "mc_eid",
    "_hsenc", "_hsmi", "mkt_tok"];
  // Sustitutos propios de scripts publicitarios y de analítica.
  const SURROGATES = {
    scutumad: [
      ["||googletagservices.com/tag/js/gpt.js", "gpt.js"],
      ["||securepubads.g.doubleclick.net/tag/js/gpt.js", "gpt.js"],
      ["||pagead2.googlesyndication.com/pagead/js/adsbygoogle.js", "adsbygoogle.js"],
      ["/fuckadblock.js", "nobab.js"],
      ["/blockadblock.js", "nobab.js"]
    ],
    privacy: [
      ["||google-analytics.com/analytics.js", "analytics.js"],
      ["||googletagmanager.com/gtag/js", "gtag.js"],
      ["||googletagmanager.com/gtm.js", "gtm.js"]
    ]
  };

  // extraParams: los `$removeparam` genéricos de las listas.
  // Modo sigiloso: los bloqueos de publicidad de scripts, imágenes, XHR y
  // marcos se convierten en redirecciones a recursos vacíos. La petición
  // «carga bien», así que la web no ve el error con el que detecta un
  // bloqueador. Prioridad entre el bloqueo (100) y las excepciones (300).
  const STEALTH_PRIORITY = 260;
  const STEALTH_RESOURCES = { script: "noop.js", image: "1x1.gif", xmlhttprequest: "noop.txt", sub_frame: "noop.html" };
  function stealthRules(rules) {
    const stealth = [];
    for (const rule of rules) {
      if (rule.action.type !== "block" || rule.priority !== PRIORITY.block || rule.condition.regexFilter) continue;
      const types = rule.condition.resourceTypes;
      // Sin tipos (todos menos main_frame) solo se convierten los grupos de
      // dominios: con patrones serían demasiadas reglas.
      const targets = types ? types.filter((type) => STEALTH_RESOURCES[type])
        : rule.condition.requestDomains ? Object.keys(STEALTH_RESOURCES) : [];
      for (const type of targets) {
        stealth.push({
          action: { type: "redirect", redirect: { extensionPath: `/src/surrogates/${STEALTH_RESOURCES[type]}` } },
          priority: STEALTH_PRIORITY,
          condition: { ...rule.condition, resourceTypes: [type], excludedResourceTypes: undefined }
        });
      }
    }
    return stealth.map((rule) => {
      delete rule.condition.excludedResourceTypes;
      return rule;
    });
  }

  function ownRules(extraParams = []) {
    const rules = { scutumad: [], privacy: [] };
    const params = [...new Set([...TRACKING_PARAMS, ...extraParams])];
    for (const param of params) {
      for (const separator of ["?", "&"]) {
        rules.privacy.push({
          action: { type: "redirect", redirect: { transform: { queryTransform: { removeParams: params } } } },
          priority: 1,
          condition: { urlFilter: `${separator}${param}=`, resourceTypes: ["main_frame"] }
        });
      }
    }
    for (const [name, entries] of Object.entries(SURROGATES)) {
      for (const [urlFilter, file] of entries) {
        rules[name].push({
          action: { type: "redirect", redirect: { extensionPath: `/src/surrogates/${file}` } },
          priority: PRIORITY.redirect,
          condition: { urlFilter, resourceTypes: ["script"], excludedInitiatorDomains: YOUTUBE_DOMAINS }
        });
      }
    }
    return rules;
  }

  globalThis.ScutumADFilterCompiler = Object.freeze({ createCompiler, ownRules, stealthRules, normalizeDomain, SCRIPTLETS, YOUTUBE_DOMAINS });
})();
