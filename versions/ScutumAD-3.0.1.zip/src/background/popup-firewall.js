// Segunda barrera local. No guarda historial ni datos en chrome.storage.
(() => {
  const policy = globalThis.ScutumADPopupPolicy;
  const intents = new Map();
  const watched = new Map();
  const learningSources = new Map();
  const key = (tabId, frameId) => `${tabId}:${frameId}`;
  const cappedSet = (map, id, value) => {
    if (map.size >= 128) map.delete(map.keys().next().value);
    map.set(id, value);
    setTimeout(() => { if (map.get(id) === value) map.delete(id); }, 5000);
  };
  function rememberIntent(message, sender) {
    const url = policy.http(message.url);
    if (!url || !Number.isInteger(sender?.tab?.id) || !Number.isInteger(sender.frameId)
        || policy.isBlockedAdUrl(url.href)) return { ok: false };
    cappedSet(intents, key(sender.tab.id, sender.frameId), {
      url: url.href, documentId: sender.documentId, expires: Date.now() + 1200
    });
    return { ok: true };
  }
  function consumeIntent(tabId, frameId, documentId, url) {
    const id = key(tabId, frameId);
    const intent = intents.get(id);
    if (!intent || Date.now() > intent.expires || intent.url !== url
        || (documentId && intent.documentId !== documentId)) return false;
    intents.delete(id);
    return true;
  }
  async function activeFor(sourceUrl, topUrl) {
    const settings = await readSettings();
    return settings.protectionEnabled && (settings.blockAds || settings.blockAnnoyances
      || settings.learnedRules?.some(rule => rule.action === "block-popup"))
      && !isWhitelisted(policy.hostname(policy.http(sourceUrl)), settings.whitelist)
      && !isWhitelisted(policy.hostname(policy.http(topUrl)), settings.whitelist);
  }
  async function close(tabId) {
    watched.delete(tabId);
    try { await chrome.tabs.remove(tabId); } catch { /* Ya cerrada por el usuario. */ }
  }
  async function created(details) {
    if (details.tabId === details.sourceTabId) return;
    let frame, tab;
    try {
      [frame, tab] = await Promise.all([
        chrome.webNavigation.getFrame({ tabId: details.sourceTabId, frameId: details.sourceFrameId }),
        chrome.tabs.get(details.sourceTabId)
      ]);
    } catch { return; }
    const sourceUrl = policy.http(frame?.url)?.href || tab?.url || "";
    const topUrl = tab?.url || sourceUrl;
    if (!await activeFor(sourceUrl, topUrl)) return;
    // Modo Estricto: cualquier web se trata como un reproductor de streaming.
    const strict = siteModeForUrls([sourceUrl, topUrl], await readSettings()) === "strict"
      || policy.isStreamingUrl(topUrl) || policy.isPlayerUrl(topUrl)
      || policy.isStreamingUrl(sourceUrl) || policy.isPlayerUrl(sourceUrl);
    const url = policy.http(details.url, sourceUrl)?.href || details.url;
    const settings = await readSettings();
    if (settings.learningEnabled) {
      const value = { sourceTabId: details.sourceTabId };
      if (learningSources.size >= 128) learningSources.delete(learningSources.keys().next().value);
      learningSources.set(details.tabId, value);
      setTimeout(() => { if (learningSources.get(details.tabId) === value) learningSources.delete(details.tabId); }, 600000);
    }
    if (policy.isBlockedPopupUrl(url, sourceUrl, policy.learnedPopupDomains(settings.learnedRules, [sourceUrl, topUrl]))) return close(details.tabId);
    if (policy.isBlockedAdUrl(url)) return close(details.tabId);
    if (!strict) {
      cappedSet(watched, details.tabId, { sourceUrl, topUrl, strict: false, expires: Date.now() + 5000 });
      return;
    }
    if (!policy.isTrustedDestination(url, sourceUrl)) {
      // Cubrir el cruce de eventos de procesos distintos sin espera larga.
      await new Promise((resolve) => setTimeout(resolve, 40));
      if (consumeIntent(details.sourceTabId, details.sourceFrameId, frame?.documentId, url)) {
        cappedSet(watched, details.tabId, { sourceUrl, topUrl, strict: false, expires: Date.now() + 5000 });
        return;
      }
      return close(details.tabId);
    }
    cappedSet(watched, details.tabId, { sourceUrl, topUrl, strict: true, expires: Date.now() + 5000 });
    try {
      const target = await chrome.tabs.get(details.tabId);
      if (policy.http(target.url)) await navigating({ tabId: details.tabId, frameId: 0, url: target.url });
    } catch { watched.delete(details.tabId); }
  }
  async function navigating(details) {
    if (details.frameId !== 0) return;
    const source = watched.get(details.tabId);
    if (!source || Date.now() > source.expires) { watched.delete(details.tabId); return; }
    if (!await activeFor(source.sourceUrl, source.topUrl)) { watched.delete(details.tabId); return; }
    // Un enlace legítimo puede atravesar about:blank antes de su destino.
    // Las aperturas originalmente vacías ya se rechazan en created().
    if (!details.url || details.url === "about:blank") return;
    const settings = await readSettings();
    if (policy.isBlockedAdUrl(details.url) || policy.isBlockedPopupUrl(details.url, source.sourceUrl,
      policy.learnedPopupDomains(settings.learnedRules, [source.sourceUrl, source.topUrl]))) return close(details.tabId);
    if (!source.strict) return;
    if (policy.isTrustedDestination(details.url, source.sourceUrl)) return;
    if (!policy.isBlockedAdUrl(details.url) && consumeIntent(details.tabId, 0, null, details.url)) {
      watched.delete(details.tabId);
      return;
    }
    await close(details.tabId);
  }
  chrome.webNavigation.onCreatedNavigationTarget.addListener((details) => { created(details).catch(() => {}); });
  chrome.webNavigation.onBeforeNavigate.addListener((details) => { navigating(details).catch(() => {}); });
  chrome.tabs.onRemoved.addListener((tabId) => {
    watched.delete(tabId);
    learningSources.delete(tabId);
    for (const [id, source] of learningSources) if (source.sourceTabId === tabId) learningSources.delete(id);
    for (const id of intents.keys()) if (id.startsWith(`${tabId}:`)) intents.delete(id);
  });
  chrome.webNavigation.onCommitted.addListener((details) => { intents.delete(key(details.tabId, details.frameId)); });
  globalThis.ScutumADPopupFirewall = Object.freeze({ rememberIntent,
    learningSourceFor(tabId) { return learningSources.get(tabId)?.sourceTabId; } });
})();
