// Una guía en la página superior coordina los content scripts de sus marcos.
// Usa mensajes internos de Chrome, nunca mensajes que una página pueda forjar.
(() => {
  const sessions = new Map();
  const guideOwners = new Map();
  const guideRevisions = new Map();
  let serial = 0;
  async function active(sender) {
    if (!Number.isInteger(sender?.tab?.id)) return false;
    const settings = await readSettings();
    return settings.protectionEnabled && settings.learningEnabled
      && !isWhitelisted(httpHostname(sender.tab.url), settings.whitelist);
  }
  async function broadcast(tabId, enabled) {
    await chrome.tabs.sendMessage(tabId, { type: "LEARNING_PICK_MODE", enabled }).catch(() => {});
  }
  async function picker(message, sender) {
    if (![0, guideOwners.get(sender.tab?.id)].includes(sender.frameId) || !await active(sender)) return { ok: false };
    sessions.delete(sender.tab.id);
    if (message.enabled) {
      if (sessions.size >= 128) sessions.delete(sessions.keys().next().value);
      sessions.set(sender.tab.id, { picking: true, expires: Date.now() + 600000 });
    }
    await broadcast(sender.tab.id, message.enabled === true);
    return { ok: true };
  }
  async function selected(message, sender) {
    const session = sessions.get(sender.tab?.id);
    const normalized = ScutumADLearningPolicy.normalizeSelector(message.selector);
    if (!session?.picking || Date.now() > session.expires || !await active(sender)
        || !normalized || normalized.disabled || !httpHostname(sender.url)) return { ok: false };
    const frameDomain = sender.frameId ? httpHostname(sender.url) : null;
    const token = String(++serial);
    sessions.set(sender.tab.id, {
      token, selector: normalized.selector, frameDomain,
      frameId: sender.frameId, documentId: sender.documentId, expires: Date.now() + 600000
    });
    await broadcast(sender.tab.id, false);
    await chrome.tabs.sendMessage(sender.tab.id, {
      type: "LEARNING_SELECTION", selectionToken: token, frameDomain
    }, { frameId: guideOwners.get(sender.tab.id) || 0 }).catch(() => {});
    return { ok: true };
  }
  async function confirm(message, sender) {
    const selection = sessions.get(sender.tab?.id);
    if (![0, guideOwners.get(sender.tab?.id)].includes(sender.frameId) || !await active(sender) || !selection
        || selection.token !== message.selectionToken || Date.now() > selection.expires) {
      return { ok: false, error: "Vuelve a seleccionar el banner antes de guardarlo." };
    }
    const frame = await chrome.webNavigation.getFrame({ tabId: sender.tab.id, frameId: selection.frameId }).catch(() => null);
    if (!frame || frame.documentId !== selection.documentId) {
      sessions.delete(sender.tab.id);
      return { ok: false, error: "El marco ha cambiado. Selecciona de nuevo el banner." };
    }
    sessions.delete(sender.tab.id);
    return queueSettingsMutation(() => addLearnedRule(selection.selector, sender, selection.frameDomain));
  }
  async function guide(message, sender) {
    if (!await active(sender)) return { ok: false };
    const revision = (guideRevisions.get(sender.tab.id) || 0) + 1;
    guideRevisions.set(sender.tab.id, revision);
    // En pantalla completa Chrome puede poner el iframe por encima incluso
    // de un popover del padre. La misma guía se presenta en el marco visible.
    const frames = await chrome.webNavigation.getAllFrames({ tabId: sender.tab.id });
    const top = await chrome.tabs.sendMessage(sender.tab.id, { type: "LEARNING_GUIDE_PROBE" }, { frameId: 0 }).catch(() => null);
    let owner = 0;
    if (top?.fullscreenActive && top.childUrl) {
      let parent = 0, childUrl = top.childUrl;
      for (let depth = 0; depth < 8 && childUrl; depth++) {
        const children = frames.filter(frame => frame.parentFrameId === parent);
        const matching = children.filter(frame => frame.url === childUrl);
        const child = matching.length === 1 ? matching[0] : children.length === 1 ? children[0] : null;
        if (!child) break;
        owner = child.frameId; parent = owner;
        const probe = await chrome.tabs.sendMessage(sender.tab.id, { type: "LEARNING_GUIDE_PROBE" }, { frameId: owner }).catch(() => null);
        childUrl = probe?.childUrl;
      }
    }
    if (guideRevisions.get(sender.tab.id) !== revision) return { ok: true };
    guideOwners.set(sender.tab.id, owner);
    await Promise.all(frames.map(frame => chrome.tabs.sendMessage(sender.tab.id,
      { type: "LEARNING_GUIDE_OWNER", visible: frame.frameId === owner }, { frameId: frame.frameId }).catch(() => {})));
    return { ok: true };
  }
  chrome.tabs.onRemoved.addListener((id) => { sessions.delete(id); guideOwners.delete(id); guideRevisions.delete(id); });
  chrome.webNavigation.onCommitted.addListener((d) => {
    if (d.frameId === 0 || sessions.get(d.tabId)?.frameId === d.frameId) sessions.delete(d.tabId);
    if (d.frameId === 0) guideOwners.delete(d.tabId);
  });
  globalThis.ScutumADLearningCoordinator = Object.freeze({ picker, selected, confirm, guide });
})();
