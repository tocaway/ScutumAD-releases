(() => {
  "use strict";

  const PLAYER_AD_SELECTOR = [
    "#movie_player.ad-showing",
    "#movie_player.ad-interrupting",
    ".html5-video-player.ad-showing",
    ".html5-video-player.ad-interrupting"
  ].join(",");
  const SKIP_SELECTOR = [
    ".ytp-ad-skip-button",
    ".ytp-ad-skip-button-modern",
    ".ytp-skip-ad-button",
    "button.ytp-ad-skip-button",
    "button[class*='ytp-ad-skip-button']"
  ].join(",");
  const AD_OVERLAY_SELECTOR = [
    ".ytp-ad-preview-container",
    ".ytp-ad-text",
    ".ytp-ad-simple-ad-badge",
    ".ytp-ad-player-overlay"
  ].join(",");
  const GUARD_DELAY = 90;
  const GUARD_INTERVAL = 750;
  // YouTube detecta las extensiones que modifican las respuestas del
  // reproductor. Este módulo no toca la red ni JSON: solo actúa sobre el
  // reproductor ya inicializado, cuando muestra un anuncio.
  let enabled = true;

  // El estado llega por un MessagePort entregado por el content script antes
  // de que se ejecute la página. Un evento del DOM lo podría falsificar la
  // propia web para desactivar la protección.
  function connectBridge(name, onMessage) {
    const listener = (event) => {
      if (event.source !== window || event.data?.scutumadBridge !== name || !event.ports?.[0]) return;
      event.stopImmediatePropagation();
      window.removeEventListener("message", listener, true);
      event.ports[0].onmessage = (message) => onMessage(message.data);
    };
    window.addEventListener("message", listener, true);
  }

  function restoreVideo(video) {
    if (video.dataset.scutumadYoutubeAdHandled !== "1") {
      return;
    }
    video.muted = video.dataset.scutumadYoutubeWasMuted === "1";
    const rate = Number(video.dataset.scutumadYoutubePlaybackRate);
    if (Number.isFinite(rate) && rate > 0) video.playbackRate = rate;
    delete video.dataset.scutumadYoutubeAdHandled;
    delete video.dataset.scutumadYoutubeWasMuted;
    delete video.dataset.scutumadYoutubePlaybackRate;
  }

  function playerShowsAd(player) {
    if (player?.matches(PLAYER_AD_SELECTOR)) {
      return true;
    }

    const scope = player || document;
    return [...scope.querySelectorAll(AD_OVERLAY_SELECTOR)].some((element) => (
      !element.hidden
      && element.getClientRects().length > 0
      && getComputedStyle(element).display !== "none"
      && getComputedStyle(element).visibility !== "hidden"
      && Number.parseFloat(getComputedStyle(element).opacity || "1") > 0
    ));
  }

  function skipCurrentAd() {
    const player = document.querySelector("#movie_player, .html5-video-player");
    const video = player?.querySelector("video.html5-main-video, video");

    if (!enabled) {
      if (video instanceof HTMLVideoElement) {
        restoreVideo(video);
      }
      return;
    }

    if (!(video instanceof HTMLVideoElement)) {
      return;
    }

    const showingAd = playerShowsAd(player);
    if (!showingAd) {
      restoreVideo(video);
      return;
    }

    player.querySelectorAll(SKIP_SELECTOR).forEach((button) => {
      if (button instanceof HTMLElement && !button.hidden && button.getClientRects().length > 0) {
        try {
          button.click();
        } catch {
          // El botón puede desaparecer durante la navegación interna.
        }
      }
    });

    if (!playerShowsAd(player)) {
      restoreVideo(video);
      return;
    }
    if (video.dataset.scutumadYoutubeAdHandled !== "1") {
      video.dataset.scutumadYoutubeWasMuted = video.muted ? "1" : "0";
      video.dataset.scutumadYoutubePlaybackRate = String(video.playbackRate || 1);
      video.dataset.scutumadYoutubeAdHandled = "1";
    }

    video.muted = true;
    video.playbackRate = 16;

    let duration = video.duration;
    try {
      const progress = player.getProgressState?.();
      if (!(Number.isFinite(duration) && duration > 0) && Number.isFinite(progress?.duration)) {
        duration = progress.duration;
      }
    } catch {
      // Algunas variantes del reproductor no exponen getProgressState.
    }

    if (Number.isFinite(duration) && duration > 0) {
      try {
        player.seekTo?.(duration, true);
      } catch {
        // El vídeo nativo se usa como segundo intento.
      }
      try {
        video.currentTime = Math.max(0, duration - 0.01);
      } catch {
        // El origen multimedia puede cambiar mientras se hace el salto.
      }
    }

    try {
      const playPromise = video.play();
      playPromise?.catch?.(() => {});
    } catch {
      // La reproducción automática puede estar bloqueada por Chrome.
    }
  }

  function beginPlayerGuard() {
    let guardTimer = null;
    const scheduleGuard = () => {
      if (guardTimer) {
        return;
      }
      guardTimer = window.setTimeout(() => {
        guardTimer = null;
        skipCurrentAd();
      }, GUARD_DELAY);
    };

    const mutationNeedsGuard = (record) => {
      const target = record.target instanceof Element ? record.target : null;
      if (target?.closest?.("#movie_player, .html5-video-player")) {
        return true;
      }
      return [...record.addedNodes].some((node) => {
        if (!(node instanceof Element)) {
          return false;
        }
        try {
          return node.matches("#movie_player, .html5-video-player, " + SKIP_SELECTOR)
            || Boolean(node.closest("#movie_player, .html5-video-player"));
        } catch {
          return false;
        }
      });
    };

    const startObserver = () => {
      const root = document.documentElement || document;
      const observer = new MutationObserver((records) => {
        if (records.some(mutationNeedsGuard)) {
          scheduleGuard();
        }
      });
      observer.observe(root, {
        attributes: true,
        attributeFilter: ["class", "hidden", "aria-label"],
        childList: true,
        subtree: true
      });
      scheduleGuard();
      // Respaldo limitado al reproductor activo para variantes que no
      // notifican sus cambios de clase.
      window.setInterval(scheduleGuard, GUARD_INTERVAL);
    };

    if (document.documentElement) {
      startObserver();
    } else {
      document.addEventListener("readystatechange", startObserver, { once: true });
    }
  }

  connectBridge("youtube", (message) => {
    if (message?.type !== "state") return;
    enabled = message.enabled !== false;
    skipCurrentAd();
  });

  beginPlayerGuard();
})();
