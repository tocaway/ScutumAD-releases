(() => {
  const HIDDEN_CLASS = "scutumad-youtube-hidden";
  const STYLE_ID = "scutumad-youtube-style";
  const SELECTORS = [
    "ytd-display-ad-renderer",
    "ytd-promoted-sparkles-web-renderer",
    "ytd-promoted-sparkles-text-search-renderer",
    "ytd-promoted-video-renderer",
    "ytd-compact-promoted-video-renderer",
    "ytd-search-pyv-renderer",
    "ytd-in-feed-ad-layout-renderer",
    "ytd-ad-slot-renderer",
    "yt-ad-slot-renderer",
    "ytd-banner-promo-renderer",
    "ytd-statement-banner-renderer",
    "ytd-mealbar-promo-renderer",
    "yt-mealbar-promo-renderer",
    "ytd-primetime-promo-renderer",
    "ytd-video-masthead-ad-v3-renderer",
    "ytd-video-masthead-ad-advertiser-info-renderer",
    "ytd-action-companion-ad-renderer",
    "ytd-companion-slot-renderer",
    "yt-companion-slot-renderer",
    "ytd-ads-engagement-panel-content",
    "ytd-engagement-panel-section-list-renderer[target-id*='engagement-panel-ads']",
    "ytd-player-legacy-desktop-watch-ads-renderer",
    // Un item-section puede mezclar un anuncio con recomendaciones legítimas.
    // Ocultarlo entero elimina la columna derecha; se ocultan únicamente los
    // renderers publicitarios concretos declarados arriba.
    "ytd-reel-video-renderer[is-ad]",
    "ytm-promoted-sparkles-web-renderer",
    "ytm-companion-ad-renderer",
    "ytm-ad-slot-renderer",
    "#masthead-ad",
    "#player-ads",
    "#feed-pyv-container",
    "#video-masthead",
    ".ytp-ad-overlay-container",
    ".ytp-ad-overlay-slot",
    ".ytp-ad-overlay-image",
    ".ytp-ad-overlay-close-button",
    ".ytp-ad-text-overlay",
    ".ytp-ad-image-overlay",
    ".ytp-ad-player-overlay",
    ".ytp-ad-message-container",
    ".ytp-ad-preview-container",
    ".ytp-ad-preview-text",
    ".ytp-ad-simple-ad-badge",
    ".ytp-ad-progress-list",
    ".ytp-ad-persistent-progress-bar",
    ".ytp-ad-action-interstitial",
    ".ytp-ad-action-interstitial-slot",
    ".ytp-ad-survey",
    ".ytp-ad-module"
  ];
  const WARNING_SELECTORS = [
    "ytd-enforcement-message-view-model",
    "ytd-ad-blocker-warning",
    "[class*='adblock-warning' i]",
    "[id*='adblock-warning' i]",
    "tp-yt-paper-dialog"
  ];
  const SELECTOR_TEXT = SELECTORS.join(",");
  // Solo tarjetas individuales y el encabezado dedicado del feed. Nunca una
  // cuadrícula, una fila ni una sección que pueda agrupar recomendaciones.
  const AD_CONTAINER_SELECTOR = [
    "ytd-rich-item-renderer",
    "ytd-rich-section-renderer",
    "ytd-rich-grid-renderer > #header"
  ].join(",");
  const WARNING_SELECTOR_TEXT = WARNING_SELECTORS.join(",");
  const SCAN_DELAY = 140;
  // El salto de anuncios del reproductor vive en youtube-main.js (mundo
  // MAIN), que puede usar la API del reproductor. Aquí solo se oculta.

  let activeController = null;

  function installStyle() {
    if (document.getElementById(STYLE_ID)) {
      return;
    }

    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      ${SELECTOR_TEXT} {
        display: none !important;
        visibility: hidden !important;
        opacity: 0 !important;
        pointer-events: none !important;
        min-height: 0 !important;
        max-height: 0 !important;
        height: 0 !important;
        overflow: hidden !important;
      }
      .${HIDDEN_CLASS} {
        display: none !important;
        visibility: hidden !important;
        opacity: 0 !important;
        pointer-events: none !important;
        min-height: 0 !important;
        max-height: 0 !important;
        height: 0 !important;
        overflow: hidden !important;
      }
    `;
    (document.documentElement || document.head || document).appendChild(style);
  }

  function removeHiddenElements() {
    document.querySelectorAll(`.${HIDDEN_CLASS}`).forEach((element) => {
      element.classList.remove(HIDDEN_CLASS);
      delete element.dataset.scutumadYoutubeHidden;
    });
  }

  function hasAdBlockWarningText(element) {
    const text = (element.textContent || "").replace(/\s+/g, " ").trim().toLowerCase();
    if (!text || text.length > 2500) {
      return false;
    }

    const mentionsBlocker = text.includes("ad blocker")
      || text.includes("adblock")
      || text.includes("bloqueador de anuncios")
      || text.includes("bloqueadores de anuncios");
    const mentionsAds = text.includes("ads")
      || text.includes("anuncios")
      || text.includes("premium");
    return mentionsBlocker && mentionsAds;
  }

  function start(reportBlocked = () => {}) {
    if (activeController) {
      return activeController;
    }

    let observer = null;
    let scanTimer = null;
    let stopped = false;
    const hiddenContainers = new Set();
    const pendingNodes = new Set();
    let flushScheduled = false;

    const hide = (element) => {
      if (!(element instanceof Element) || element.dataset.scutumadYoutubeHidden === "1") {
        return 0;
      }

      element.dataset.scutumadYoutubeHidden = "1";
      element.classList.add(HIDDEN_CLASS);
      reportBlocked(1);
      return 1;
    };

    // Exige publicidad reconocida y rechaza cualquier rama desconocida,
    // vídeo, enlace o texto ajeno al anuncio. Los div solo son envoltorios;
    // las etiquetas publicitarias conservan su contenido sin destruirlo.
    const isCardDecoration = (element) => (
      element.matches("ytd-rich-item-renderer > yt-interaction#interaction")
      && !element.textContent.trim()
      && [...element.children].every((child) => (
        child.matches("div.stroke, div.fill") && child.childNodes.length === 0
      ))
    );

    const containsOnlyAd = (element) => {
      if (element.matches(SELECTOR_TEXT)) {
        return true;
      }
      if (element.localName !== "div" && !element.matches(AD_CONTAINER_SELECTOR)) {
        return false;
      }
      let foundAd = false;
      for (const child of element.childNodes) {
        if (child.nodeType === Node.TEXT_NODE && child.textContent.trim()) {
          return false;
        }
        if (!(child instanceof Element) || child.matches("style, script, template") || isCardDecoration(child)) {
          continue;
        }
        if (!containsOnlyAd(child)) {
          return false;
        }
        foundAd = true;
      }
      return foundAd;
    };

    const inspectAdContainers = (node) => {
      const containers = new Set(node.querySelectorAll(AD_CONTAINER_SELECTOR));
      // Una mutación del bloque interno también debe revisar sus tarjetas.
      for (let parent = node; parent; parent = parent.parentElement) {
        if (parent.matches(AD_CONTAINER_SELECTOR)) containers.add(parent);
      }
      containers.forEach((container) => {
        if (containsOnlyAd(container)) {
          hide(container);
          hiddenContainers.add(container);
        } else if (hiddenContainers.delete(container)) {
          // YouTube reutiliza las tarjetas durante la navegación SPA.
          container.classList.remove(HIDDEN_CLASS);
          delete container.dataset.scutumadYoutubeHidden;
        }
      });
      hiddenContainers.forEach((container) => {
        if (!container.isConnected) hiddenContainers.delete(container);
      });
    };

    const inspectWarnings = (node) => {
      if (!(node instanceof Element)) {
        return;
      }

      const candidates = [];
      try {
        if (node.matches(WARNING_SELECTOR_TEXT)) {
          candidates.push(node);
        }
        candidates.push(...node.querySelectorAll(WARNING_SELECTOR_TEXT));
      } catch {
        return;
      }

      candidates.forEach((element) => {
        if (hasAdBlockWarningText(element)) {
          hide(element);
        }
      });
    };

    const inspectNode = (node) => {
      if (!(node instanceof Element)) {
        return;
      }

      try {
        if (node.matches(SELECTOR_TEXT)) {
          hide(node);
        }
        node.querySelectorAll(SELECTOR_TEXT).forEach((element) => hide(element));
        inspectAdContainers(node);
      } catch {
        // Un nodo puede desaparecer mientras YouTube actualiza la interfaz.
      }
      inspectWarnings(node);
    };

    const scanExisting = () => {
      if (stopped) {
        return;
      }
      try {
        document.querySelectorAll(SELECTOR_TEXT).forEach((element) => hide(element));
        inspectAdContainers(document.documentElement);
        document.querySelectorAll(WARNING_SELECTOR_TEXT).forEach((element) => {
          if (hasAdBlockWarningText(element)) {
            hide(element);
          }
        });
      } catch {
        // La página puede cambiar de contexto durante una navegación SPA.
      }
    };

    const scheduleScan = () => {
      if (stopped || scanTimer) {
        return;
      }
      scanTimer = setTimeout(() => {
        scanTimer = null;
        scanExisting();
      }, SCAN_DELAY);
    };

    // Las mutaciones se agrupan: un mismo nodo se revisa una vez por lote y
    // se descartan los nodos contenidos en otro que ya se va a revisar.
    const flushPending = () => {
      flushScheduled = false;
      if (stopped) {
        pendingNodes.clear();
        return;
      }
      const nodes = [...pendingNodes].filter((node) => node.isConnected);
      pendingNodes.clear();
      nodes
        .filter((node) => !nodes.some((other) => other !== node && other.contains(node)))
        .forEach(inspectNode);
    };

    const onMutations = (records) => {
      // Revisar también eliminaciones: una tarjeta publicitaria puede
      // convertirse en un vídeo normal sin cambiar el elemento superior.
      records.forEach((record) => {
        if (record.target instanceof Element) pendingNodes.add(record.target);
      });
      if (!flushScheduled && pendingNodes.size) {
        flushScheduled = true;
        setTimeout(flushPending, 0);
      }
    };

    installStyle();
    scanExisting();

    const root = document.documentElement || document;
    observer = new MutationObserver(onMutations);
    observer.observe(root, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["class", "id", "hidden", "aria-label"]
    });

    document.addEventListener("yt-navigate-finish", scheduleScan, { passive: true });
    document.addEventListener("yt-page-data-updated", scheduleScan, { passive: true });
    window.addEventListener("popstate", scheduleScan, { passive: true });

    activeController = {
      stop() {
        if (stopped) {
          return;
        }
        stopped = true;
        observer?.disconnect();
        if (scanTimer) {
          clearTimeout(scanTimer);
        }
        document.removeEventListener("yt-navigate-finish", scheduleScan);
        document.removeEventListener("yt-page-data-updated", scheduleScan);
        window.removeEventListener("popstate", scheduleScan);
        removeHiddenElements();
        hiddenContainers.clear();
        document.getElementById(STYLE_ID)?.remove();
        activeController = null;
      }
    };

    return activeController;
  }

  globalThis.ScutumADYouTube = {
    start,
    stop() {
      activeController?.stop();
    },
    isRunning() {
      return Boolean(activeController);
    }
  };
})();
