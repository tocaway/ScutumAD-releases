// Registro en directo de las reglas de red aplicadas en una pestaña. Usa
// onRuleMatchedDebug (solo extensiones descomprimidas) y no guarda nada: los
// datos desaparecen al cerrar esta página.
(() => {
  const MAX_ROWS = 1000;
  const RULESET_NAMES = {
    _dynamic: "Listas actualizadas",
    ads: "Publicidad",
    scutumad: "Filtros propios",
    trackers: "Rastreadores",
    privacy: "Privacidad",
    annoyances: "Distracciones",
    malware: "Webs peligrosas"
  };
  const ACTION_NAMES = { block: "Bloqueado", redirect: "Sustituido", allow: "Permitido", allowAllRequests: "Permitido" };
  const tabId = Number(new URLSearchParams(location.search).get("tab"));
  const elements = {
    tabInfo: document.getElementById("tabInfo"),
    rows: document.getElementById("rows"),
    empty: document.getElementById("empty"),
    filter: document.getElementById("filterInput"),
    pause: document.getElementById("pauseButton"),
    clear: document.getElementById("clearButton"),
    reload: document.getElementById("reloadButton"),
    unavailable: document.getElementById("unavailable")
  };
  let paused = false;
  // Las reglas dinámicas no guardan el tipo de acción en el evento: se
  // consulta una vez la lista de reglas para conocerlo.
  const dynamicActions = new Map();

  function cell(text, className) {
    const element = document.createElement("td");
    element.textContent = text;
    if (className) element.className = className;
    return element;
  }

  function matchesFilter(row) {
    const needle = elements.filter.value.trim().toLowerCase();
    return !needle || row.textContent.toLowerCase().includes(needle);
  }

  function addRow({ request, rule }) {
    if (paused || request.tabId !== tabId) return;
    const action = rule.rulesetId === "_dynamic" ? dynamicActions.get(rule.ruleId) : null;
    const row = document.createElement("tr");
    row.append(
      cell(new Date().toLocaleTimeString("es")),
      cell(ACTION_NAMES[action] || "Regla aplicada", `action ${action || ""}`),
      cell(request.type),
      cell(RULESET_NAMES[rule.rulesetId] || rule.rulesetId),
      cell(request.url, "url")
    );
    row.hidden = !matchesFilter(row);
    elements.rows.prepend(row);
    while (elements.rows.children.length > MAX_ROWS) elements.rows.lastElementChild.remove();
    elements.empty.hidden = true;
  }

  async function init() {
    if (!Number.isInteger(tabId)) {
      elements.tabInfo.textContent = "Ábrelo desde el menú de ScutumAD en la pestaña que quieras revisar.";
      return;
    }
    try {
      const tab = await chrome.tabs.get(tabId);
      elements.tabInfo.textContent = tab.title ? `${tab.title} — ${tab.url}` : tab.url;
    } catch {
      elements.tabInfo.textContent = "La pestaña ya no existe.";
    }
    const event = chrome.declarativeNetRequest.onRuleMatchedDebug;
    if (!event) {
      elements.unavailable.hidden = false;
      return;
    }
    try {
      for (const rule of await chrome.declarativeNetRequest.getDynamicRules()) {
        dynamicActions.set(rule.id, rule.action.type);
      }
    } catch {
      // Sin la lista se muestra «Regla aplicada».
    }
    event.addListener(addRow);
  }

  elements.filter.addEventListener("input", () => {
    for (const row of elements.rows.children) row.hidden = !matchesFilter(row);
  });
  elements.pause.addEventListener("click", () => {
    paused = !paused;
    elements.pause.textContent = paused ? "Reanudar" : "Pausar";
  });
  elements.clear.addEventListener("click", () => {
    elements.rows.replaceChildren();
    elements.empty.hidden = false;
  });
  elements.reload.addEventListener("click", () => {
    if (Number.isInteger(tabId)) void chrome.tabs.reload(tabId).catch(() => {});
  });

  void init();
})();
