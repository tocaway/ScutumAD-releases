// Actualizador de la propia extensión. Habla con el ayudante local
// (scutumad-updater, por native messaging), que descarga la versión
// publicada, comprueba su firma y la instala en su carpeta. La extensión no
// descarga código: solo pide comprobar o aplicar y después se recarga.
//
// Si el navegador carga ScutumAD desde otra carpeta (por ejemplo, la de
// desarrollo), actualizar no cambiaría esta copia: se avisa en vez de aplicar.
(() => {
  const HOST = "com.scutumad.updater";
  const ALARM = "scutumad-app-update";
  const INTERVAL_MINUTES = 6 * 60;
  const STATE_KEY = "appUpdate";
  const WINDOW_PAGE = "popup/update.html";
  let running = null;

  const runningVersion = () => chrome.runtime.getManifest().version;

  // -1, 0 o 1 ("3.0" == "3.0.0").
  function compareVersions(a, b) {
    const pa = String(a).split(".").map(Number);
    const pb = String(b).split(".").map(Number);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
      const diff = (pa[i] || 0) - (pb[i] || 0);
      if (diff) return Math.sign(diff);
    }
    return 0;
  }

  async function readState() {
    return (await chrome.storage.local.get(STATE_KEY))[STATE_KEY] || {};
  }

  async function writeState(patch) {
    const next = { ...await readState(), ...patch };
    await chrome.storage.local.set({ [STATE_KEY]: next });
    return next;
  }

  async function ask(cmd) {
    try {
      const response = await chrome.runtime.sendNativeMessage(HOST, { cmd });
      if (!response?.ok) return { helper: true, status: response?.status, error: response?.error || "El actualizador no respondió" };
      return { helper: true, status: response.status };
    } catch {
      // El ayudante no está instalado o no está registrado en este navegador.
      return { helper: false, error: null };
    }
  }

  // La copia que se ejecuta es la que gestiona el ayudante si tienen la misma versión.
  function isManaged(status) {
    return Boolean(status?.current) && compareVersions(status.current, runningVersion()) === 0;
  }

  function summary(status) {
    const latest = status?.latest;
    return {
      helper: true,
      helperVersion: status?.current || null,
      extensionDir: status?.extensionDir || null,
      previous: status?.previous || null,
      managed: isManaged(status),
      latest: latest ? { version: latest.version, published: latest.published, notes: latest.notes || [] } : null,
      available: Boolean(latest) && compareVersions(latest.version, runningVersion()) > 0
    };
  }

  // Ventana pequeña de aviso: "available" (hay versión nueva) o "updated"
  // (ScutumAD acaba de actualizarse).
  const WINDOW_WIDTH = 400;
  const WINDOW_HEIGHT = 360;

  // Arriba a la derecha de la ventana del navegador, justo bajo la barra de
  // extensiones (donde está el icono de ScutumAD), con un pequeño margen.
  async function windowPosition() {
    try {
      const browser = await chrome.windows.getLastFocused({ windowTypes: ["normal"] });
      if (!Number.isFinite(browser?.left) || !Number.isFinite(browser?.width)) return {};
      return {
        left: Math.max(browser.left, browser.left + browser.width - WINDOW_WIDTH - 16),
        top: (browser.top || 0) + 88
      };
    } catch {
      return {};
    }
  }

  async function openUpdateWindow(mode) {
    const options = {
      url: chrome.runtime.getURL(`${WINDOW_PAGE}?mode=${mode}`),
      type: "popup", width: WINDOW_WIDTH, height: WINDOW_HEIGHT, focused: true
    };
    try {
      try {
        await chrome.windows.create({ ...options, ...await windowPosition() });
      } catch {
        // Chrome rechaza una posición fuera de la pantalla (p. ej. con dos
        // monitores): entonces se abre donde decida el navegador.
        await chrome.windows.create(options);
      }
    } catch {
      // Sin ventanas del navegador abiertas no se puede mostrar; no es un error.
    }
  }

  async function notify(latest) {
    const state = await readState();
    if (state.notifiedVersion === latest.version) return;
    await writeState({ notifiedVersion: latest.version });
    await openUpdateWindow("available");
  }

  // manual: el usuario pulsó «Buscar actualizaciones» (no aplica sola aunque
  // esté activado el modo automático, para que vea antes qué hay de nuevo).
  async function check({ manual = false } = {}) {
    if (running) return running;
    running = (async () => {
      const result = await ask("check");
      if (!result.helper) return writeState({ helper: false, checkedAt: Date.now(), error: null });
      const state = await writeState({ ...summary(result.status), checkedAt: Date.now(), error: result.error || null });
      if (result.error || !state.available || !state.managed) return state;

      const { autoUpdateApp } = await chrome.storage.local.get({ autoUpdateApp: false });
      if (!manual && autoUpdateApp && state.latest.version !== state.skippedVersion) {
        return applyNow();
      }
      // En la búsqueda manual ya se ve en Configuración: sin ventana.
      if (!manual) await notify(state.latest);
      return state;
    })().finally(() => { running = null; });
    return running;
  }

  async function reloadInto(version, patch = {}) {
    await writeState({ ...patch, pendingVersion: version, error: null });
    // Deja tiempo para que la página que lo pidió reciba la respuesta.
    setTimeout(() => chrome.runtime.reload(), 800);
    return { ...await readState(), reloading: true };
  }

  async function applyNow() {
    const result = await ask("apply");
    if (!result.helper) return writeState({ helper: false });
    if (result.error) return writeState({ error: result.error });
    const installed = result.status?.current;
    if (installed && compareVersions(installed, runningVersion()) > 0) {
      return reloadInto(installed, { skippedVersion: null, announceUpdate: true });
    }
    return writeState({ ...summary(result.status), error: null });
  }

  async function apply() {
    if (running) await running.catch(() => {});
    return applyNow();
  }

  // Vuelve a la versión anterior y no vuelve a instalar sola la que se deja.
  async function rollback() {
    const leaving = runningVersion();
    const result = await ask("rollback");
    if (!result.helper) return writeState({ helper: false });
    if (result.error) return writeState({ error: result.error });
    const installed = result.status?.current;
    if (installed && compareVersions(installed, leaving) !== 0) {
      return reloadInto(installed, { skippedVersion: leaving, announceUpdate: false });
    }
    return writeState({ ...summary(result.status), error: null });
  }

  // Tras recargar: comprueba que el navegador cargó la versión instalada.
  async function confirmPendingReload() {
    const state = await readState();
    if (!state.pendingVersion) return;
    if (compareVersions(state.pendingVersion, runningVersion()) === 0) {
      const notes = state.latest?.version === runningVersion() ? state.latest.notes || [] : [];
      await writeState({ pendingVersion: null, announceUpdate: false, lastApplied: { version: runningVersion(), at: Date.now(), notes }, available: false, managed: true, error: null });
      // Volver atrás marca announceUpdate=false; una versión anterior a esta
      // no lo marca, y también es una actualización.
      if (state.announceUpdate !== false) await openUpdateWindow("updated");
    } else {
      await writeState({
        pendingVersion: null,
        managed: false,
        error: `Se instaló la versión ${state.pendingVersion}, pero el navegador carga ScutumAD desde otra carpeta.`
      });
    }
  }

  async function status() {
    return { ...await readState(), running: runningVersion() };
  }

  function scheduleChecks() {
    chrome.alarms?.create(ALARM, { delayInMinutes: 2, periodInMinutes: INTERVAL_MINUTES });
  }

  chrome.alarms?.onAlarm.addListener((alarm) => {
    if (alarm.name === ALARM) void check();
  });

  void confirmPendingReload().catch(() => {});

  globalThis.ScutumADAppUpdater = Object.freeze({
    check, apply, rollback, status, scheduleChecks, compareVersions
  });
})();
