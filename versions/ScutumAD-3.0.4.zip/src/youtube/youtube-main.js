(() => {
  "use strict";

  // YouTube detecta que un anuncio se acelera o se salta, y entonces bloquea
  // el vídeo o avisa del bloqueador. Por eso los anuncios se quitan antes de
  // que existan: se borran de los datos que recibe el reproductor
  // (adPlacements, adSlots, playerAds) y las peticiones del reproductor se
  // identifican como de un anuncio, para las que YouTube no sirve publicidad.
  // Solo se borran o cambian datos; no se descarga ni se ejecuta código.
  const AD_KEYS = ["adPlacements", "adSlots", "playerAds"];
  const AD_RESPONSE_URL = /playlist\?list=|\/player(?!.*get_drm_license)|watch\?[tv]=|get_watch\?/;
  const AD_BREAK_URL = /\/youtubei\/v1\/player\/ad_break/;
  const SKIP_SELECTOR = [
    ".ytp-ad-skip-button",
    ".ytp-ad-skip-button-modern",
    ".ytp-skip-ad-button",
    "button.ytp-ad-skip-button",
    "button[class*='ytp-ad-skip-button']"
  ].join(",");
  const GUARD_DELAY = 90;
  const GUARD_INTERVAL = 750;
  const defineProperty = Object.defineProperty;
  const apply = Reflect.apply;
  const nativeParse = JSON.parse;
  const nativeStringify = JSON.stringify;
  let enabled = true;

  // El estado llega por un MessagePort entregado por el content script antes
  // de que se ejecute la página. Un evento del DOM lo podría falsificar la
  // propia web para desactivar la protección.
  function connectBridge(name, onMessage) {
    const listener = (event) => {
      if (event.source !== window || event.data?.scutumadBridge !== name || !event.ports?.[0]) return;
      event.stopImmediatePropagation();
      window.removeEventListener("message", listener, true);
      event.ports[0].onmessage = (message) => onMessage(message.data);
    };
    window.addEventListener("message", listener, true);
  }

  const isObject = (value) => value !== null && typeof value === "object";

  // Borra los anuncios de una respuesta del reproductor (o de su playerResponse).
  function stripAds(data, keys = AD_KEYS) {
    if (!isObject(data)) return data;
    for (const target of [data, data.playerResponse]) {
      if (!isObject(target)) continue;
      for (const key of keys) delete target[key];
    }
    return data;
  }

  // Shorts: quita las entradas que son anuncios.
  function stripShortsAds(data) {
    if (Array.isArray(data?.entries)) {
      for (let index = data.entries.length - 1; index >= 0; index--) {
        if (isObject(data.entries[index]?.command?.reelWatchEndpoint?.adClientParams)
            && "isAd" in data.entries[index].command.reelWatchEndpoint.adClientParams) {
          data.entries.splice(index, 1);
        }
      }
    }
    return data;
  }

  // Llama a edit(valor) cada vez que la página asigna owner[key].
  function onAssign(owner, key, edit) {
    let current = owner[key];
    if (isObject(current)) edit(current);
    try {
      defineProperty(owner, key, {
        configurable: true,
        enumerable: true,
        get: () => current,
        set: (next) => {
          current = next;
          if (isObject(next)) edit(next);
        }
      });
    } catch {}
  }

  // Fija el valor de owner.a.b.c aunque la página cree los objetos más tarde.
  function forceValue(owner, path, value) {
    const [key, ...rest] = path;
    if (rest.length) {
      onAssign(owner, key, (next) => forceValue(next, rest, value));
      return;
    }
    let current = owner[key];
    try {
      defineProperty(owner, key, {
        configurable: true,
        enumerable: true,
        get: () => (enabled ? value : current),
        set: (next) => { current = next; }
      });
    } catch {}
  }

  function editJsonText(text) {
    try {
      const data = nativeParse(text);
      if (!isObject(data) || !AD_KEYS.some((key) => key in data || (isObject(data.playerResponse) && key in data.playerResponse))) return text;
      return nativeStringify(stripAds(data));
    } catch {
      return text;
    }
  }

  function hookJson() {
    JSON.parse = new Proxy(nativeParse, {
      apply(target, thisArg, args) {
        const data = apply(target, thisArg, args);
        if (!enabled || !isObject(data)) return data;
        // Con streaming SABR, la respuesta trae su propia URL y sus anuncios.
        if (data.playerResponse?.streamingData?.serverAbrStreamingUrl) stripAds(data, ["adPlacements", "adSlots"]);
        return stripShortsAds(data);
      }
    });
    JSON.stringify = new Proxy(nativeStringify, {
      apply(target, thisArg, args) {
        const text = apply(target, thisArg, args);
        if (!enabled || typeof text !== "string") return text;
        // La petición del reproductor se presenta como de un anuncio: YouTube
        // no inserta publicidad en ella.
        return text
          .split('"clientScreen":"WATCH"').join('"clientScreen":"ADUNIT"')
          .split('isWebNativeShareAvailable":true}}').join('isWebNativeShareAvailable":true},"clientScreen":"ADUNIT"}');
      }
    });
  }

  function hookFetch() {
    if (typeof window.fetch !== "function") return;
    window.fetch = new Proxy(window.fetch, {
      apply(target, thisArg, args) {
        const resource = args[0];
        const url = String(typeof Request === "function" && resource instanceof Request ? resource.url : resource);
        if (enabled && AD_BREAK_URL.test(url)) return Promise.reject(new TypeError("Failed to fetch"));
        const result = apply(target, thisArg, args);
        if (!enabled || !AD_RESPONSE_URL.test(url)) return result;
        return result.then((response) => response.clone().text().then((text) => {
          const edited = editJsonText(text);
          if (edited === text) return response;
          const clean = new Response(edited, { status: response.status, statusText: response.statusText, headers: response.headers });
          try {
            defineProperty(clean, "url", { value: response.url });
            defineProperty(clean, "redirected", { value: response.redirected });
            defineProperty(clean, "type", { value: response.type });
          } catch {}
          return clean;
        }).catch(() => response));
      }
    });
  }

  function hookXhr() {
    if (typeof XMLHttpRequest !== "function") return;
    const proto = XMLHttpRequest.prototype;
    const urls = new WeakMap();
    const cache = new WeakMap();
    const open = proto.open;
    proto.open = new Proxy(open, {
      apply(target, thisArg, args) {
        urls.set(thisArg, String(args[1]));
        return apply(target, thisArg, args);
      }
    });
    for (const name of ["response", "responseText"]) {
      const descriptor = Object.getOwnPropertyDescriptor(proto, name);
      if (!descriptor?.get) continue;
      defineProperty(proto, name, {
        ...descriptor,
        get() {
          const value = apply(descriptor.get, this, []);
          if (!enabled || this.readyState !== 4 || typeof value !== "string" || !AD_RESPONSE_URL.test(urls.get(this) || "")) return value;
          const cached = cache.get(this);
          if (cached?.source === value) return cached.result;
          const result = editJsonText(value);
          cache.set(this, { source: value, result });
          return result;
        }
      });
    }
  }

  // Temporizadores con los que YouTube retrasa el vídeo si cree que hay bloqueador.
  function hookTimers() {
    window.setTimeout = new Proxy(window.setTimeout, {
      apply(target, thisArg, args) {
        const [callback, delay] = args;
        if (enabled && typeof callback === "function") {
          const code = String(callback);
          if (Number(delay) === 17000 && code.includes("[native code]")) {
            return apply(target, thisArg, [callback, 17, ...args.slice(2)]);
          }
          if (Number(delay) === 5000 && code.includes("(),a,b)")) return 0;
        }
        return apply(target, thisArg, args);
      }
    });
  }

  function installShield() {
    onAssign(window, "ytInitialPlayerResponse", (data) => enabled && stripAds(data));
    onAssign(window, "playerResponse", (data) => enabled && stripAds(data, ["adPlacements"]));
    forceValue(window, ["google_ad_status"], 1);
    forceValue(window, ["ytcfg", "data_", "EXPERIMENT_FLAGS", "web_streaming_watch"], false);
    hookJson();
    hookFetch();
    hookXhr();
    hookTimers();
  }

  // Respaldo: si aun así aparece un anuncio con botón de saltar, se pulsa.
  // No se acelera ni se adelanta el vídeo: YouTube lo detecta.
  function skipCurrentAd() {
    if (!enabled) return;
    const player = document.querySelector("#movie_player, .html5-video-player");
    if (!player?.classList.contains("ad-showing")) return;
    player.querySelectorAll(SKIP_SELECTOR).forEach((button) => {
      if (button instanceof HTMLElement && !button.hidden && button.getClientRects().length > 0) {
        try {
          button.click();
        } catch {
          // El botón puede desaparecer durante la navegación interna.
        }
      }
    });
  }

  function beginPlayerGuard() {
    let guardTimer = null;
    const scheduleGuard = () => {
      if (guardTimer) {
        return;
      }
      guardTimer = window.setTimeout(() => {
        guardTimer = null;
        skipCurrentAd();
      }, GUARD_DELAY);
    };

    const mutationNeedsGuard = (record) => {
      const target = record.target instanceof Element ? record.target : null;
      if (target?.closest?.("#movie_player, .html5-video-player")) {
        return true;
      }
      return [...record.addedNodes].some((node) => {
        if (!(node instanceof Element)) {
          return false;
        }
        try {
          return node.matches("#movie_player, .html5-video-player, " + SKIP_SELECTOR)
            || Boolean(node.closest("#movie_player, .html5-video-player"));
        } catch {
          return false;
        }
      });
    };

    const startObserver = () => {
      const root = document.documentElement || document;
      const observer = new MutationObserver((records) => {
        if (records.some(mutationNeedsGuard)) {
          scheduleGuard();
        }
      });
      observer.observe(root, {
        attributes: true,
        attributeFilter: ["class", "hidden", "aria-label"],
        childList: true,
        subtree: true
      });
      scheduleGuard();
      // Respaldo limitado al reproductor activo para variantes que no
      // notifican sus cambios de clase.
      window.setInterval(scheduleGuard, GUARD_INTERVAL);
    };

    if (document.documentElement) {
      startObserver();
    } else {
      document.addEventListener("readystatechange", startObserver, { once: true });
    }
  }

  connectBridge("youtube", (message) => {
    if (message?.type !== "state") return;
    enabled = message.enabled !== false;
    skipCurrentAd();
  });

  installShield();
  beginPlayerGuard();
})();
