(() => {
  "use strict";

  // Texto de versión para el menú y Configuración: "v3.0.6 · 03/11/2026".
  // La fecha la escribe scripts/package.mjs en release.json al publicar; en
  // una copia sin publicar solo se muestra la versión.
  function formatDate(date) {
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(date || ""));
    return match ? `${match[3]}/${match[2]}/${match[1]}` : "";
  }

  async function versionText() {
    const version = chrome.runtime.getManifest().version;
    try {
      const release = await (await fetch(chrome.runtime.getURL("release.json"))).json();
      const date = release.version === version ? formatDate(release.date) : "";
      if (date) return `v${version} · ${date}`;
    } catch {}
    return `v${version}`;
  }

  globalThis.ScutumADVersion = Object.freeze({ formatDate, versionText });
})();
