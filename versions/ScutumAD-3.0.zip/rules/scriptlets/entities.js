// Generado por scripts/build-rules.mjs a partir de src/scriptlets/engine.js.
// Motor de scriptlets de ScutumAD (implementación propia, compatible con los
// nombres de uBlock Origin y Adblock Plus). Se ejecuta en el mundo MAIN antes
// que la página. RULES_PLACEHOLDER se sustituye por { rules, exceptions }:
// en la publicación (rules/scriptlets.js) o al actualizar las listas.
(function scutumadScriptlets(data) {
  "use strict";
  const hostname = location.hostname.toLowerCase().replace(/\.$/, "");
  if (!hostname) return;

  // Claves que aplican a este host: el dominio y sus padres, y las
  // entidades (ejemplo.*) cuando quedan como mucho dos etiquetas de TLD.
  const labels = hostname.split(".");
  const keys = [];
  for (let start = 0; start < labels.length; start++) {
    keys.push(labels.slice(start).join("."));
    for (let end = Math.max(start + 1, labels.length - 2); end < labels.length; end++) {
      keys.push(`${labels.slice(start, end).join(".")}.*`);
    }
  }
  const exceptions = new Set(keys.flatMap((key) => data.exceptions[key] || []));
  if (exceptions.has("*")) return;
  const seen = new Set();
  const rules = keys.flatMap((key) => data.rules[key] || []).filter((rule) => {
    const signature = rule.join("\u0000");
    if (seen.has(signature) || exceptions.has(signature)) return false;
    seen.add(signature);
    return true;
  });
  if (!rules.length) return;

  const MARKER = `scutumad-${Math.random().toString(36).slice(2)}`;
  const defineProperty = Object.defineProperty;
  const getDescriptor = Object.getOwnPropertyDescriptor;
  const apply = Reflect.apply;

  window.addEventListener("error", (event) => {
    if (typeof event.message === "string" && event.message.includes(MARKER)) event.preventDefault();
  }, true);
  const abort = () => {
    throw new ReferenceError(MARKER);
  };

  // Aguja: texto o /regex/flags; "!" delante invierte; vacía casa con todo.
  function matcher(needle = "") {
    let negate = false;
    let text = String(needle);
    if (text.startsWith("!")) {
      negate = true;
      text = text.slice(1);
    }
    if (!text) return () => !negate;
    const regex = /^\/(.+)\/([gimsu]*)$/.exec(text);
    let test;
    if (regex) {
      try {
        const pattern = new RegExp(regex[1], regex[2].replace("g", ""));
        test = (value) => pattern.test(value);
      } catch {
        return () => false;
      }
    } else {
      test = (value) => value.includes(text);
    }
    return (value) => test(String(value)) !== negate;
  }

  function regexOrText(value) {
    const regex = /^\/(.+)\/([gimsu]*)$/.exec(value);
    if (regex) {
      try {
        return new RegExp(regex[1], regex[2]);
      } catch {
        return null;
      }
    }
    return value;
  }

  const noop = () => {};
  function constantValue(raw, extra = []) {
    const factories = {
      undefined: () => undefined, false: () => false, true: () => true, null: () => null,
      "": () => "", emptyStr: () => "",
      noopFunc: () => noop, trueFunc: () => () => true, falseFunc: () => () => false,
      throwFunc: () => () => { throw new Error(); }, noopCallbackFunc: () => () => noop,
      emptyArray: () => [], "[]": () => [], emptyObj: () => ({}), "{}": () => ({}),
      yes: () => "yes", no: () => "no", on: () => "on", off: () => "off"
    };
    let value;
    if (Object.prototype.hasOwnProperty.call(factories, raw)) {
      value = factories[raw]();
    } else if (/^-?\d+(?:\.\d+)?$/.test(raw) && Math.abs(Number(raw)) <= 0x7fff) {
      value = Number(raw);
    } else {
      return { ok: false };
    }
    if (extra.includes("asFunction")) {
      const inner = value;
      value = () => inner;
    } else if (extra.includes("asCallback")) {
      const inner = value;
      value = () => () => inner;
    } else if (extra.includes("asResolved")) {
      value = Promise.resolve(value);
    } else if (extra.includes("asRejected")) {
      value = Promise.reject(value);
    }
    return { ok: true, value };
  }

  // Getter/setter en el último eslabón de `chain` (a.b.c). Si un eslabón aún
  // no existe, espera a que la página lo cree.
  function trapChain(owner, chain, makeDescriptor) {
    const dot = chain.indexOf(".");
    const name = dot < 0 ? chain : chain.slice(0, dot);
    const rest = dot < 0 ? "" : chain.slice(dot + 1);
    if (!rest) {
      const current = getDescriptor(owner, name);
      if (current && current.configurable === false) return;
      try {
        defineProperty(owner, name, { configurable: true, ...makeDescriptor(current, owner) });
      } catch {
        // Propiedad protegida.
      }
      return;
    }
    const next = owner[name];
    if (next && (typeof next === "object" || typeof next === "function")) {
      trapChain(next, rest, makeDescriptor);
      return;
    }
    let value = next;
    try {
      defineProperty(owner, name, {
        configurable: true,
        get: () => value,
        set(newValue) {
          value = newValue;
          if (newValue && (typeof newValue === "object" || typeof newValue === "function")) {
            trapChain(newValue, rest, makeDescriptor);
          }
        }
      });
    } catch {
      // Propiedad protegida.
    }
  }

  function holder(current, owner) {
    let value = current && "value" in current ? current.value : undefined;
    return {
      read: () => (current?.get ? apply(current.get, owner, []) : value),
      write: (newValue) => (current?.set ? apply(current.set, owner, [newValue]) : (value = newValue))
    };
  }

  function guardedChain(chain, shouldAbort) {
    trapChain(window, chain, (current, owner) => {
      const store = holder(current, owner);
      return {
        get() {
          if (shouldAbort()) abort();
          return store.read();
        },
        set(newValue) {
          if (shouldAbort()) abort();
          store.write(newValue);
        }
      };
    });
  }

  // Rutas de json-prune: a.b, [] (cada elemento) y [-] (quita el elemento
  // del array si contiene el resto de la ruta).
  function prune(object, parts) {
    if (!object || typeof object !== "object") return false;
    const [part, ...rest] = parts;
    if (part === "[]") {
      if (!Array.isArray(object)) return false;
      let changed = false;
      object.forEach((item) => { changed = prune(item, rest) || changed; });
      return changed;
    }
    if (part === "[-]") {
      if (!Array.isArray(object)) return false;
      let changed = false;
      for (let index = object.length - 1; index >= 0; index--) {
        if (hasPath(object[index], rest)) {
          object.splice(index, 1);
          changed = true;
        }
      }
      return changed;
    }
    if (!rest.length) {
      if (!(part in object)) return false;
      delete object[part];
      return true;
    }
    return prune(object[part], rest);
  }

  function hasPath(object, parts) {
    let current = object;
    for (const part of parts) {
      if (part === "[]" || part === "[-]") {
        return Array.isArray(current) && current.some((item) => hasPath(item, parts.slice(parts.indexOf(part) + 1)));
      }
      if (!current || typeof current !== "object" || !(part in current)) return false;
      current = current[part];
    }
    return true;
  }

  function pruner(prunePaths = "", neededPaths = "") {
    const toPrune = prunePaths.split(/\s+/).filter(Boolean).map((path) => path.split("."));
    const needed = neededPaths.split(/\s+/).filter(Boolean).map((path) => path.split("."));
    return (value) => {
      if (value && typeof value === "object" && needed.every((path) => hasPath(value, path))) {
        toPrune.forEach((path) => prune(value, path));
      }
      return value;
    };
  }

  // Argumentos "propsToMatch, valor" al final de algunos scriptlets.
  function propsToMatch(args) {
    const index = args.indexOf("propsToMatch");
    return index >= 0 ? args[index + 1] || "" : "";
  }

  // "url:x method:POST" o simplemente "x" (que se compara con la URL).
  function requestMatcher(needle = "") {
    if (!needle || needle === "*") return () => true;
    const tests = needle.split(/\s+/).filter(Boolean).map((part) => {
      const colon = part.indexOf(":");
      const known = colon > 0 && ["url", "method", "body", "headers", "mode", "credentials"].includes(part.slice(0, colon));
      const key = known ? part.slice(0, colon) : "url";
      return [key, matcher(known ? part.slice(colon + 1) : part)];
    });
    return (details) => tests.every(([key, test]) => test(details[key] ?? ""));
  }

  function fetchDetails(args) {
    const [resource, init = {}] = args;
    const isRequest = typeof Request === "function" && resource instanceof Request;
    return {
      url: String(isRequest ? resource.url : resource),
      method: String(init.method || (isRequest ? resource.method : "GET")).toUpperCase(),
      body: typeof init.body === "string" ? init.body : ""
    };
  }

  function rebuildResponse(original, text) {
    const response = new Response(text, {
      status: original.status, statusText: original.statusText, headers: original.headers
    });
    try {
      defineProperty(response, "url", { value: original.url });
      defineProperty(response, "redirected", { value: original.redirected });
      defineProperty(response, "type", { value: original.type });
    } catch {}
    return response;
  }

  const fetchFilters = [];
  function hookFetch() {
    if (hookFetch.done || typeof fetch !== "function") return;
    hookFetch.done = true;
    window.fetch = new Proxy(window.fetch, {
      apply(target, thisArg, args) {
        const details = fetchDetails(args);
        for (const filter of fetchFilters) {
          if (filter.block && filter.matches(details)) {
            return Promise.resolve(new Response(filter.body || "", { status: 200, statusText: "OK" }));
          }
        }
        const editors = fetchFilters.filter((filter) => !filter.block && filter.matches(details));
        const result = apply(target, thisArg, args);
        if (!editors.length) return result;
        return result.then((response) => response.clone().text().then((text) => {
          let edited = text;
          for (const editor of editors) edited = editor.edit(edited);
          return edited === text ? response : rebuildResponse(response, edited);
        }).catch(() => response));
      }
    });
  }

  const xhrFilters = [];
  const xhrState = new WeakMap();
  function hookXhr() {
    if (hookXhr.done || typeof XMLHttpRequest !== "function") return;
    hookXhr.done = true;
    const proto = XMLHttpRequest.prototype;
    const open = proto.open;
    const send = proto.send;
    proto.open = function scutumadOpen(method, url, ...rest) {
      xhrState.set(this, { method: String(method).toUpperCase(), url: String(url) });
      return apply(open, this, [method, url, ...rest]);
    };
    proto.send = function scutumadSend(...args) {
      const state = xhrState.get(this);
      const blocked = state && xhrFilters.find((filter) => filter.block && filter.matches(state));
      if (!blocked) return apply(send, this, args);
      const xhr = this;
      defineProperty(xhr, "readyState", { value: 4, configurable: true });
      defineProperty(xhr, "status", { value: 200, configurable: true });
      defineProperty(xhr, "statusText", { value: "OK", configurable: true });
      defineProperty(xhr, "responseText", { value: blocked.body || "", configurable: true });
      defineProperty(xhr, "response", { value: blocked.body || "", configurable: true });
      setTimeout(() => {
        for (const type of ["readystatechange", "load", "loadend"]) xhr.dispatchEvent(new Event(type));
      }, 1);
      return undefined;
    };
    for (const name of ["response", "responseText"]) {
      const descriptor = getDescriptor(proto, name);
      if (!descriptor?.get) continue;
      defineProperty(proto, name, {
        ...descriptor,
        get() {
          const value = apply(descriptor.get, this, []);
          const state = xhrState.get(this);
          if (!state || this.readyState !== 4 || typeof value !== "string" && name === "responseText") return value;
          const editors = xhrFilters.filter((filter) => !filter.block && filter.matches(state));
          if (!editors.length) return value;
          if (state.cache && state.cache.source === value) return state.cache.result;
          let text = typeof value === "string" ? value : value && typeof value === "object" ? JSON.stringify(value) : value;
          if (typeof text !== "string") return value;
          for (const editor of editors) text = editor.edit(text);
          const result = typeof value === "string" ? text : JSON.parse(text);
          state.cache = { source: value, result };
          return result;
        }
      });
    }
  }

  function jsonEditor(prunePaths, neededPaths) {
    const prunePaths_ = pruner(prunePaths, neededPaths);
    return (text) => {
      try {
        const object = JSON.parse(text);
        prunePaths_(object);
        return JSON.stringify(object);
      } catch {
        return text;
      }
    };
  }

  function textEditor(pattern, replacement = "") {
    const target = regexOrText(pattern);
    if (target === null || target === "") return (text) => text;
    return (text) => (typeof target === "string" ? text.split(target).join(replacement) : text.replace(target, replacement));
  }

  function timerFilter(name, needle, delayArg, transform) {
    const test = matcher(needle);
    const delayTest = delayArg === undefined || delayArg === "" || delayArg === "*"
      ? () => true
      : (delay) => {
        const negate = delayArg.startsWith("!");
        const expected = Number(negate ? delayArg.slice(1) : delayArg);
        return (Number(delay) === expected) !== negate;
      };
    const native = window[name];
    window[name] = new Proxy(native, {
      apply(target, thisArg, args) {
        const [callback, delay] = args;
        if (test(String(callback)) && delayTest(delay)) {
          const next = transform(args);
          if (!next) return 0;
          return apply(target, thisArg, next);
        }
        return apply(target, thisArg, args);
      }
    });
  }

  function onDomReady(callback) {
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", callback, { once: true });
    else callback();
  }

  function domEditor(selector, edit, behavior = "") {
    const run = () => {
      try {
        document.querySelectorAll(selector).forEach(edit);
      } catch {}
    };
    if (behavior.includes("asap")) run();
    onDomReady(run);
    if (behavior.includes("stay") || behavior.includes("complete")) {
      const start = () => {
        run();
        if (behavior.includes("stay")) {
          new MutationObserver(run).observe(document.documentElement, { childList: true, subtree: true, attributes: true });
        }
      };
      if (behavior.includes("complete")) window.addEventListener("load", start, { once: true });
      else onDomReady(start);
    }
  }

  function storageItem(storageName, key, rawValue) {
    if (!key) return;
    let storage;
    try {
      storage = window[storageName];
    } catch {
      return;
    }
    if (rawValue === "$remove$") {
      try { storage.removeItem(key); } catch {}
      return;
    }
    const allowed = { undefined: "undefined", false: "false", true: "true", null: "null", "": "", emptyArr: "[]", emptyObj: "{}", yes: "yes", no: "no", on: "on", off: "off" };
    let value = allowed[rawValue];
    if (value === undefined && /^\d+$/.test(rawValue) && Number(rawValue) <= 0x7fff) value = rawValue;
    if (value === undefined) return;
    try { storage.setItem(key, value); } catch {}
  }

  function noAdBlockDetector() {
    class Detector {
      constructor() { this.callbacks = []; }
      setOption() { return this; }
      check() { this.callbacks.forEach((callback) => { try { callback(); } catch {} }); return true; }
      emitEvent() { return this; }
      clearEvent() {}
      on(detected, callback) { if (!detected) this.onNotDetected(callback); return this; }
      onDetected() { return this; }
      onNotDetected(callback) {
        if (typeof callback === "function") {
          this.callbacks.push(callback);
          setTimeout(() => { try { callback(); } catch {} }, 1);
        }
        return this;
      }
    }
    for (const name of ["FuckAdBlock", "BlockAdBlock", "SniffAdBlock"]) {
      try {
        defineProperty(window, name, { value: Detector, configurable: true, writable: true });
        defineProperty(window, name.charAt(0).toLowerCase() + name.slice(1), { value: new Detector(), configurable: true, writable: true });
      } catch {}
    }
  }

  const scriptlets = {
    "abort-on-property-read"(chain) {
      trapChain(window, chain, () => ({ get: abort, set() {} }));
    },
    "abort-on-property-write"(chain) {
      trapChain(window, chain, (current, owner) => ({ get: holder(current, owner).read, set: abort }));
    },
    "abort-current-script"(chain, needle, inlineOnly) {
      const test = matcher(needle);
      guardedChain(chain, () => {
        const script = document.currentScript;
        if (!(script instanceof HTMLScriptElement)) return false;
        if (script.src) return inlineOnly !== "inline" && test(script.src);
        return test(script.textContent || "");
      });
    },
    "abort-on-stack-trace"(chain, needle) {
      const test = matcher(needle);
      guardedChain(chain, () => test(new Error().stack || ""));
    },
    "set-constant"(chain, raw, ...extra) {
      const constant = constantValue(raw, extra);
      if (!constant.ok) return;
      trapChain(window, chain, () => ({ get: () => constant.value, set() {} }));
    },
    "no-setTimeout-if"(needle, delay) {
      timerFilter("setTimeout", needle, delay, () => null);
    },
    "no-setInterval-if"(needle, delay) {
      timerFilter("setInterval", needle, delay, () => null);
    },
    "nano-setTimeout-booster"(needle, delay = "1000", boost = "0.05") {
      const factor = Math.min(50, Math.max(0.001, Number(boost) || 0.05));
      timerFilter("setTimeout", needle, delay, ([callback, wait, ...rest]) => [callback, (Number(wait) || 0) * factor, ...rest]);
    },
    "nano-setInterval-booster"(needle, delay = "1000", boost = "0.05") {
      const factor = Math.min(50, Math.max(0.001, Number(boost) || 0.05));
      timerFilter("setInterval", needle, delay, ([callback, wait, ...rest]) => [callback, (Number(wait) || 0) * factor, ...rest]);
    },
    "addEventListener-defuser"(type, needle) {
      const typeTest = matcher(type);
      const test = matcher(needle);
      const native = EventTarget.prototype.addEventListener;
      EventTarget.prototype.addEventListener = new Proxy(native, {
        apply(target, thisArg, args) {
          const [eventType, handler] = args;
          if (typeTest(eventType) && test(String(handler))) return undefined;
          return apply(target, thisArg, args);
        }
      });
    },
    "window.open-defuser"(needle) {
      const test = matcher(needle);
      const decoy = () => ({ closed: false, close: noop, focus: noop, blur: noop, postMessage: noop,
        document: { write: noop, writeln: noop, close: noop, open: noop }, location: {} });
      window.open = new Proxy(window.open, {
        apply(target, thisArg, args) {
          if (test(String(args[0] ?? ""))) return decoy();
          return apply(target, thisArg, args);
        }
      });
    },
    "no-fetch-if"(needle, body) {
      fetchFilters.push({ block: true, matches: requestMatcher(needle), body: body === "emptyObj" ? "{}" : body === "emptyArr" ? "[]" : "" });
      hookFetch();
    },
    "no-xhr-if"(needle, body) {
      xhrFilters.push({ block: true, matches: requestMatcher(needle), body: body === "emptyObj" ? "{}" : body === "emptyArr" ? "[]" : "" });
      hookXhr();
    },
    "json-prune"(prunePaths, neededPaths) {
      const run = pruner(prunePaths, neededPaths);
      JSON.parse = new Proxy(JSON.parse, {
        apply: (target, thisArg, args) => run(apply(target, thisArg, args))
      });
      Response.prototype.json = new Proxy(Response.prototype.json, {
        apply: (target, thisArg, args) => apply(target, thisArg, args).then(run)
      });
    },
    "json-prune-fetch-response"(prunePaths, neededPaths, ...rest) {
      fetchFilters.push({ matches: requestMatcher(propsToMatch(rest)), edit: jsonEditor(prunePaths, neededPaths) });
      hookFetch();
    },
    "json-prune-xhr-response"(prunePaths, neededPaths, ...rest) {
      xhrFilters.push({ matches: requestMatcher(propsToMatch(rest)), edit: jsonEditor(prunePaths, neededPaths) });
      hookXhr();
    },
    "trusted-replace-fetch-response"(pattern, replacement, needle) {
      fetchFilters.push({ matches: requestMatcher(needle), edit: textEditor(pattern, replacement) });
      hookFetch();
    },
    "trusted-replace-xhr-response"(pattern, replacement, needle) {
      xhrFilters.push({ matches: requestMatcher(needle), edit: textEditor(pattern, replacement) });
      hookXhr();
    },
    "remove-attr"(attributes, selector, behavior) {
      const names = String(attributes || "").split("|").filter(Boolean);
      if (!names.length) return;
      domEditor(selector || names.map((name) => `[${CSS.escape(name)}]`).join(","),
        (element) => names.forEach((name) => element.removeAttribute(name)), behavior);
    },
    "remove-class"(classes, selector, behavior) {
      const names = String(classes || "").split("|").filter(Boolean);
      if (!names.length) return;
      domEditor(selector || names.map((name) => `.${CSS.escape(name)}`).join(","),
        (element) => element.classList.remove(...names), behavior);
    },
    "remove-cookie"(needle) {
      const test = matcher(needle);
      const remove = () => {
        document.cookie.split(";").forEach((cookie) => {
          const name = cookie.split("=")[0].trim();
          if (!name || !test(name)) return;
          const domains = ["", location.hostname, `.${location.hostname}`];
          for (const domain of domains) {
            document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/${domain ? `; domain=${domain}` : ""}`;
          }
        });
      };
      remove();
      window.addEventListener("beforeunload", remove);
    },
    "set-local-storage-item"(key, value) {
      storageItem("localStorage", key, value);
    },
    "set-session-storage-item"(key, value) {
      storageItem("sessionStorage", key, value);
    },
    "noeval-if"(needle) {
      const test = matcher(needle);
      window.eval = new Proxy(window.eval, {
        apply(target, thisArg, args) {
          if (test(String(args[0]))) return undefined;
          return apply(target, thisArg, args);
        }
      });
    },
    "nowebrtc"() {
      const stub = function RTCPeerConnection() {
        return { close: noop, createDataChannel: noop, createOffer: () => Promise.resolve({}),
          setLocalDescription: () => Promise.resolve(), addEventListener: noop, removeEventListener: noop };
      };
      for (const name of ["RTCPeerConnection", "webkitRTCPeerConnection", "mozRTCPeerConnection"]) {
        if (name in window) {
          try { defineProperty(window, name, { value: stub, configurable: true, writable: true }); } catch {}
        }
      }
    },
    "nobab": noAdBlockDetector
  };

  // Alias de uBlock Origin y Adblock Plus.
  const aliases = {
    aopr: "abort-on-property-read", aopw: "abort-on-property-write",
    acs: "abort-current-script", "abort-current-inline-script": "abort-current-script",
    aost: "abort-on-stack-trace", set: "set-constant", "override-property-read": "set-constant",
    nostif: "no-setTimeout-if", "prevent-setTimeout": "no-setTimeout-if",
    nosiif: "no-setInterval-if", "prevent-setInterval": "no-setInterval-if",
    "nano-stb": "nano-setTimeout-booster", "nano-sib": "nano-setInterval-booster",
    aeld: "addEventListener-defuser", "prevent-addEventListener": "addEventListener-defuser", "prevent-listener": "addEventListener-defuser",
    nowoif: "window.open-defuser", "no-window-open-if": "window.open-defuser", "prevent-window-open": "window.open-defuser",
    "prevent-fetch": "no-fetch-if", "prevent-xhr": "no-xhr-if",
    "trusted-rpfr": "trusted-replace-fetch-response", "replace-fetch-response": "trusted-replace-fetch-response",
    ra: "remove-attr", rc: "remove-class", "cookie-remover": "remove-cookie",
    noeval: "noeval-if", "silent-noeval": "noeval-if", nofab: "nobab", "bab-defuser": "nobab"
  };

  for (const [rawName, ...args] of rules) {
    const name = aliases[rawName] || rawName;
    try {
      scriptlets[name]?.(...args);
    } catch {
      // Un scriptlet fallido no debe impedir los demás.
    }
  }
})({"rules":{"0123movie.*":[["aopr","AaDetector"]],"0123movies.*":[["set","check_adblock","true"],["aopr","mm"],["abort-on-property-read","open"],["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"]],"0l23movies.*":[["aopr","rid"]],"123anime.*":[["aopr","glxopen"],["acs","setTimeout","popi"],["nowoif"]],"123animes.*":[["aopr","glxopen"],["aopr","AaDetector"]],"123link.*":[["aopr","jQuery.adblock"],["acs","$","test-block"],["acs","$","adi"],["acs","$","undefined"],["aopr","ads_block"],["aopr","blockAdBlock"],["nano-sib"],["set","blurred","false"]],"123mkv.*":[["nowoif"]],"123movierulz.*":[["nowoif"]],"123movies.*":[["aopr","open"],["abort-on-property-read","open"],["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"]],"123moviesc.*":[["aopr","mm"]],"123moviesgo.*":[["abort-on-property-write","atAsyncContainers"],["abort-current-inline-script","Math","/break|case/"]],"123moviess.*":[["acs","JSON.parse","atob"],["aost","document.createElement","inlineScript"]],"1337x.*":[["abort-on-property-write","window.onload","false"],["abort-current-inline-script","document.createElement","script"]],"1337x.unblocked.*":[["aopr","open"]],"1337x.unblockit.*":[["aopr","btoa"],["aopr","open"]],"1377x.*":[["abort-on-property-read","window.open"]],"1flix.*":[["abort-on-property-read","window.open"],["abort-current-inline-script","Array.prototype.reduce"]],"2ddl.*":[["nowebrtc"]],"3sk.*":[["abort-on-property-read","atob"],["abort-on-property-write","Fingerprint2"],["abort-on-property-read","decodeURIComponent"],["abort-on-property-read","RegExp"]],"4movierulz.*":[["aeld","","_0x"]],"5movierulz2.*":[["nowoif"]],"5movies.*":[["aopr","mm"]],"7movierulz1.*":[["nowoif"]],"7moviesrulz.*":[["nowoif"]],"7starhd.*":[["nowoif"]],"9anime.*":[["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"]],"9hentai.*":[["aeld","click","saveLastEvent"],["prevent-listener","click","saveLastEvent"]],"9xbuddy.*":[["nowoif"]],"9xupload.*":[["nano-stb"]],"absoluporn.*":[["acs","ExoLoader"]],"actvid.*":[["abort-on-property-write","window.open"],["abort-current-inline-script","addEventListener","HTMLAllCollection"]],"adblockeronstreamtape.*":[["abort-on-property-read","open"],["abort-on-property-write","_pop"],["abort-on-property-write","_pao"],["abort-current-inline-script","JSON.parse","Promise"],["abort-current-inline-script","document.createElement","adblock"]],"adblockstreamtape.*":[["abort-on-property-read","open"],["abort-on-property-write","_pop"],["abort-on-property-write","_pao"],["abort-current-inline-script","JSON.parse","Promise"],["abort-current-inline-script","document.createElement","adblock"]],"adbull.*":[["ra","onclick"]],"adfloz.*":[["nowoif"],["set","blurred","false"]],"adshort.*":[["aopw","Fingerprint2"],["nowoif"],["set","blurred","false"]],"adsrt.*":[["nowoif"],["acs","atob","decodeURIComponent"],["aopw","Fingerprint2"],["aopr","rmVideoPlay"],["set","blurred","false"]],"advertape.*":[["abort-on-property-write","window.open"],["abort-current-inline-script","EventTarget.prototype.addEventListener","delete window"],["abort-current-inline-script","WebAssembly","atob"],["abort-current-inline-script","JSON.parse","Promise"],["abort-current-inline-script","document.createElement","adblock"]],"adyou.*":[["aeld","/^(?:click|mousedown)$/","bypassEventsInProxies"]],"akoam.*":[["abort-on-property-read","String.fromCharCode"]],"akwam.*":[["abort-on-property-read","String.fromCharCode"]],"aliancapes.*":[["nostif","nextFunction","2000"]],"allcalidad.*":[["acs","doOnce"],["aeld","","0x"],["aopw","smrtSB"],["set","btoa","null"],["ra","href","#clickfakeplayer"]],"allfeeds.*":[["nowoif"]],"allitebooks.*":[["nowebrtc"]],"alphatron.*":[["abort-current-inline-script","EventTarget.prototype.addEventListener","delete"]],"androidaba.*":[["aopw","adBlockDetected"]],"anime-sama.*":[["abort-on-property-read","aclib.runBanner"]],"animeblix.*":[["nowoif"]],"animecomplet.*":[["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"]],"animefire.*":[["abort-current-inline-script","WebAssembly","atob"]],"animeflv.*":[["acs","jQuery","pp12"]],"animeheaven.*":[["no-xhr-if","method:HEAD"],["abort-on-property-write","window.open"]],"animekb.*":[["nowebrtc"]],"animepahe.*":[["acs","String.fromCharCode","shift"],["aopr","open"],["aopr","PopAds"],["abort-on-property-read","open"],["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"],["abort-on-property-read","document.querySelector"],["abort-current-inline-script","JSON.parse"],["abort-on-property-read","_0x43d1"],["abort-on-property-read","_0x53b5"]],"animeunity.*":[["abort-on-property-write","ZpQw9XkLmN8c3vR3"],["abort-current-inline-script","document.createElement","/\\.settings\\s*=\\s*\\w+\\s*\\|\\|/"]],"animeworld.*":[["abort-current-inline-script","WebAssembly","atob"]],"anisubindo.*":[["aeld","load","nextFunction"]],"anitube.*":[["aopr","exoJsPop101"],["set","adBlockDetected","noopFunc"],["abort-on-property-read","open"],["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"],["abort-current-inline-script","EventTarget.prototype.addEventListener","delete"],["abort-on-property-write","_pop"]],"aniwave.*":[["abort-current-inline-script","document.write"],["abort-on-property-read","window.open"]],"aquipelis.*":[["aopw","smrtSB"],["aopw","smrtSP"]],"arabseed.*":[["aeld","","_0x"],["abort-on-property-read","atob"],["abort-on-property-read","decodeURI"],["abort-on-property-read","decodeURIComponent"],["abort-current-inline-script","Math","zfgloaded"],["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"]],"archivebate.*":[["abort-current-inline-script","WebAssembly","atob"]],"arenavision.*":[["nowoif"]],"asia2tv.*":[["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"]],"asiaflix.*":[["abort-on-property-write","ZpQw9XkLmN8c3vR3"],["abort-current-inline-script","document.createElement","/\\.settings\\s*=\\s*\\w+\\s*\\|\\|/"]],"asiansex.*":[["aopr","popit"],["aeld","popstate","noPop"]],"asmroger.*":[["abort-current-inline-script","document.createElement","/l\\.parentNode\\.insertBefore\\(s/"]],"atomixhq.*":[["aopw","adcashMacros"],["nowoif","!/download\\/|link/"]],"babla.*":[["set-local-storage-item","adshield-analytics-uuid","$remove$"],["set-local-storage-item","/_fa_bGFzdF9iZmFfYXQ=$/","$remove$"],["set-local-storage-item","/_fa_dXVpZA==$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWNjZXB0YWJsZV9hZHM=$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWRz$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfYWRibG9ja19jaXJjdW12ZW50X3Njb3Jl$/","$remove$"]],"bde4.*":[["nofab"],["nano-sib"]],"bdiptv.*":[["aopr","AaDetector"],["nowoif"]],"bdupload.*":[["nano-stb"]],"beinconnect.*":[["abort-current-inline-script","Math","zfgloaded"]],"beinmatch.*":[["nowoif"]],"bflix.*":[["abort-on-property-write","window.open"],["abort-current-inline-script","EventTarget.prototype.addEventListener","delete window"]],"bigwarp.*":[["abort-on-property-write","window.open"],["abort-current-inline-script","EventTarget.prototype.addEventListener","delete window"],["abort-current-inline-script","WebAssembly","atob"]],"biqle.*":[["acs","decodeURI","decodeURIComponent"],["aopr","Date.prototype.toUTCString"]],"bluemediafiles.*":[["aopr","open"],["nano-sib","i--"],["set","Time_Start","0"]],"bokepindo13.*":[["abort-on-property-read","open"]],"bokepindoh.*":[["abort-on-property-read","open"]],"bolly4u.*":[["aopr","open"],["aopr","XMLHttpRequest"]],"booru.*":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"]],"btdb.*":[["aeld","","_0x"],["aopr","console.clear"],["aeld","","Date"],["aopr","open"]],"buffsports.*":[["abort-on-property-write","ZpQw9XkLmN8c3vR3"],["abort-current-inline-script","document.createElement","/\\.settings\\s*=\\s*\\w+\\s*\\|\\|/"]],"burningseries.*":[["aeld","click","preventDefault"],["ra","onclick"]],"cambabe.*":[["acs","onload"],["acs","crakPopInParams"]],"camcaps.*":[["abort-on-property-write","window.open"],["abort-on-property-write","popUnder"]],"camwhores.*":[["abort-on-property-read","window.open"],["override-property-read","flashvars.video_click_url","undefined"],["override-property-read","flashvars.adv_pre_url","undefined"],["override-property-read","flashvars.adv_pre_vast","undefined"],["override-property-read","flashvars.protect_block","undefined"]],"capshd.*":[["nowoif"]],"casa-cinema.*":[["abort-current-inline-script","atob"],["abort-on-property-write","zfgformats"],["abort-on-property-write","window.open"],["abort-current-inline-script","EventTarget.prototype.addEventListener","delete window"]],"cataz.*":[["abort-on-property-write","window.open"],["abort-current-inline-script","addEventListener","HTMLAllCollection"]],"cdn.gledaitv.*":[["aopr","Handlers"],["aopr","Settings"],["nostif","initializeAdblockDetection"],["aopr","idiotHelper"],["aopr","idiotHandlers"],["acs","document.createElement","detection-bait"]],"ciberdvd.*":[["nowoif"],["aopw","smrtSB"]],"cima-club.*":[["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"],["abort-on-property-read","window.zfgstorage"]],"cimalina.*":[["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"]],"cineb.*":[["prevent-listener","mousedown","shown_at"],["abort-on-property-read","window.open"],["abort-on-property-write","window.open"],["abort-current-inline-script","addEventListener","HTMLAllCollection"],["abort-on-property-read","localStorage"]],"cineby.*":[["abort-on-property-read","open"],["override-property-read","window.atOptions1","undefined"],["override-property-read","window.atOptions2","undefined"],["abort-current-inline-script","document.addEventListener","/adNetworks/"],["abort-current-inline-script","document.getElementById"]],"cinemalibero.*":[["nowoif"],["aopr","AaDetector"]],"cinetux.*":[["aopw","smrtSB"],["ra","href","#clickfakeplayer"]],"cloudvideotv.*":[["nowoif"],["aopr","localStorage"]],"couchtuner.*":[["acs","RegExp","0x"]],"crichd.*":[["aopr","AaDetector"]],"cricwatch.*":[["abort-on-property-write","ZpQw9XkLmN8c3vR3"],["abort-current-inline-script","document.createElement","/\\.settings\\s*=\\s*\\w+\\s*\\|\\|/"]],"crohasit.*":[["aopw","Fingerprint2"]],"cucuflix.*":[["abort-on-property-read","atob"],["abort-on-property-read","window.open"],["abort-current-inline-script","document.createElement","/referrerPolicy.*no-referrer-when-downgrade/"]],"cyberdrop.*":[["abort-current-inline-script","WebAssembly","atob"]],"dailysport.*":[["acs","String.fromCharCode","atob"],["aopr","AaDetector"],["aopr","open"]],"ddlvalley.*":[["acs","decodeURI","getScriptFromCss"],["aopw","Fingerprint2"]],"depedlps.*":[["aeld","load","onload"],["aopr","encodeURIComponent"]],"desbloqueador.*":[["aeld","mousedown","trigger"],["set","Ok","true"],["nowoif","given"]],"descarga-animex.*":[["aopw","adBlockDetected"]],"desiremovies.*":[["acs","document.createElement","console"],["aeld","","_0x"]],"desiupload.*":[["acs","getCookie"],["aeld","","history.go"]],"dewimg.*":[["nowoif"],["acs","addEventListener","-0x"]],"dfiles.*":[["acs","decodeURI","decodeURIComponent"]],"divxtotal.*":[["acs","jQuery","btoa"]],"divxtotal1.*":[["acs","jQuery","btoa"]],"dl-protect.*":[["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"]],"dlhd.*":[["abort-on-property-write","window.open"],["abort-current-inline-script","EventTarget.prototype.addEventListener","delete window"],["abort-on-property-write","ZpQw9XkLmN8c3vR3"],["abort-current-inline-script","document.createElement","/\\.settings\\s*=\\s*\\w+\\s*\\|\\|/"]],"docer.*":[["set","ads_unblocked","true"]],"dood.*":[["abort-current-inline-script","Math","zfgloaded"],["abort-on-property-read","open"],["abort-on-property-write","_pop"],["abort-on-property-read","DoodPop"],["abort-on-property-write","adb"],["override-property-read","cRAds","trueFunc"],["abort-on-property-write","xRds"],["abort-on-property-write","xPoPAdS"],["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"]],"doods.*":[["abort-current-inline-script","Math","zfgloaded"],["abort-on-property-read","open"],["abort-on-property-write","_pop"],["abort-on-property-read","DoodPop"],["abort-on-property-write","adb"],["override-property-read","cRAds","trueFunc"],["abort-on-property-write","xRds"],["abort-on-property-write","xPoPAdS"],["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"]],"doodstream.*":[["abort-current-inline-script","Math","zfgloaded"],["abort-on-property-read","open"],["abort-on-property-write","_pop"],["abort-on-property-read","DoodPop"],["abort-on-property-write","adb"],["override-property-read","cRAds","trueFunc"],["abort-on-property-write","xRds"],["abort-on-property-write","xPoPAdS"],["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"]],"doood.*":[["abort-on-property-read","window.open"]],"dooodster.*":[["abort-current-inline-script","Math","zfgloaded"],["abort-on-property-read","open"],["abort-on-property-write","_pop"],["abort-on-property-read","DoodPop"],["abort-on-property-write","adb"],["override-property-read","cRAds","trueFunc"],["abort-on-property-write","xRds"],["abort-on-property-write","xPoPAdS"],["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"],["abort-on-property-read","window.open"]],"dooood.*":[["abort-on-property-read","DoodPop"],["abort-on-property-write","adb"],["override-property-read","cRAds","trueFunc"],["abort-on-property-write","xRds"],["abort-on-property-write","xPoPAdS"]],"douploads.*":[["acs","$","show"],["ra","checked","input#chkIsAdd"]],"downloadming.*":[["aopw","decodeURIComponent"]],"dpstream.*":[["set","load_pop_power","noopFunc"],["ra","href","#clickfakeplayer"]],"dramamate.*":[["nowebrtc"]],"dz4soft.*":[["noeval"],["aeld","load","2000"]],"easy-coin.*":[["acs","Math.random","banner"]],"ebookmed.*":[["aeld","load","2000"]],"eg4link.*":[["nano-sib"]],"egy.*":[["abort-on-property-read","open"]],"egyanime.*":[["abort-on-property-write","_pop"]],"egybest.*":[["abort-on-property-read","open"]],"egybest2.*":[["abort-on-property-read","open"]],"egydead.*":[["abort-on-property-write","_pop"],["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"],["abort-current-inline-script","Promise","JSON.parse"]],"egynow.*":[["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"]],"einthusan.*":[["no-xhr-if","/^(?!.*(einthusan\\.io|yahoo|rtnotif|ajax|quantcast|bugsnag))/"]],"elixx.*":[["aopr","AdservingModule"],["aopr","LieDetector"],["aopw","I833"],["json-prune","urls","urls.0"]],"embedseek.*":[["json-prune","ads playerAds"]],"epicplayplay.*":[["abort-current-inline-script","document.createElement","/fakeelement/"]],"erothots.*":[["abort-current-inline-script","Node.prototype.insertBefore","pop1stp"]],"ettv.*":[["nowoif"],["aopr","AaDetector"]],"evileaks.*":[["acs","$","prompt"]],"ext.tofilecrypt.*":[["override-property-read","isAdblock","false"],["abort-current-inline-script","EventTarget.prototype.addEventListener","/key/"],["abort-on-property-read","aclib"],["abort-on-property-read","Adcash"],["override-property-read","isAdblock2","false"]],"extramovies.*":[["abort-on-property-read","decodeURIComponent"]],"extreme-down.*":[["acs","$","friendlyduck"],["acs","Math","decodeURIComponent"],["abort-on-property-read","NativeAd"],["abort-current-inline-script","Math","zfgloaded"],["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"],["abort-on-property-read","decodeURIComponent"]],"extreme-download.*":[["abort-on-property-read","NativeAd"],["abort-current-inline-script","Math","zfgloaded"],["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"]],"eztv.*":[["nowebrtc"]],"faselhd.*":[["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"]],"fc2ppv.*":[["abort-current-inline-script","WebAssembly","atob"]],"fc2stream.*":[["abort-on-property-write","window.open"]],"fembed.*":[["aopr","__Y"],["aopw","adcashMacros"],["aopr","mm"],["nowoif"]],"ffmovies.*":[["acs","String.fromCharCode","break;"],["nowoif"]],"file4go.*":[["acs","document.getElementById","ad_block"],["set","time","0"]],"filedown.*":[["nowoif"]],"filemoon.*":[["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"]],"filesamba.*":[["aopr","_wm"]],"flemmix.*":[["abort-on-property-write","window.open"],["abort-current-inline-script","JSON.parse"],["abort-on-property-read","localStorage"]],"flixcdn.*":[["abort-on-property-write","cache_loader.init"],["abort-on-property-read","window.open"]],"flixmomo.*":[["prevent-window-open","/./","1000","iframe"]],"flyflix.*":[["abort-on-property-write","window.open"]],"foumovies.*":[["aopw","decodeURIComponent"]],"foundit.*":[["set","freshpaint","{}"],["set","freshpaint.track","noopFunc"]],"freecoursesonline.*":[["aeld","load","nextFunction"]],"freestreams-live1.*":[["abort-on-property-write","window.open"],["abort-current-inline-script","EventTarget.prototype.addEventListener","delete window"]],"frembed.*":[["abort-on-property-write","window.open"],["abort-current-inline-script","EventTarget.prototype.addEventListener","delete window"]],"french-stream.*":[["abort-on-property-write","_vrhxb"],["abort-on-property-write","_uhkeedds"],["abort-current-inline-script","EventTarget.prototype.addEventListener","delete window"],["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"],["override-property-read","aclib.runPop","noopFunc"],["prevent-window-open","/./","iframe"]],"fsvid.*":[["abort-on-property-write","cRAds"],["override-property-read","cRAds","false"]],"fxporn69.*":[["aeld","click","exopop"],["set","adblock","noopFunc"],["nostif","nextFunction","2000"]],"fxstreet.*":[["set-local-storage-item","adshield-analytics-uuid","$remove$"],["set-local-storage-item","/_fa_bGFzdF9iZmFfYXQ=$/","$remove$"],["set-local-storage-item","/_fa_dXVpZA==$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWNjZXB0YWJsZV9hZHM=$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWRz$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfYWRibG9ja19jaXJjdW12ZW50X3Njb3Jl$/","$remove$"]],"gamecopyworld.*":[["acs","document.createElement","Tool"]],"gamestorrents.*":[["aopr","LieDetector"]],"ganool.*":[["aeld","/^(?:click|mousedown)$/","_0x"],["nowebrtc"]],"gaypornhdfree.*":[["aeld","DOMContentLoaded","adsBlocked"]],"gdriveplayer.*":[["aopr","AaDetector"],["nowoif","!gdrivedownload"]],"gmx.*":[["aeld","timeupdate"]],"gnula.*":[["nowoif"],["aeld","click","","elements",".post.movies"]],"gogoanimetv.*":[["aopr","AaDetector"],["nosiif","_0x"],["nowoif"]],"gomoviesc.*":[["nowoif"]],"gomoviesfree.*":[["aopr","glxopen"]],"gostream.*":[["set","check_adblock","true"]],"govid.*":[["abort-on-property-read","adcashMacros"],["abort-on-property-write","Fingerprint2"],["abort-on-property-read","open"],["abort-on-property-write","_pop"],["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"],["abort-on-property-read","atop"]],"gowatchseries.*":[["abort-current-inline-script","Object.defineProperty","XMLHttpRequest"]],"grantorrent.*":[["aopr","getUrlParameter"],["acs","onload","btoa"],["aopr","LieDetector"],["nano-stb"],["aopw","Fingerprint2"],["acs","decodeURI","decodeURIComponent"]],"grantorrent1.*":[["aopr","getUrlParameter"],["aopw","Fingerprint2"],["acs","decodeURI","decodeURIComponent"]],"grantorrents.*":[["nano-stb"]],"gsurl.*":[["aeld","mousedown","preventDefault"]],"hdfriday.*":[["aopr","open"]],"hdfull.*":[["acs","document.createElement","l.parentNode.insertBefore(s"],["aeld","mousedown","!!{});"],["nano-stb"]],"hdporner.*":[["abort-current-inline-script","document.createElement","/l\\.parentNode\\.insertBefore\\(s/"]],"hdvid.*":[["aopw","atOptions"],["aost","String.fromCharCode","stackDepth:3"],["aopw","Fingerprint2"],["aopw","smrtSB"],["nowebrtc"],["abort-on-property-read","decodeURIComponent"],["abort-on-property-read","Fingerprint2"],["abort-on-property-read","atob"]],"hentaisd.*":[["aopr","LieDetector"]],"hh3dhay.*":[["abort-current-inline-script","Symbol","/break|case/"]],"hideout.*":[["acs","stop","adblock"]],"himovies.*":[["abort-current-inline-script","document.createElement","script"]],"hqq.*":[["abort-on-property-read","smrtSB"],["abort-on-property-read","smrtSP"],["abort-on-property-write","window.open"],["abort-on-property-read","ownerid"],["abort-on-property-read","_pop"]],"hydrax.*":[["aeld","","_0x"]],"hyperdebrid.*":[["acs","decodeURI","atob"]],"icdrama.*":[["set","adblock","1"]],"idedroidsafelink.*":[["aeld","load","onload"]],"idlelivelink.*":[["nano-sib"]],"iegy.*":[["abort-on-property-read","open"]],"iegybest.*":[["abort-on-property-read","attr"]],"iframejav.*":[["nowoif"],["aopr","__Y"]],"igram.*":[["nano-sib"]],"imgdew.*":[["aopr","CustomEvent"],["aopr","exoJsPop101"],["aopr","ExoLoader.addZone"],["aopw","Fingerprint2"],["nowoif"]],"imgmaze.*":[["aopr","exoJsPop101"],["aopr","ExoLoader.addZone"],["aopr","popjs.init"],["aopw","Fingerprint2"],["nowoif"]],"imgoutlet.*":[["aopr","CustomEvent"],["aopr","exoJsPop101"],["aopw","Fingerprint2"],["nowoif"]],"imgsen.*":[["aopr","CustomEvent"]],"imgsto.*":[["aopr","CustomEvent"]],"imgtown.*":[["aopr","CustomEvent"],["aopr","exoJsPop101"],["aopr","ExoLoader.addZone"],["aopr","popjs.init"],["aopw","Fingerprint2"],["nowoif"],["acs","addEventListener","-0x"]],"imgview.*":[["aopr","CustomEvent"],["aopr","exoJsPop101"],["aopr","ExoLoader.addZone"],["aopw","Fingerprint2"],["nowoif"]],"imgviu.*":[["nowoif"],["acs","addEventListener","-0x"]],"inkapelis.*":[["acs","setTimeout","aadblock"],["aopr","AaDetector"],["aopw","smrtSB"],["aopw","smrtSP"],["aopw","Fingerprint2"],["acs","decodeURI","decodeURIComponent"]],"ispunlock.*":[["aopr","pace"]],"japanfuck.*":[["aopr","popit"],["aeld","popstate","noPop"]],"japanporn.*":[["aopr","popit"],["aeld","popstate","noPop"]],"javhd.*":[["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"javsub.*":[["abort-on-property-read","juicy_tags"]],"javwide.*":[["aopr","AaDetector"]],"jetanimes.*":[["abort-on-property-read","open"],["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"]],"kaliscan.*":[["abort-on-property-write","window.open"],["abort-current-inline-script","document.createElement","/l\\.parentNode\\.insertBefore\\(s/"]],"keepvid.*":[["nowoif"]],"kickasstorrents.*":[["abort-on-property-write","ospen"]],"kimcartoon.*":[["abort-on-property-read","NativeAd"],["abort-current-inline-script","document.createElement","String.fromCharCode"],["abort-on-property-read","localStorage"]],"king-pes.*":[["aeld","load","onload"]],"kinoger.*":[["aopr","__Y"],["nowoif"]],"kinogo.*":[["abort-on-property-read","startAdAngle"]],"kinox.*":[["aopr","decodeURI"]],"kinoz.*":[["nowebrtc"],["aopr","AaDetector"],["aopr","decodeURI"]],"kiss-anime.*":[["nowebrtc"]],"kissjav.*":[["cookie-remover","kt_ips"]],"kisstvshow.*":[["acs","$","#divDownload"]],"knaben.*":[["abort-on-property-read","aclib","false"]],"komikcast.*":[["aeld","load","onload"],["aopr","open"],["abort-on-property-read","localStorage"],["abort-on-property-write","JSON.parse"]],"kstreaming.*":[["aopw","Fingerprint2"],["nowebrtc"]],"kwik.*":[["acs","String.fromCharCode","shift"],["aopr","open"],["aopr","PopAds"]],"l1afav.*":[["abort-on-property-read","window.open"]],"l23movies.*":[["acs","JSON.parse","atob"]],"lanjutkeun.*":[["aeld","load","2000"]],"leaktape.*":[["abort-on-property-read","atob"]],"leechall.*":[["nano-sib"]],"lenkino.*":[["nostif","innerText","2000"]],"letmewatchthis.*":[["nowebrtc"]],"likemanga.*":[["abort-current-inline-script","Node.prototype.insertBefore","pop1stp"]],"limetorrents.*":[["aopr","LieDetector"],["aeld","","_0x"],["aeld","load","onload"],["acs","Object.assign","popunder"],["acs","Math","XMLHttpRequest"],["nowoif"]],"lin-ks.*":[["nano-sib"]],"links-url.*":[["aeld","load","onload"]],"linkshorts.*":[["aopr","open"],["set","blurred","false"]],"linkshub.*":[["nowoif"]],"liveball.*":[["prevent-listener","DOMContentLoaded","start"]],"livecamrips.*":[["abort-on-property-write","window.open"],["abort-current-inline-script","EventTarget.prototype.addEventListener","delete window"],["prevent-listener","click","window.open"]],"lodynet.*":[["abort-on-property-read","decodeURIComponent"],["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"]],"lookmovie2.*":[["abort-current-inline-script","addEventListener"],["prevent-listener","initPrePlaybackCounter-event"]],"lordpremium.*":[["aeld","load","nextFunction"]],"loveroms.*":[["acs","decodeURI","decodeURIComponent"]],"m1xdrop.*":[["abort-on-property-write","window.open"],["abort-current-inline-script","EventTarget.prototype.addEventListener","delete window"],["abort-on-property-write","_pop"],["prevent-listener","","dtnoppu"],["abort-current-inline-script","document.createElement","window.open"],["abort-current-inline-script","document.createElement"],["abort-on-property-read","window.open"]],"m4ufree.*":[["nostif","debugger"],["nowebrtc"],["aopr","mm"]],"mangago.*":[["abort-current-inline-script","document.documentElement","/break|case/"]],"mangakoma01.*":[["abort-current-inline-script","document.createElement","/l\\.parentNode\\.insertBefore\\(s/"]],"mangamanga.*":[["aeld","keydown"]],"mangaraw.*":[["abort-current-inline-script","WebAssembly","atob"],["abort-current-inline-script","document.createElement","/l\\.parentNode\\.insertBefore\\(s/"]],"mangasail.*":[["set","adblock","1"]],"mangovideo.*":[["acs","document.createElement","script"],["set","flashvars.popunder_url",""]],"mavanimes.*":[["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"],["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","JSON.parse"]],"mavplay.*":[["aopr","jwplayer.utils.Timer"],["aopr","__Y"],["aopw","adcashMacros"],["aopr","mm"],["nowoif"]],"mazpic.*":[["nowoif"],["acs","addEventListener","-0x"]],"mega-dvdrip.*":[["aeld","DOMContentLoaded","shortener"]],"mega1080p.*":[["aeld","DOMContentLoaded","btoa"]],"mega4up.*":[["ra","onclick","[onclick^=\"window.open\"]"],["nowoif"]],"megalink.*":[["aopr","app_vars.force_disable_adblock"],["set","blurred","false"],["aeld","click","popunder"]],"megavideo.*":[["nowoif"]],"mejortorrent.*":[["nowebrtc"]],"mejortorrento.*":[["nowebrtc"]],"mejortorrents.*":[["nowebrtc"]],"mejortorrents1.*":[["nowebrtc"]],"mejortorrentt.*":[["nowebrtc"]],"metrolagu.*":[["abort-on-property-write","window.open"]],"mexa.*":[["acs","document.getElementById","adblockinfo"],["nowoif"]],"mimaletadepeliculas.*":[["aeld","load","advertising"]],"miniurl.*":[["aopr","app_vars.force_disable_adblock"],["set","blurred","false"]],"missav.*":[["prevent-window-open","/pop?url="]],"mixdroop.*":[["abort-on-property-write","_pop"],["prevent-listener","","dtnoppu"],["abort-current-inline-script","document.createElement","window.open"]],"mixdrop.*":[["abort-on-property-write","_pop"],["abort-on-property-write","_pao"],["abort-on-property-write","window.open"],["prevent-listener","","dtnoppu"],["abort-current-inline-script","document.createElement","window.open"],["abort-current-inline-script","$","String.fromCharCode"],["override-property-read","MDCore.adblock","0"],["abort-current-inline-script","String.fromCharCode"],["abort-on-property-read","window.open"],["abort-current-inline-script","atob","popundersPerIP"]],"mixdrp.*":[["abort-on-property-write","_pop"],["prevent-listener","","dtnoppu"],["abort-current-inline-script","document.createElement","window.open"]],"mkvcage.*":[["nowebrtc"]],"moretvtime.*":[["acs","adBlockDetected"]],"mov2day.*":[["abort-current-inline-script","addEventListener","HTMLAllCollection"],["abort-on-property-read","LieDetector"],["abort-on-property-read","window.open"],["abort-current-inline-script","String.fromCharCode","2147483647"]],"movearnpre.*":[["abort-on-property-write","window.open"]],"movie4me.*":[["aopr","Math.floor"]],"movieon21.*":[["nowoif"]],"moviepire.*":[["abort-on-property-read","aclib","false"]],"movieruls.*":[["nowoif"]],"movierulz.*":[["nowoif"]],"movierulz2free.*":[["nowoif"]],"movierulzfree.*":[["nowoif"]],"movierulzlink.*":[["aopr","String.fromCharCode"]],"movierulzs.*":[["nowoif"]],"movierulzwatch.*":[["nowoif"]],"movierulzz.*":[["nowoif"]],"movies123.*":[["nowoif"],["aopr","AaDetector"]],"moviescounter.*":[["aopr","LieDetector"],["aeld","","_0x"]],"moviesrulz.*":[["nowoif"]],"moviesrulzfree.*":[["nowoif"]],"moviflex.*":[["acs","Math","XMLHttpRequest"],["nowoif"]],"movisubmalay.*":[["aopr","glxopen"],["aopr","exoJsPop101"]],"movs4u.*":[["aeld","","_0x"],["abort-current-inline-script","Math","zfgloaded"]],"mp3clan.*":[["aopw","Fingerprint2"]],"mp3guild.*":[["aopw","Fingerprint2"]],"mrpiracy.*":[["acs","document.getElementById","deleted"],["aopr","LieDetector"],["nowoif"]],"mtsproducoes.*":[["aopw","block_detected"]],"musichq.*":[["abort-on-property-write","rotationUrl"],["override-property-read","changeServer","undefined"],["abort-current-inline-script","document.createElement","/script/"],["prevent-listener","beforeunload","()"],["abort-on-property-write","window.open"],["abort-current-inline-script","addEventListener","HTMLAllCollection"]],"mxdrop.*":[["abort-on-property-write","_pop"],["prevent-listener","","dtnoppu"],["abort-current-inline-script","document.createElement","window.open"]],"mycloudz.*":[["override-property-read","window.open","noopFunc"]],"mycoolmoviez.*":[["nowebrtc"]],"myegy.*":[["aopw","decodeURI"]],"myembed.*":[["prevent-window-open","/^/"]],"myflixerfree.*":[["override-property-read","vastAdData","undefined"]],"myflixerzz.*":[["abort-on-property-read","window.open"]],"mypiratebay.*":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-on-property-write","_pop"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"],["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"]],"myvidmate.*":[["acs","atob","decodeURIComponent"]],"mywatchseries.*":[["nowebrtc"],["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"]],"nakastream.*":[["replace-fetch-response","/(adsterraSmartLink[0-9]?:)[^]+/","$1","adsterraSmartLink"]],"nbabox.*":[["abort-on-property-write","ZpQw9XkLmN8c3vR3"],["abort-current-inline-script","document.createElement","/\\.settings\\s*=\\s*\\w+\\s*\\|\\|/"]],"newmovierulz.*":[["aopr","String.fromCharCode"]],"newpelis.*":[["aeld","","0x"],["set","btoa","null"],["nowoif"],["aeld","load","url"],["aopw","smrtSB"],["aopw","smrtSP"]],"nextorrent.*":[["acs","jQuery","popunder"],["ra","onclick"]],"nonsensediamond.*":[["aopr","decodeURI"]],"notebookcheck.*":[["aopw","ab_cl"]],"novablogitalia.*":[["aeld","load","nextFunction"]],"novelasesp.*":[["aeld","load","2000"]],"nudevista.*":[["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"nupload.*":[["abort-on-property-read","aclib.runPop"]],"nyahentai.*":[["abort-current-inline-script","WebAssembly","atob"]],"officedepot.*":[["set","gbTracker","{}"],["set","gbTracker.sendAutoSearchEvent","noopFunc"]],"ohmymag.*":[["aopr","_sp_._networkListenerData"]],"okanime.*":[["acs","$","getElementById"],["nowebrtc"],["nowoif"]],"oload.*":[["aopr","AaDetector"],["aopr","open"],["aopr","_pop"],["aopr","decodeURI"]],"oneupload.*":[["abort-on-property-write","window.open"],["abort-current-inline-script","JSON.parse"],["abort-on-property-read","localStorage"]],"onionplay.*":[["prevent-window-open","/./"],["override-property-read","scds","0"]],"onlinevideoconverter.*":[["nowoif"]],"onmovies.*":[["aopw","Fingerprint2"]],"onvid.*":[["aopw","Fingerprint2"],["aopw","smrtSB"],["nowebrtc"]],"openloadmovies.*":[["aopr","AaDetector"],["abort-on-property-read","atob"],["abort-on-property-write","Fingerprint2"]],"otakuindo.*":[["aopr","Date.prototype.toUTCString"],["nobab"]],"otomoto.*":[["abort-on-property-read","Baxter.targeting.ad_price"],["abort-on-property-read","Baxter.targeting.ad_title"],["override-property-read","Baxter.targeting","emptyObj"]],"ouo.*":[["aopr","AaDetector"],["nowebrtc"],["nano-sib","stop()"]],"outletpic.*":[["nowoif"],["acs","addEventListener","-0x"]],"ovid.*":[["aopw","Fingerprint2"],["aopw","smrtSB"],["nowebrtc"]],"pahe.*":[["nowoif"],["aeld","","_0x"]],"pandafreegames.*":[["nostif","adFilled","2500"]],"pandamovie.*":[["aopr","exoNoExternalUI38djdkjDDJsio96"],["nowoif"]],"paperio.*":[["override-property-read","checktimeForAds","falseFunc"]],"pctfenix.*":[["acs","I833"],["aopr","AaDetector"],["aopr","TID"],["aopw","adcashMacros"],["nowoif","!/download\\/|link/"]],"pctnew.*":[["acs","I833"],["aopr","AaDetector"],["aopr","TID"],["aopw","adcashMacros"],["nowoif","!/download\\/|link/"]],"peliculas-dvdrip.*":[["aeld","DOMContentLoaded","shortener"],["aopr","AdservingModule"]],"peliculas24.*":[["acs","blur"],["aopw","smrtSB"]],"peliculaseroticasonline.*":[["abort-on-property-write","_0x1dc1"]],"pelis28.*":[["nowoif"],["ra","href","#clickfakeplayer"]],"pelisflix1.*":[["abort-on-property-read","doSecondPop"],["abort-on-property-read","doSecondPopU"]],"pelisflix2.*":[["abort-on-property-read","doSecondPop"],["abort-on-property-read","doSecondPopU"]],"pelisflix200.*":[["abort-on-property-read","doSecondPop"],["abort-on-property-read","doSecondPopU"]],"pelisgratis.*":[["aopw","smrtSB"]],"pelispedia.*":[["acs","allclick_Public"],["nano-stb"],["ra","href","a#clickfakeplayer"],["ra","href","#opfk"],["ra","href",".fake_player > [href][target]"]],"pelispedia24.*":[["nowoif"],["ra","href","a#clickfakeplayer"]],"pelisplus.*":[["aopr","AaDetector"],["aopw","adcashMacros"],["aopw","smrtSP"],["aopw","smrtSB"],["nowoif"],["ra","href","#opfk"],["abort-on-property-write","_zoxxpiee"]],"pelisplus2.*":[["acs","document.getElementsByTagName","onclick"]],"pelisplushd.*":[["aopw","adcashMacros"],["nowoif"],["abort-on-property-read","window.open"]],"pelix.*":[["aeld","","0x"],["set","btoa","null"],["nowoif"],["aeld","load","url"],["aopw","smrtSB"],["aopw","smrtSP"],["aopr","AaDetector"],["aopw","adcashMacros"]],"perfectgirls.*":[["acs","ExoLoader"],["aopw","ads_priv"],["noeval"],["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-on-property-read","open"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"perfektdamen.*":[["acs","ExoLoader"],["aopw","ads_priv"],["noeval"]],"pianmanga.*":[["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"picrok.*":[["nowoif"],["acs","addEventListener","-0x"]],"pingit.*":[["aopr","AaDetector"],["aopr","open"],["aopr","rmVideoPlay"],["aopr","_pop"],["aopw","Fingerprint2"],["set","blurred","false"]],"pinkporno.*":[["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"pinterest.*":[["json-prune","resource_response.data.[-].ad_data resource_response.data.results.[-].ad_data initialReduxState.resources.UserHomefeedResource.{}.data.[-].ad_data"]],"pirate.*":[["aeld","/^(?:click|mousedown)$/","_0x"]],"piratebay.*":[["aeld","/^(?:click|mousedown)$/","_0x"],["aopr","AaDetector"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"piratebayz.*":[["aopr","LieDetector"]],"pirateproxy.*":[["aopw","Fingerprint2"],["nowebrtc"],["acs","String.fromCharCode","decodeURIComponent"],["aeld","/^(?:click|mousedown)$/","_0x"],["acs","Object.defineProperty","document.body.appendChild"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"pkembed.*":[["abort-on-property-write","window.open"],["abort-current-inline-script","EventTarget.prototype.addEventListener","delete window"]],"platinmods.*":[["nano-sib"]],"ployan.*":[["abort-on-property-read","window.open"]],"plyjam.*":[["set","attr","{}"],["set","scriptSrc",""]],"pnd.*":[["aopr","AaDetector"],["aopw","Fingerprint2"]],"poop.*":[["override-property-read","setTimeout","noopFunc"],["abort-current-inline-script","String.fromCharCode","2147483647"],["abort-on-property-read","window.open"]],"popcornstream.*":[["nostif","blur"],["aeld","","btoa"]],"pornfay.*":[["nowoif"]],"pornhat.*":[["aopr","document.dispatchEvent"]],"pornhd8k.*":[["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"pornhoarder.*":[["abort-on-property-write","ZpQw9XkLmN8c3vR3"],["abort-current-inline-script","document.createElement","/\\.settings\\s*=\\s*\\w+\\s*\\|\\|/"]],"pornid.*":[["aopr","decodeURI"]],"porno-tour.*":[["aopr","document.dispatchEvent"],["nostif","innerText","2000"]],"pornoakt.*":[["prevent-listener","mousedown","pop.doEvent"]],"pornproxy.*":[["abort-current-inline-script","document.createElement","/script/"],["abort-on-property-write","PopCookieTimeout"],["abort-on-property-read","PopURL"]],"primevid.*":[["abort-on-property-write","window.open"]],"prmovies.*":[["abort-on-property-read","open"],["abort-current-inline-script","JSON.parse"],["abort-on-property-read","localStorage"]],"projectfreetv.*":[["aeld","","_0x"]],"prostoporno.*":[["aopr","ExoLoader.serve"]],"proxytpb.*":[["aeld","/^(?:click|mousedown)$/","_0x"]],"psarips.*":[["aopw","Fingerprint2"]],"pussyspace.*":[["aopr","open"]],"putlocker9.*":[["aopw","Fingerprint2"]],"putlockerc.*":[["nowoif"]],"putlockertv.*":[["nowoif"]],"pxp.*":[["abort-current-inline-script","WebAssembly","atob"],["abort-current-inline-script","document.createElement","/l\\.parentNode\\.insertBefore\\(s/"]],"rainanime.*":[["aopr","loadRunative"]],"raw18.*":[["abort-current-inline-script","document.createElement","/l\\.parentNode\\.insertBefore\\(s/"]],"remaxhd.*":[["aopr","decodeURI"],["nowoif"]],"rmcmv.*":[["nosiif","visibility"]],"rojadirecta.*":[["aopw","closeMyAd"],["aopw","smrtSP"],["abort-on-property-read","smrtSB"],["abort-on-property-read","smrtSP"]],"rojadirectatv.*":[["aopw","smrtSP"]],"rojadirectatvlive.*":[["nowoif"]],"rpmstream.*":[["json-prune","ads playerAds"]],"rule34.*":[["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"],["abort-on-property-write","zfgloadedpopup"],["abort-current-inline-script","WebAssembly","atob"],["prevent-listener","getexoloader"],["abort-on-property-write","ExoLoader","false"],["abort-on-property-read","ExoLoader.addZone","false"],["abort-on-property-read","ExoLoader.serve","false"],["abort-current-inline-script","document.dispatchEvent","/getexoloader/"]],"rushporn.*":[["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"sandrives.*":[["nostif","nextFunction","250"]],"savemedia.*":[["nowoif"]],"seeflix.*":[["abort-on-property-write","window.open"],["abort-current-inline-script","EventTarget.prototype.addEventListener","delete window"],["abort-on-property-read","aclib","false"]],"seehd.*":[["acs","String.fromCharCode","shift"]],"series24.*":[["abort-on-property-read","aclib.runPop"]],"sexrura.*":[["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"sextb.*":[["prevent-window-open","/[/]api[/]direct[/]/"]],"sexvid.*":[["acs","document.write","iframe"],["aopr","ExoLoader"],["aopr","pu"],["abort-on-property-read","atob"],["abort-current-inline-script","document.write","/promo/"],["override-property-read","window.diptr","undefined"],["abort-on-property-read","window.pu"],["abort-current-inline-script","document.write","iframe"]],"sexvideos.*":[["cookie-remover","tgpOut"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["override-property-read","setTimeout","noopFunc"]],"shahed4u.*":[["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"]],"shaheed4u.*":[["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"]],"shahid4uu.*":[["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"]],"shahidd4u.*":[["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"]],"shortearn.*":[["aopr","AaDetector"],["aopr","open"],["set","blurred","false"]],"shorten.*":[["aopr","AaDetector"],["aopr","app_vars.force_disable_adblock"],["aopr","parcelRequire"],["nowoif"]],"shrtfly.*":[["aopr","open"],["aopr","tabUnder"]],"silkengirl.*":[["aopr","ExoLoader.addZone"],["aopr","loadTool"],["aopr","exoNoExternalUI38djdkjDDJsio96"]],"simpcity.*":[["abort-current-inline-script","WebAssembly","atob"]],"singingdalong.*":[["aeld","load","2000"]],"skidrowreloaded.*":[["abort-on-property-read","runPop"],["abort-current-inline-script","open"],["abort-on-property-read","Math.floor"]],"smashyplayer.*":[["abort-on-property-write","cache_loader"]],"soap2day.*":[["abort-on-property-read","window.open"],["abort-current-inline-script","document.createElement","script"],["abort-on-property-read","localStorage"]],"sobatkeren.*":[["nowoif"]],"solarmovie.*":[["aopr","AaDetector"],["nowoif"],["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"],["abort-on-property-read","window.open"],["abort-on-property-read","AaDetector"],["abort-on-property-read","localStorage"],["abort-current-inline-script","Math","zfgloaded"]],"songs.*":[["aopr","AaDetector"]],"sound-park.*":[["acs","$","open"],["acs","document.createElement","script"],["abort-current-inline-script","$","open"]],"soundpark-club.*":[["acs","$","open"],["acs","document.createElement","script"]],"soundpark.*":[["acs","$","open"],["acs","document.createElement","script"]],"spankbang.*":[["set","send_gravity_event","noopFunc"],["set","send_recommendation_event","noopFunc"]],"speedporn.*":[["aopr","exoNoExternalUI38djdkjDDJsio96"],["nowoif"]],"sporting77.*":[["nowoif"]],"sportlemon.*":[["aopr","decodeURI"]],"sportlemons.*":[["aopr","decodeURI"]],"sportlemonx.*":[["aopr","decodeURI"]],"sportlive.*":[["ra","onclick"]],"ssrmovies.*":[["nowoif"]],"stardima.*":[["abort-current-inline-script","document.createElement","/break|case/"]],"starmusiq.*":[["nowebrtc"],["set","isAdBlockActive","false"]],"steamplay.*":[["abort-on-property-read","btoa"],["abort-on-property-write","adcashMacros"]],"strcloud.*":[["abort-on-property-read","open"],["abort-on-property-write","_pop"],["abort-on-property-write","_pao"],["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"],["abort-current-inline-script","JSON.parse","Promise"],["abort-current-inline-script","document.createElement","adblock"]],"stre4mpay.*":[["abort-on-property-read","puOverlay"]],"stre4mplay.*":[["abort-on-property-read","puOverlay"]],"stream2watch.*":[["acs","atob"],["aopr","AdservingModule"]],"streamcdn.*":[["aopr","AaDetector"],["aopr","open"]],"streameast.*":[["aeld","/^/","0x"],["nosiif","visibility","1000"],["nowebrtc"],["nostif","sadbl"],["acs","Object.defineProperty","break;case"]],"streamhoe.*":[["aopr","open"],["aopr","_pop"]],"streaming-community.*":[["abort-on-property-write","window.open"],["abort-current-inline-script","EventTarget.prototype.addEventListener","delete window"]],"streaming-french.*":[["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"]],"streamingcommunity.*":[["abort-current-inline-script","String.fromCharCode","/btoa|break/"]],"streamingnow.*":[["prevent-window-open","_blank","2000","obj"]],"streamingworld.*":[["acs","atob","decodeURIComponent"],["aopr","AaDetector"],["aopw","Fingerprint2"]],"streamm4u.*":[["nowebrtc"],["aopr","AaDetector"],["abort-on-property-write","_showApk"]],"streamtape.*":[["abort-on-property-read","open"],["abort-on-property-write","_pop"],["abort-on-property-write","_pao"],["abort-on-property-write","window.open"],["abort-current-inline-script","EventTarget.prototype.addEventListener","delete window"],["abort-current-inline-script","JSON.parse","Promise"],["abort-current-inline-script","document.createElement","adblock"]],"streamvid.*":[["abort-current-inline-script","setTimeout","_0x"],["prevent-window-open","/.*/","1000","iframe"]],"streamxtv.*":[["abort-on-property-read","runPop"],["abort-current-inline-script","TextEncoder","/shown_at/"]],"strikeout.*":[["nowoif","|"],["acs","setTimeout","admc"],["acs","String.fromCharCode","shift"]],"strip2.*":[["abort-current-inline-script","__require","/clickunder/"],["override-property-read","Object.prototype.ads/mobiads","undefined"]],"strmup.*":[["abort-on-property-write","window.open"],["abort-current-inline-script","EventTarget.prototype.addEventListener","delete window"],["override-property-read","b4ec4795de7e51b370809da193ce1a7d","trueFunc"]],"strp2p.*":[["json-prune","ads playerAds"]],"strtape.*":[["abort-on-property-read","open"],["abort-on-property-write","_pop"],["abort-on-property-write","_pao"],["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"],["abort-current-inline-script","JSON.parse","Promise"],["abort-current-inline-script","document.createElement","adblock"]],"strumyk.*":[["abort-on-property-read","aclib"]],"superflixapi.*":[["prevent-window-open","/^/"]],"supervideo.*":[["aopr","AaDetector"]],"swatchseries.*":[["abort-current-inline-script","String.fromCharCode","2147483647"]],"sxyprn.*":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"],["abort-current-inline-script","vast_urls"],["override-property-read","D4zz","undefined"],["abort-current-inline-script","decodeURI","decodeURIComponent"],["abort-current-inline-script","document.createElement","script"]],"syosetu.*":[["abort-current-inline-script","WebAssembly","atob"]],"tamilmv.*":[["nowebrtc"],["acs","atob","decodeURIComponent"]],"tamilyogi.*":[["acs","String.fromCharCode","shift"]],"tarjetarojatvonline.*":[["aopw","closeMyAd"],["aopw","smrtSP"]],"teensex.*":[["aopr","popit"],["aeld","popstate","noPop"]],"teknorizen.*":[["set","safelink.adblock","false"]],"telecharger-igli4.*":[["aopw","adBlockDetected"]],"teleriumtv.*":[["nowoif"]],"tennisonline.*":[["abort-on-property-write","ZpQw9XkLmN8c3vR3"],["abort-current-inline-script","document.createElement","/\\.settings\\s*=\\s*\\w+\\s*\\|\\|/"]],"theflixer.*":[["abort-on-property-read","window.zfgstorage"]],"thefmovies.*":[["aost","Math","inlineScript"],["nostif","'0x"],["nowoif"]],"thepiratebay.*":[["aeld","/^(?:click|mousedown)$/","_0x"],["aopw","spot"],["aopr","popjs.init"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"thestreameast.*":[["aeld","/^/","0x"],["nosiif","visibility","1000"],["nowebrtc"],["nostif","sadbl"],["aopr","aclib"]],"thevidhd.*":[["aopw","smrtSB"],["nowebrtc"]],"thoptv.*":[["aopr","AaDetector"],["nostif","readyplayer","2000"]],"ticketmaster.*":[["set","Navigator.prototype.globalPrivacyControl","false"],["set","navigator.globalPrivacyControl","false"]],"tiz-cycling.*":[["acs","jQuery","blocker"]],"tmearn.*":[["aopr","app_vars.force_disable_adblock"],["nowoif"],["set","blurred","false"],["aopr","AaDetector"]],"toflix.*":[["abort-on-property-write","window.open"]],"toonanime.*":[["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"],["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"]],"top-flix.*":[["abort-current-inline-script","Math","zfgloaded"]],"topcinemaa.*":[["abort-on-property-write","zfgformats"],["abort-on-property-write","window.open"],["abort-current-inline-script","EventTarget.prototype.addEventListener","delete window"],["abort-current-inline-script","atob","ChmaorrC"],["abort-on-property-write","zfgproxyhttp"]],"topstreams.*":[["nowebrtc"],["acs","$","ads"],["acs","setTimeout","admc"]],"torkitty.*":[["prevent-listener","click","handlePopunder"]],"torlock.*":[["acs","setTimeout","admc"],["nowebrtc"]],"torlock2.*":[["acs","setTimeout","admc"],["nowebrtc"]],"tornadomovies.*":[["set","atob","noopFunc"]],"torrent9.*":[["aeld","","_0x"],["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"]],"torrentz2eu.*":[["aopr","glxopen"],["acs","decodeURI","decodeURIComponent"],["acs","$","open"]],"totaldebrid.*":[["nostif","nextFunction","250"]],"tpb.*":[["aopr","pace"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"tpbay.*":[["abort-on-property-read","_wm_settings"]],"transfermarkt.*":[["acs","document.querySelector","popupBlocked"],["acs","Math","/\\}\\s*\\(.*?\\b(self|this|window)\\b.*?\\)/"]],"tube18.*":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"],["abort-current-inline-script","pop_init"],["abort-on-property-read","popundrCheck"]],"tubsexer.*":[["nostif","innerText","2000"]],"tugaflix.*":[["aopr","open"]],"tuktukcinema.*":[["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"]],"turbovid.*":[["abort-current-inline-script","WebAssembly","atob"]],"uiz.*":[["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"up4stream.*":[["abort-current-inline-script","document.createElement","/String\\.fromCharCode.*[0-9]{2,3}/"]],"uploadev.*":[["nowoif"],["set","openInNewTab","noopFunc"]],"ups2up.*":[["abort-current-inline-script","document.documentElement","/break|case/"],["abort-on-property-write","window.open"],["abort-current-inline-script","EventTarget.prototype.addEventListener","delete window"],["abort-current-inline-script","JSON.parse"],["abort-on-property-read","localStorage"]],"uptomega.*":[["nano-stb","seconds"]],"upvid.*":[["nowoif"]],"urlcero.*":[["aopr","open"],["nostif","checkAdblockUser","1000"]],"ustream.*":[["nowoif"],["aopr","console.clear"]],"uwatchfree.*":[["aeld","","_0x"]],"vanime.*":[["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"]],"ver-pelis.*":[["nowoif"],["acs","decodeURI","decodeURIComponent"]],"vev.*":[["aeld","/^(?:click|mousedown|mouseup)$/","di()"],["set","console.clear","trueFunc"],["nowoif","/^/","1"]],"vid2faf.*":[["abort-on-property-read","window.open"]],"vidara.*":[["abort-on-property-read","window.open"],["abort-on-property-read","popundersPerIP"],["abort-current-inline-script","String.fromCharCode","2147483647"],["abort-current-inline-script","document.createElement","delete window"]],"vidbolt.*":[["prevent-window-open","/./","1000","iframe"]],"vidcloud.*":[["nowoif"],["aopr","BetterJsPop"],["aopr","decodeURI"],["aopw","adBlockDetected"],["aopr","__Y"],["acs","atob","decodeURIComponent"],["acs","Math","XMLHttpRequest"]],"vidcore.*":[["prevent-window-open","/./","1000","iframe"]],"vidello.*":[["abort-on-property-write","window.open"]],"videobb.*":[["aopr","jwplayer.utils.Timer"],["aopr","__Y"],["aopw","adcashMacros"],["aopr","mm"],["aopr","glxopen"],["nowoif"]],"vidhd.*":[["aopw","Fingerprint2"],["aopw","smrtSB"],["nowebrtc"],["aopr","AaDetector"]],"vidmoly.*":[["override-property-read","HTMLAnchorElement.prototype.click","noopFunc"],["prevent-listener","DOMContentLoaded","href"],["abort-current-inline-script","addEventListener","DOMContentLoaded"],["abort-on-property-read","window.open"]],"vidop.*":[["aeld","/^(?:click|mousedown|mouseup)$/","di()"],["set","console.clear","trueFunc"]],"vidora.*":[["override-property-read","cRAds","false"]],"vids.*":[["abort-on-property-write","window.open"],["abort-current-inline-script","EventTarget.prototype.addEventListener","delete window"],["abort-current-inline-script","document.createElement","pop_tag"]],"vidstream.*":[["nowoif","!api?call=","10","obj"]],"vidup.*":[["set","console.clear","trueFunc"],["nowoif","/^/","1"]],"vidwish.*":[["abort-on-property-write","window.open"],["abort-current-inline-script","Math.random","parseInt"]],"vidzy.*":[["abort-on-property-write","window.open"],["abort-current-inline-script","EventTarget.prototype.addEventListener","delete window"],["override-property-read","cRAds","false"],["abort-on-property-write","cRAds"]],"vinaurl.*":[["aopr","app_vars.force_disable_adblock"],["aopr","open"],["aopw","adsHeight"],["ra","onmousemove","button"],["set","blurred","false"]],"vintagetube.*":[["aopr","popit"],["aeld","popstate","noPop"]],"vipboxtv.*":[["json-prune","*","*.adserverDomain"]],"vipleague.*":[["abort-on-property-write","ZpQw9XkLmN8c3vR3"],["abort-current-inline-script","document.createElement","/\\.settings\\s*=\\s*\\w+\\s*\\|\\|/"]],"vipracing.*":[["acs","$","show"],["aopr","AaDetector"]],"vipstand.*":[["nowoif","//"],["abort-current-inline-script","document.createElement","/l\\.parentNode\\.insertBefore\\(s/"]],"vixcloud.*":[["abort-on-property-write","window.open"],["abort-current-inline-script","EventTarget.prototype.addEventListener","delete window"]],"vizcloud.*":[["abort-on-property-read","AaDetector"]],"voiranime.*":[["abort-on-property-read","NativeAd"],["abort-current-inline-script","document.createElement","String.fromCharCode"]],"voirfilms.*":[["aopw","smrtSB"],["nowoif"],["acs","atob","decodeURIComponent"]],"voirseries.*":[["abort-on-property-read","localStorage"],["abort-on-property-write","JSON.parse"],["abort-on-property-read","open"],["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"]],"vostfree.*":[["abort-on-property-write","_pop"],["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"]],"watch-series.*":[["acs","Math","XMLHttpRequest"],["nowebrtc"],["nowoif"],["set","console.clear","trueFunc"]],"watch4hd.*":[["aopr","open"]],"watchgameofthrones.*":[["aopr","AaDetector"],["nobab"]],"watchporn.*":[["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"watchpornfree.*":[["aopr","exoNoExternalUI38djdkjDDJsio96"],["nowoif"]],"watchseries.unblocked.*":[["nowebrtc"]],"watchseries1.*":[["abort-current-inline-script","document.dispatchEvent","myEl"],["abort-on-property-read","aNB"],["abort-on-property-read","BetterJsPop"],["abort-on-property-read","ExLdr.serve"],["abort-on-property-read","exoDocumentProtocol"],["abort-on-property-read","ExoLoader"],["abort-on-property-read","ExoLoader.addZone"],["abort-on-property-read","ExoLoader.serve"],["abort-on-property-read","exoNoExternalUI38djdkjDDJsio96"],["abort-on-property-read","ExoooLoooader"],["abort-on-property-read","getexoloader"],["abort-on-property-read","popit"],["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"],["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"]],"watchseriestv.*":[["abort-current-inline-script","String.fromCharCode","2147483647"],["abort-on-property-read","window.open"]],"watchtvseries.*":[["nowebrtc"]],"watchug.*":[["abort-on-property-write","window.open"],["abort-current-inline-script","EventTarget.prototype.addEventListener","delete window"]],"wawacity.*":[["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"],["abort-current-inline-script","JSON.stringify"]],"wco.*":[["abort-current-inline-script","document.createElement","adsbox"],["override-property-read","blockAdBlock","undefined"]],"wcostream.*":[["abort-current-inline-script","document.createElement","adsbox"],["override-property-read","blockAdBlock","undefined"]],"web2.0calc.*":[["aopr","doads"]],"webbro.*":[["aopr","AaDetector"]],"weloma.*":[["abort-current-inline-script","document.createElement","/l\\.parentNode\\.insertBefore\\(s/"]],"wetteronline.*":[["aopr","__eiPb"]],"wiflix.*":[["abort-current-inline-script","JSON.parse"],["abort-on-property-read","localStorage"]],"woxikon.*":[["set-local-storage-item","adshield-analytics-uuid","$remove$"],["set-local-storage-item","/_fa_bGFzdF9iZmFfYXQ=$/","$remove$"],["set-local-storage-item","/_fa_dXVpZA==$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWNjZXB0YWJsZV9hZHM=$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfaXNfYmxvY2tpbmdfYWRz$/","$remove$"],["set-local-storage-item","/_fa_Y2FjaGVfYWRibG9ja19jaXJjdW12ZW50X3Njb3Jl$/","$remove$"]],"xberuang.*":[["set","safelink.adblock","false"],["nano-sib"]],"xclusivejams.*":[["aopr","decodeURI"]],"xmovies8.*":[["nowoif"],["aeld","/^(?:click|mousedown|mousemove|touchstart|touchend|touchmove)$/","system.popunder"],["set","check_adblock","true"]],"xnxx.*":[["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"],["prevent-listener","DOMContentLoaded","/loadAdsDelayed/"],["override-property-read","xv.sda.pp.init","noopFunc"],["override-property-read","xv.conf.dyn.exoclick_domain","undefined"],["abort-on-property-read","html5player.enableVideoPreRollAds"],["override-property-read","xv.conf.dyn.ads.excld","undefined"],["override-property-read","xv.conf.dyn.excld","undefined"],["override-property-read","html5player.disableVideoAds","true"],["override-property-read","xv.conf.dyn.slcams","false"]],"xprime.*":[["abort-on-property-write","window.open"]],"xvideos.*":[["abort-current-inline-script","document.querySelectorAll","popMagic"],["abort-on-property-read","popMagic"]],"xxxmovies.*":[["aopr","popit"],["aeld","popstate","noPop"]],"y2mate.*":[["abort-on-property-read","dispatchEvent"],["abort-on-property-read","window.open"],["abort-current-inline-script","String.fromCharCode","2147483647"]],"yggtorrent.*":[["aopw","Fingerprint2"]],"yifysubtitles.*":[["override-property-read","isAdblock","false"],["abort-current-inline-script","EventTarget.prototype.addEventListener","/key/"],["abort-on-property-read","aclib"],["abort-on-property-read","Adcash"],["override-property-read","isAdblock2","false"]],"yomovies.*":[["abort-on-property-read","window.open"],["prevent-window-open","/./"],["abort-current-inline-script","JSON.parse"]],"younetu.*":[["abort-on-property-write","window.open"],["abort-on-property-read","doSecondPop"],["abort-current-inline-script","atob","popundersPerIP"],["abort-on-property-read","BetterJsPop"]],"youporn.*":[["set","page_params.holiday_promo","true"]],"youtubedownloader.*":[["nowoif"]],"yoututosjeff.*":[["aopw","adBlockDetected"],["aeld","load","2000"]],"ytmp3.*":[["nowoif"]],"yts-official.*":[["abort-on-property-read","atob"],["abort-on-property-read","JSON.stringify"],["abort-on-property-read","localStorage"],["abort-on-property-read","window.__adFormats"]],"yts.*":[["nowebrtc"],["aeld","","_0x"],["aopr","runAdblock"],["nowoif"],["nostif","admc"],["acs","document.createElement","admc"],["aopw","Adcash"],["abort-on-property-read","atob"],["abort-on-property-read","localStorage"],["abort-on-property-read","window.__adFormats"]],"yts2.*":[["abort-on-property-read","JSON.stringify"]],"yurineko.*":[["abort-current-inline-script","WebAssembly","instantiate"]],"zbporn.*":[["aopr","decodeURI"],["aopr","promo"]],"zeefiles.*":[["ra","onclick","[onclick^=\"window.open\"]"],["nano-stb","tick"],["nowoif"]],"zoechip.*":[["abort-on-property-read","localStorage"]],"zonatmo.*":[["abort-on-property-write","zfgloadedpopup"],["prevent-listener","/click|mousedown/","/async/"]],"zone-annuaire.*":[["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"]],"zone-telechargement.*":[["abort-current-inline-script","document.documentElement","/atob|case|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-on-property-write","JSON.parse"],["abort-current-inline-script","Math","/atob|break/"],["abort-current-inline-script","JSON.stringify"],["abort-on-property-read","decodeURIComponent"]],"zooqle.*":[["nowebrtc"],["aeld","/^(?:mousedown|mouseup)$/","0x"]],"zplayer.*":[["abort-current-inline-script","document.documentElement","/atob|break|JSON.parse/"],["abort-current-inline-script","String.fromCharCode","/atob|break/"],["abort-current-inline-script","Math","/atob|break/"]]},"exceptions":{"3igames.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"abczdrowie.pl":["aost\u0000WP.prebid\u0000onLoad"],"account.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"auto.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"away.vk.com":["abort-on-property-read\u0000vk__adsLight.adsShowed"],"away.vk.ru":["abort-on-property-read\u0000vk__adsLight.adsShowed"],"biz.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"blog.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"bonus.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"calendar.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"calls.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"cloud.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"connect.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"deti.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"dev.fingerprint.com":["no-xhr-if\u0000method:POST"],"dobro.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"docs.fingerprint.com":["no-xhr-if\u0000method:POST"],"dziennikbaltycki.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"dzienniklodzki.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"dziennikpolski24.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"dziennikzachodni.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"e.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"echodnia.eu":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"expressbydgoski.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"expressilustrowany.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"finance.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"gazetakrakowska.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"gazetalubuska.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"gazetawroclawska.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"gibdd.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"gk24.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"gloswielkopolski.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"gol24.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"gp24.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"gra.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"gs24.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"health.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"help.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"hi-tech.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"horo.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"job.mt.de":["nostif\u0000.call(null)\u000010"],"job.nw.de":["nostif\u0000.call(null)\u000010"],"kino.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"kurierlubelski.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"lady.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"love.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"mcs.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"minigames.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"mmminigames.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"motofakty.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"my.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"naszemiasto.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"new.fastpic.org":["abort-current-inline-script\u0000document.getElementById\u0000maybeShow","abort-on-property-read\u0000Date.prototype.toUTCString","abort-on-property-read\u0000Element.prototype.attachShadow","abort-on-property-write\u0000__BIM__"],"news.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"notes.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"nowiny24.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"nowosci.com.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"nto.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"o2.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"octavius.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"okminigames.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"otvet.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"pcgames.de":["set\u0000CustomEvent\u0000noopFunc"],"pets.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"pingit.com":["aopr\u0000AaDetector","aopr\u0000_pop","aopr\u0000open","aopr\u0000rmVideoPlay","aopw\u0000Fingerprint2","set\u0000blurred\u0000false"],"plans.rainbowplantlife.com":["abort-on-property-read\u0000Intl.DateTimeFormat\u0000false","abort-on-property-read\u0000as_1058949371\u0000true","await\u0000new ","json-override\u0000isUnregistered\u0000true\u0000isUnregistered","override-property-read\u0000Navigator.prototype.onLine\u0000false","override-property-read\u0000as_-1217724578\u0000true","override-property-read\u0000as_-1269284192\u0000true","override-property-read\u0000as_-1349200120\u0000true","override-property-read\u0000as_-1499012015\u0000true","override-property-read\u0000as_-1858225736\u0000true","override-property-read\u0000as_-690327166\u0000true","override-property-read\u0000as_-930335972\u0000true","override-property-read\u0000as_-977715772\u0000true","override-property-read\u0000as_-989986399\u0000true","override-property-read\u0000as_1026413243\u0000true","override-property-read\u0000as_1098238358\u0000true","override-property-read\u0000as_1327966181\u0000true","override-property-read\u0000as_348516803\u0000true","override-property-read\u0000as_447456217\u0000true","override-property-read\u0000as_687465023\u0000true","override-property-read\u0000as_720001151\u0000true","override-property-read\u0000as_739024637\u0000true","override-property-read\u0000as_759290138\u0000true","override-property-read\u0000as_818940565\u0000true","override-property-read\u0000as_989017961\u0000true","replace-argument\u0000Element.prototype.setAttribute\u00001\u0000","replace-xhr-response\u0000/[\\s\\S]*/\u0000\u0000/pub_300x250/"],"player-smotri.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"poczta.wp.pl":["hide-if-matches-xpath\u0000.//div[@class and @* and not (@id)]//a[@class and @* and not (@id)][string-length(@href)>1000]//div[@class]//img[@class and @* and not (@id)][string-length(@src)>100]/ancestor::div[@class and @* and not(@id)][3]","hide-if-matches-xpath\u0000//a[string-length(@href)>1000]/img[@class and @*[not(name() = \"class\")]][string-length(@src)>125]","hide-if-matches-xpath\u0000//a[string-length(@href)>1000]/img[@src]/ancestor::div[.//span[normalize-space(text())=\"REKLAMA\"]][1][string-length(normalize-space()) < 100]","hide-if-matches-xpath\u0000//div[@class and @*[not(@class)]=\"\"]/div[not(*) and not(normalize-space())][@class and @*[not(@class)]=\"\"]/ancestor::div[@class and @*[not(@class)]=\"\"][contains(@class,\" \")][contains(@*[not(@class)],\" \")][string-length(@*[not(@class)]) > 25][not(starts-with(@class,\"app-container\") or starts-with(@class,\"sticky-wrapper\"))]","hide-if-matches-xpath\u0000//ul[@class]/li[string-length(@class)<=25][contains(normalize-space(), \" \")]/img[string-length(@src) >140]/following-sibling::span/a[string-length(@href) > 2000]/ancestor::li"],"pogoda.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"polskatimes.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"pomorska.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"poranny.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"sportowefakty.wp.pl":["hide-if-matches-xpath\u0000//a[string-length(@href)>1000]/img[@src]/ancestor::div[.//span[normalize-space(text())=\"REKLAMA\"]][1][string-length(normalize-space()) < 100]","hide-if-matches-xpath\u0000//div[@class and @*[not(@class)]=\"\"]/div[not(*) and not(normalize-space())][@class and @*[not(@class)]=\"\"]/ancestor::div[@class and @*[not(@class)]=\"\"][contains(@class,\" \")][contains(@*[not(@class)],\" \")][string-length(@*[not(@class)]) > 25][not(starts-with(@class,\"app-container\") or starts-with(@class,\"sticky-wrapper\"))]"],"sportowy24.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"strefaagro.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"strefabiznesu.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"stronakobiet.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"t-online.de":["set\u0000CustomEvent\u0000noopFunc"],"telemagazyn.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"to.com.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"todo.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"top.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"touch.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"tv.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"uii.io":["noeval"],"uqload.co":["abort-current-script\u0000document.createElement\u0000break;case $."],"vfokuse.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"vr.pornhat.*":["aopr\u0000document.dispatchEvent"],"widgets.mail.ru":["replace-fetch-response\u0000result\u0000.\u0000banner"],"wspolczesna.pl":["set-constant\u0000pp_adblock_is_off\u0000trueFunc"],"www.hoyolab.com":["trusted-set-cookie\u0000DEVICEFP\u000000000000000\u0000\u0000\u0000domain\u0000.hoyolab.com","trusted-set-cookie\u0000DEVICEFP_SEED_ID\u0000\u00000\u0000\u0000domain\u0000.hoyolab.com","trusted-set-cookie\u0000DEVICEFP_SEED_TIME\u0000\u00000\u0000\u0000domain\u0000.hoyolab.com"],"www.hoyoverse.com":["trusted-set-cookie\u0000DEVICEFP\u000000000000000\u0000\u0000\u0000domain\u0000.hoyoverse.com","trusted-set-cookie\u0000DEVICEFP_SEED_ID\u0000\u00000\u0000\u0000domain\u0000.hoyoverse.com","trusted-set-cookie\u0000DEVICEFP_SEED_TIME\u0000\u00000\u0000\u0000domain\u0000.hoyoverse.com"],"yandex.*":["aopr\u0000Object.prototype.renderDirect):matches-path(/\\/(?:weather\\/|pogoda\\/|hava\\/)/"]}});
