// Actualizador de listas de filtros. Descarga las listas (solo datos, nunca
// código), las compila en el propio navegador y guarda el resultado en
// IndexedDB. background.js lo aplica como reglas dinámicas, CSS y scriptlets.
//
// Privacidad: cada descarga es una petición anónima a la web oficial de la
// lista: sin cookies, sin referer, sin parámetros ni datos del usuario.
(() => {
  const DB_NAME = "scutumad-filters";
  const STORE = "data";
  const UPDATE_ALARM = "scutumad-filter-update";
  const UPDATE_INTERVAL_MINUTES = 6 * 60;
  const { FILTER_LISTS, OWN_LIST } = globalThis.ScutumADFilterLists;
  const { createCompiler, ownRules, stealthRules } = globalThis.ScutumADFilterCompiler;
  const { shardScriptlets, shardCode } = globalThis.ScutumADScriptletShards;
  let running = null;

  function openDb() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, 1);
      request.onupgradeneeded = () => request.result.createObjectStore(STORE);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async function transaction(mode, operation) {
    const db = await openDb();
    try {
      return await new Promise((resolve, reject) => {
        const tx = db.transaction(STORE, mode);
        const request = operation(tx.objectStore(STORE));
        tx.oncomplete = () => resolve(request?.result);
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(tx.error);
      });
    } finally {
      db.close();
    }
  }

  const idbGet = (key) => transaction("readonly", (store) => store.get(key));
  const idbSet = (key, value) => transaction("readwrite", (store) => store.put(value, key));
  const idbDelete = (key) => transaction("readwrite", (store) => store.delete(key));

  async function download(url) {
    const response = await fetch(url, {
      credentials: "omit",
      referrerPolicy: "no-referrer",
      cache: "no-cache",
      redirect: "follow",
      headers: { Accept: "text/plain" }
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const text = await response.text();
    if (text.length < 100) throw new Error("respuesta vacía");
    return text;
  }

  function listVersion(text) {
    return /^[!#]\s*(?:Version|Last modified|Updated):\s*(.+)$/mi.exec(text)?.[1]?.trim() || "sin versión";
  }

  async function runUpdate() {
    const meta = (await idbGet("meta")) || {};
    const sources = [];
    const failed = [];
    for (const list of FILTER_LISTS) {
      try {
        const text = await download(list.url);
        await idbSet(`list:${list.id}`, text);
        sources.push({ list, text });
      } catch (error) {
        // Si falla una descarga se usa la última copia buena de esa lista.
        const cached = await idbGet(`list:${list.id}`);
        if (!cached) throw new Error(`${list.title}: ${error.message}`);
        failed.push(list.title);
        sources.push({ list, text: cached });
      }
    }
    const own = await (await fetch(chrome.runtime.getURL("filters/scutumad.txt"))).text();
    sources.push({ list: OWN_LIST, text: own });

    const compiler = createCompiler();
    for (const { text } of sources) compiler.collectBadfilters(text);
    for (const { list, text } of sources) compiler.addList(text, list);
    const { rulesets, trackingParams, cosmetic, scriptlets } = compiler.finish();
    for (const [category, rules] of Object.entries(ownRules(trackingParams))) rulesets[category] = [...(rulesets[category] || []), ...rules];
    rulesets.stealth = stealthRules([...rulesets.ads, ...rulesets.scutumad]);

    const engine = await (await fetch(chrome.runtime.getURL("src/scriptlets/engine.js"))).text();
    const shards = shardScriptlets(scriptlets).map((shard) => ({
      id: shard.id, matches: shard.matches, code: shardCode(engine, shard.data)
    }));

    await idbSet("rules", rulesets);
    await idbSet("cosmetic", cosmetic);
    await idbSet("scriptlets", shards);
    const next = {
      ...meta,
      dynamic: true,
      updatedAt: Date.now(),
      lastAttempt: Date.now(),
      lastError: failed.length ? `Sin conexión con: ${failed.join(", ")} (se usó la copia anterior)` : null,
      versions: Object.fromEntries(sources.map(({ list, text }) => [list.title, listVersion(text)])),
      ruleCount: Object.values(rulesets).reduce((total, rules) => total + rules.length, 0)
    };
    await idbSet("meta", next);
    return next;
  }

  // force: actualizar aunque la última actualización sea reciente o la
  // actualización automática esté desactivada (botón «Actualizar ahora»).
  async function updateFilterLists({ force = false } = {}) {
    if (running) return running;
    running = (async () => {
      const settings = await readSettings();
      const meta = (await idbGet("meta")) || {};
      if (!force) {
        if (!settings.autoUpdateLists) return meta;
        if (meta.lastAttempt && Date.now() - meta.lastAttempt < (UPDATE_INTERVAL_MINUTES - 10) * 60000) return meta;
      }
      try {
        const next = await runUpdate();
        await onFilterListsUpdated();
        return next;
      } catch (error) {
        const failed = { ...meta, lastAttempt: Date.now(), lastError: error.message };
        await idbSet("meta", failed);
        return failed;
      }
    })().finally(() => { running = null; });
    return running;
  }

  // Vuelve a las listas incluidas en el paquete (sin borrar las descargas).
  async function useBundledLists() {
    const meta = (await idbGet("meta")) || {};
    await idbSet("meta", { ...meta, dynamic: false });
    await onFilterListsUpdated();
    return { ...meta, dynamic: false };
  }

  function scheduleUpdates() {
    chrome.alarms?.create(UPDATE_ALARM, { delayInMinutes: 1, periodInMinutes: UPDATE_INTERVAL_MINUTES });
  }
  chrome.alarms?.onAlarm.addListener((alarm) => {
    if (alarm.name === UPDATE_ALARM) void updateFilterLists();
  });

  globalThis.ScutumADUpdater = Object.freeze({
    updateFilterLists, useBundledLists, scheduleUpdates,
    meta: () => idbGet("meta").then((meta) => meta || {}),
    compiled: async (key) => {
      const meta = await idbGet("meta");
      return meta?.dynamic ? idbGet(key) : null;
    },
    clear: () => Promise.all(["meta", "rules", "cosmetic", "scriptlets"].map(idbDelete))
  });
})();
