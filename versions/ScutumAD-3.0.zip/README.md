# ScutumAD

ScutumAD 3.0 es una extensión de Google Chrome (Manifest V3) que bloquea publicidad, rastreadores, distracciones y webs peligrosas con las mismas listas que usan los bloqueadores profesionales. Funciona en tu navegador, sin servidor propio ni telemetría. Solo se conecta para actualizar sus listas de filtros, de forma anónima (ver `PRIVACIDAD.md`).

## Qué hace

- **Listas profesionales:** EasyList, EasyList Spanish, EasyPrivacy, las listas de uBlock Origin (filtros, privacidad, malware, arreglos rápidos y excepciones), la lista anti-circunvención de Adblock Plus, las de newsletters y notificaciones de Fanboy, y las de malware y phishing de malware-filter.
  - Unas **19.000 reglas de red** (más de 100.000 dominios agrupados).
  - Unos **15.000 selectores cosméticos**.
  - **Scriptlets** para unos 6.700 sitios.
- **Actualización automática:** cada 6 horas descarga las listas, las compila en el navegador y las aplica sin reiniciar. Si falla una descarga, usa la última copia buena de esa lista. Las listas incluidas en la versión son el respaldo.
- **Modos por sitio:** se eligen desde el popup.
  - **Desactivado:** no bloquea nada.
  - **Básico:** solo bloquea en la red.
  - **Óptimo** (predeterminado): red, ocultación y scriptlets.
  - **Estricto:** como Óptimo, y además cierra cualquier pop-up que no hayas pedido.
- **Ocultación por CSS:** cada web recibe solo sus selectores y Chrome los aplica sin recorrer la página (unos 8 ms la primera vez).
- **Scriptlets:** desactivan detectores de bloqueadores y retiran anuncios del código de la página. El motor es propio y compatible con los nombres de uBlock Origin y Adblock Plus. Si un sitio necesita un scriptlet que el motor no tiene, no se le aplica ninguno, para no romper la web aplicando solo una parte.
- **Sustitutos locales** de `gtag.js`, `gtm.js`, `analytics.js`, `gpt.js`, `adsbygoogle.js`, FuckAdBlock/BlockAdBlock y recursos vacíos: las webs no se rompen al bloquear esos scripts.
- **Limpieza de enlaces:** quita 130 parámetros de rastreo (`utm_*`, `fbclid`, `gclid`…) de las páginas que abres.
- **Webs peligrosas:** bloquea dominios de malware y phishing.
- **YouTube:** módulo propio que oculta los anuncios del feed y salta los del reproductor. Las reglas de red nunca tocan lo que inicia YouTube, y no se aplican scriptlets a YouTube, para evitar su bloqueo anti-adblock.
- **Cortafuegos de pop-ups** en dos capas para reproductores de streaming (y para cualquier web en modo Estricto).
- **Modo aprendizaje:**
  - selecciona un elemento, amplía o reduce la selección y ve el filtro antes de guardarlo;
  - con **Quitar solo ahora** lo oculta sin guardar nada;
  - también aprende páginas publicitarias que se abren solas.
- **Registro de bloqueos:** «Ver lo bloqueado en esta pestaña» muestra en directo qué se bloquea y con qué lista. No guarda nada.
- **Modo sigiloso** (activado por defecto), para que las webs no detecten el bloqueador ni pidan desactivarlo:
  - los scripts, imágenes, peticiones y marcos publicitarios bloqueados se sustituyen por archivos vacíos que cargan sin error;
  - la ocultación genérica deja el anuncio invisible pero con su tamaño, así un elemento «cebo» no delata al bloqueador (pueden quedar huecos en blanco);
  - los nombres que ScutumAD usa en la página son aleatorios y las funciones que modifica siguen pareciendo nativas.
- **Contador** de peticiones bloqueadas en el icono.
- **Copia de seguridad:** exporta e importa en JSON los ajustes, los modos por sitio y las reglas aprendidas.
- Una web no puede desactivar la protección imitando los mensajes internos de ScutumAD.

## Instalar en Chrome

1. Descomprime la ZIP en una carpeta permanente.
2. Abre `chrome://extensions/` y activa **Modo de desarrollador**.
3. Pulsa **Cargar descomprimida** y elige la carpeta que contiene `manifest.json`.
4. Opcional, recomendado: en **Detalles** de ScutumAD, activa **Permitir scripts de usuario**. Así los scriptlets también usan las listas actualizadas; si no, se usan los incluidos en la versión.
5. Fija el icono de ScutumAD en la barra.

Chrome identifica las extensiones descomprimidas por su carpeta: si la mueves, empieza con ajustes nuevos. Antes de moverla, exporta los ajustes desde Configuración.

## Permisos

| Permiso | Para qué |
|---|---|
| `declarativeNetRequest` | Bloqueo de red, sustitutos y limpieza de enlaces. Chrome aplica las reglas y ScutumAD no ve las peticiones. |
| `declarativeNetRequestFeedback` | El registro de bloqueos, solo mientras su página está abierta. |
| `scripting`, `userScripts` | Inyectar los scriptlets solo en los sitios que los necesitan. |
| `storage` | Ajustes, modos por sitio y reglas aprendidas. |
| `alarms` | Actualizar las listas cada 6 horas. |
| `webNavigation` | Segunda barrera del cortafuegos de pop-ups. |
| `offscreen` | Adaptar el icono al tema claro u oscuro. |
| `<all_urls>` | Aplicar la protección en las webs y descargar las listas. |

## Estructura

```text
ScutumAD/
├── manifest.json
├── src/
│   ├── background/   # Worker: reglas, actualizador, cortafuegos, aprendizaje
│   ├── content/      # Scripts de página: ocultación, aprendizaje, pop-ups
│   ├── youtube/      # Módulo de YouTube
│   ├── scriptlets/   # Motor de scriptlets
│   ├── shared/       # Ajustes, listas, compilador y políticas comunes
│   ├── surrogates/   # Sustitutos locales
│   └── offscreen/    # Icono adaptativo
├── popup/  options/  logger/
├── filters/scutumad.txt   # Filtros propios (sintaxis Adblock Plus)
├── rules/                 # Generado: rulesets (también stealth.json), cosmético y scriptlets
├── icons/  assets/
├── scripts/               # build-rules.mjs, prune-regex.mjs y validate.mjs
├── tests/
├── docs/  licenses/  INSTALACION/
├── PRIVACIDAD.md
└── README.md
```

## Desarrollo

Regenerar las listas incluidas en la versión (`.cache/` queda fuera del paquete):

```bash
node scripts/build-rules.mjs --download
```

Auditoría y pruebas:

```bash
node scripts/validate.mjs
```

```bash
node --test tests/*.mjs
```

```bash
node scripts/chrome-check.mjs
```

`chrome-check.mjs` carga la extensión en un Chrome real sin interfaz y comprueba el ID fijo, el service worker y que todos los rulesets estén activos. GitHub ejecuta estas tres comprobaciones en cada cambio (`.github/workflows/pruebas.yml`).

Publicar una versión: sube `version` en `manifest.json` y llévalo a `main`. Si las pruebas pasan, `.github/workflows/publicar.yml` empaqueta con `scripts/package.mjs`, firma el paquete (Ed25519, clave pública en `updater/release-key.pub`) y lo publica en `tocaway/ScutumAD-releases`.

Chrome rechaza las regex que superan 2 KB compiladas y, en modo desarrollador, las lista como errores de la extensión. `build-rules.mjs` llama a `prune-regex.mjs`, que carga la extensión en un Chrome temporal, pregunta con `isRegexSupported` y quita las que Chrome no acepta (define `SCUTUMAD_CHROME` si Chrome no está en su ruta habitual). La prueba completa en navegador (`tests/browser-behavior.mjs`) necesita Playwright mediante `SCUTUMAD_PLAYWRIGHT_DIR`; sin él se omite.

## Licencias

El código de ScutumAD es propietario (ver `LICENSE`) y para uso personal. Las listas incluidas mantienen sus licencias: CC BY-SA, CC BY, CC0 y **GPLv3** (las de uBlock Origin y la anti-circunvención de Adblock Plus). Detalles y atribución en `licenses/THIRD_PARTY_NOTICES.md`. Si algún día distribuyes ScutumAD a terceros, revisa antes las obligaciones de la GPLv3.
