# Dependencias de ScutumAD

## Estado de la versión 3.0.6

- Dependencias npm de ejecución: ninguna.
- Bibliotecas JavaScript externas empaquetadas: ninguna.
- Código remoto ejecutable: prohibido y no incluido.
- Motor de filtrado: APIs nativas de Chrome y código propio.
- Listas de filtros de terceros: incluidas como datos y compiladas con
  `scripts/build-rules.mjs` (sin dependencias npm). Licencias en
  `THIRD_PARTY_NOTICES.md`.
- Almacenamiento: `chrome.storage.local`.
- Pruebas opcionales de navegador: Playwright externo al paquete, únicamente
  como herramienta de desarrollo; licencia Apache-2.0. No se redistribuye.

La ausencia de `package.json` es intencionada: el paquete de la extensión no
necesita instalar módulos para funcionar. Si se propone añadir una dependencia,
deberá justificarse, comprobarse su licencia y sus dependencias transitivas,
revisarse por vulnerabilidades y añadirse a `THIRD_PARTY_NOTICES.md` cuando
corresponda.
