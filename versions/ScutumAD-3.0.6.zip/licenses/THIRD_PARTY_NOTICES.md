# Third-Party Notices

ScutumAD 3.0.6 incluye listas de filtros de terceros convertidas a reglas de
Chrome. El código JavaScript, la interfaz, los iconos, el conversor
(`scripts/build-rules.mjs`), los sustitutos de `src/surrogates/` y los filtros
propios (`filters/scutumad.txt`, compilados a `rules/scutumad.json` y
`rules/privacy.json`) son implementación propia de ScutumAD.

## Listas de filtros incluidas

Las listas se descargan al preparar cada versión y, con la actualización
automática activada, cada 6 horas desde la propia extensión. Se convierten a
`declarativeNetRequest`, CSS y argumentos de scriptlets. El resultado, que es una adaptación de esas
listas, se distribuye bajo la licencia de cada una. Se mantiene separado de las
reglas propias de ScutumAD:

| Lista | Autores | Licencia | Archivos generados |
|---|---|---|---|
| [EasyList](https://easylist.to/) | The EasyList authors | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/) (doble licencia con GPLv3; ScutumAD la usa bajo CC BY-SA 3.0) | `rules/ads.json`, sección `ads` de `rules/cosmetic.json` |
| [EasyList Spanish](https://easylist.to/) | The EasyList authors | CC BY-SA 3.0 / GPLv3 (usada bajo CC BY-SA 3.0) | `rules/ads.json`, sección `ads` de `rules/cosmetic.json` |
| [EasyPrivacy](https://easylist.to/) | The EasyList authors | CC BY-SA 3.0 / GPLv3 (usada bajo CC BY-SA 3.0) | `rules/trackers.json` |
| [uBlock filters, Privacy, Badware risks, Quick fixes, Unbreak](https://github.com/uBlockOrigin/uAssets) | Raymond Hill y colaboradores de uAssets | [GPLv3](https://www.gnu.org/licenses/gpl-3.0.html) | `rules/ads.json`, `rules/trackers.json`, `rules/malware.json`, `rules/cosmetic.json`, `rules/scriptlets/` |
| [ABP Anti-Circumvention Filter List](https://gitlab.com/eyeo/anti-cv/abp-filters-anti-cv) | eyeo GmbH y colaboradores | GPLv3 | `rules/ads.json`, `rules/cosmetic.json`, `rules/scriptlets/` |
| [Fanboy's Newsletter List](https://easylist.to/) | Fanboy | [CC BY 3.0](https://creativecommons.org/licenses/by/3.0/) | `rules/annoyances.json`, sección `annoyances` de `rules/cosmetic.json` |
| [Fanboy's Notifications Blocking List](https://easylist.to/) | Fanboy | CC BY 3.0 | `rules/annoyances.json`, sección `annoyances` de `rules/cosmetic.json` |
| [urlhaus-filter](https://gitlab.com/malware-filter/urlhaus-filter) | malware-filter (datos de URLhaus, abuse.ch) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) | `rules/malware.json` |
| [phishing-filter](https://gitlab.com/malware-filter/phishing-filter) | malware-filter (datos de OpenPhish, PhishTank e IPThreat) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/); fuentes con sus propias condiciones de uso gratuito | `rules/malware.json` |

Cambios realizados: conversión de la sintaxis Adblock Plus a reglas
`declarativeNetRequest` y a CSS, omisión de los filtros que Chrome no puede
reproducir y exclusión de las peticiones que inicia YouTube. Los archivos
generados indican la versión de cada lista en `rules/cosmetic.json`
(`versions`).

## APIs del navegador

ScutumAD utiliza APIs públicas de Chrome documentadas por Google, entre ellas
`declarativeNetRequest`, `scripting`, `userScripts`, `alarms`, `storage`,
`offscreen`, `webNavigation`, `tabs` y `action`. Estas APIs no se redistribuyen como componentes dentro de la
extensión.

## Referencias conceptuales y pruebas

Se consultó la documentación pública de las categorías de filtros de AdGuard
para estudiar el concepto de separar publicidad y ventanas innecesarias, sin
copiar código, reglas ni listas: [documentación de filtros](https://adguard.com/kb/general/ad-filtering/adguard-filters/).
La implementación del cortafuegos se basa en la especificación propia y la
[API oficial de navegación de Chrome](https://developer.chrome.com/docs/extensions/reference/api/webNavigation).
Playwright (Apache-2.0) y Chrome for Testing se usan solo como herramientas
externas de pruebas; sus binarios y bibliotecas no se incluyen en la ZIP.

No se incorpora código de uBlock Origin, AdGuard ni Adblock Plus. El motor de
scriptlets (`src/scriptlets/engine.js`) y los sustitutos son implementación
propia que acepta los mismos nombres de scriptlet y de recurso que esas listas.

ScutumAD se usa de forma personal. Las listas GPLv3 se incluyen como datos
separados; si se distribuyera ScutumAD a terceros, habría que cumplir la GPLv3
para esos archivos (ofrecer su fuente y conservar la licencia).
