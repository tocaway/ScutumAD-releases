// Ventana de aviso de actualización. ?mode=available: hay una versión nueva
// (Actualizar ahora / Más tarde). ?mode=updated: ScutumAD acaba de actualizarse.
(async () => {
  const $ = (id) => document.getElementById(id);
  const mode = new URLSearchParams(location.search).get("mode");
  const send = (type) => chrome.runtime.sendMessage({ type }).catch(() => null);
  // Las notas llegan como "3.0.6: texto"; se muestra solo el texto.
  const showNotes = (notes = []) => $("notes").replaceChildren(...notes.map((note) => {
    const item = document.createElement("li");
    item.textContent = String(note).replace(/^\d+(?:\.\d+)+:\s*/, "");
    return item;
  }));

  $("secondary").addEventListener("click", () => window.close());
  const state = (await send("APP_UPDATE_STATUS"))?.update || {};

  if (mode === "updated") {
    $("title").textContent = `ScutumAD se ha actualizado a la ${state.running}`;
    $("subtitle").textContent = await globalThis.ScutumADVersion?.versionText() || `v${state.running}`;
    showNotes(state.lastApplied?.notes);
    $("secondary").hidden = true;
    $("primary").textContent = "Vale";
    $("primary").addEventListener("click", () => window.close());
    return;
  }

  const version = state.latest?.version;
  $("title").textContent = version ? `ScutumAD ${version} disponible` : "ScutumAD está al día";
  $("subtitle").textContent = `Tienes la versión ${state.running}`;
  showNotes(state.latest?.notes);
  if (!state.available) {
    $("primary").hidden = true;
    $("secondary").textContent = "Cerrar";
    return;
  }
  $("primary").addEventListener("click", async () => {
    $("primary").disabled = $("secondary").disabled = true;
    $("primary").textContent = "Actualizando…";
    const result = (await send("APP_UPDATE_APPLY"))?.update;
    // Si se instala, la extensión se recarga y esta ventana se cierra sola.
    if (result?.reloading) return;
    $("message").textContent = result?.error || "No se pudo actualizar. Inténtalo desde Configuración.";
    $("primary").textContent = "Actualizar ahora";
    $("primary").disabled = $("secondary").disabled = false;
  });
})();
