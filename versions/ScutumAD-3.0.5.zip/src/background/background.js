importScripts("../shared/settings.js", "../shared/popup-policy.js", "../shared/learning-policy.js",
  "../shared/filter-lists.js", "../shared/filter-compiler.js", "../shared/scriptlet-shards.js", "updater.js");
const { CATEGORY_SETTINGS } = ScutumADFilterLists;
const { DEFAULT_SETTINGS, SITE_MODES, siteModeFor } = ScutumADSettings;
// Claves de versiones anteriores que ya no se usan.
const OBSOLETE_SETTINGS = ["stats", "videoAccelerationEnabled", "videoAccelerationLevel", "blockDownloads"];

const RULESET_IDS = ["ads", "scutumad", "trackers", "privacy", "annoyances", "malware", "stealth"];
const DYNAMIC_RULE_BASE_ID = 100000;
const MAX_WHITELIST_ENTRIES = 200;
const MAX_SITE_MODES = 500;
const MAX_LEARNED_RULES = 300;
const MAX_LEARNED_SELECTOR_LENGTH = 700;

let rulesSyncQueue = Promise.resolve();
let settingsMutationQueue = Promise.resolve();
function queueSettingsMutation(operation) {
  const result = settingsMutationQueue.then(operation);
  settingsMutationQueue = result.catch(() => {});
  return result;
}
const OFFSCREEN_DOCUMENT = "src/offscreen/offscreen.html";

function normalizeDomain(value) {
  if (typeof value !== "string") {
    return null;
  }

  let candidate = value.trim().toLowerCase();
  if (!candidate) {
    return null;
  }

  try {
    if (!candidate.includes("://")) {
      candidate = `https://${candidate}`;
    }
    const parsed = new URL(candidate);
    const hostname = parsed.hostname.replace(/^\.+|\.+$/g, "");
    if (!hostname || hostname.includes("/") || hostname.includes("@")) {
      return null;
    }
    if (!/^[a-z0-9.-]+$/i.test(hostname)) {
      return null;
    }
    return hostname;
  } catch {
    return null;
  }
}

function normalizeLearnedRule(value) {
  if (!value || typeof value !== "object") {
    return null;
  }

  const domain = normalizeDomain(value.domain);
  if (value.action === "block-popup") {
    const destinationDomain = normalizeDomain(value.destinationDomain);
    if (!domain || !destinationDomain || domain === destinationDomain) return null;
    return { id: Number.isInteger(value.id) ? value.id : null, domain, destinationDomain, action: "block-popup", confidence: 1 };
  }
  if (value.frameDomain && !normalizeDomain(value.frameDomain)) return null;
  const normalized = ScutumADLearningPolicy.normalizeSelector(value.selector);
  const selector = normalized?.selector || "";
  if (!domain || !selector || selector.length > MAX_LEARNED_SELECTOR_LENGTH) {
    return null;
  }

  // Los selectores se generan localmente a partir del DOM y nunca deben
  // convertirse en una vía para inyectar CSS arbitrario.
  if (/[{};<>]/.test(selector) || /(?:javascript|data):/i.test(selector)) {
    return null;
  }

  const id = Number.isInteger(value.id) && value.id > 0 ? value.id : null;
  return {
    id,
    domain,
    selector,
    action: "hide",
    confidence: 1,
    ...(value.frameDomain ? { frameDomain: normalizeDomain(value.frameDomain) } : {}),
    ...((value.disabled || normalized.disabled) ? { disabled: true } : {})
  };
}

function normalizeLearnedRules(value) {
  if (!Array.isArray(value)) {
    return [];
  }

  const seen = new Set();
  const rules = [];
  value.forEach((entry) => {
    const rule = normalizeLearnedRule(entry);
    if (!rule) {
      return;
    }
    const key = `${rule.domain}\u0000${rule.action}\u0000${rule.selector || rule.destinationDomain}\u0000${rule.frameDomain || ""}`;
    if (seen.has(key)) {
      return;
    }
    seen.add(key);
    rules.push(rule);
  });
  return rules.slice(0, MAX_LEARNED_RULES);
}

async function readSettings() {
  const stored = await chrome.storage.local.get(DEFAULT_SETTINGS);
  const whitelist = Array.isArray(stored.whitelist)
    ? stored.whitelist.map(normalizeDomain).filter(Boolean).slice(0, MAX_WHITELIST_ENTRIES)
    : [];
  const learnedRules = normalizeLearnedRules(stored.learnedRules);

  return {
    siteModes: normalizeSiteModes(stored.siteModes),
    protectionEnabled: stored.protectionEnabled !== false,
    blockAds: stored.blockAds !== false,
    blockTrackers: stored.blockTrackers !== false,
    youtubeProtection: stored.youtubeProtection !== false,
    blockAnnoyances: stored.blockAnnoyances !== false,
    blockMalware: stored.blockMalware !== false,
    learningEnabled: stored.learningEnabled === true,
    autoUpdateLists: stored.autoUpdateLists !== false,
    stealthMode: stored.stealthMode !== false,
    learnedRules,
    whitelist: [...new Set(whitelist)]
  };
}

// Solo basic y strict se guardan aquí: optimal es el predeterminado y off
// vive en la lista blanca.
function normalizeSiteModes(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};
  const entries = Object.entries(value)
    .map(([domain, mode]) => [normalizeDomain(domain), mode])
    .filter(([domain, mode]) => domain && (mode === "basic" || mode === "strict"))
    .slice(0, MAX_SITE_MODES);
  return Object.fromEntries(entries);
}

function siteModeForUrls(urls, settings) {
  return siteModeFor(urls.map((url) => httpHostname(url)), settings);
}

function isWhitelisted(hostname, whitelist) {
  if (!hostname || !Array.isArray(whitelist)) {
    return false;
  }

  const normalizedHost = hostname.toLowerCase().replace(/\.$/, "");
  return whitelist.some((domain) => (
    normalizedHost === domain || normalizedHost.endsWith(`.${domain}`)
  ));
}

function buildWhitelistRules(whitelist) {
  const rules = [];

  whitelist.forEach((domain, index) => {
    const firstId = DYNAMIC_RULE_BASE_ID + index * 2;

    rules.push({
      id: firstId,
      priority: 1000,
      action: { type: "allow" },
      condition: { initiatorDomains: [domain] }
    });

    // allowAllRequests cubre también lo que carguen los marcos del sitio,
    // aunque la petición la inicie un tercero incrustado.
    rules.push({
      id: firstId + 1,
      priority: 1000,
      action: { type: "allowAllRequests" },
      condition: {
        requestDomains: [domain],
        resourceTypes: ["main_frame", "sub_frame"]
      }
    });
  });

  return rules;
}

function enabledCategories(settings) {
  if (!settings.protectionEnabled) return [];
  // El modo sigiloso transforma bloqueos de publicidad: sin ellos no aplica.
  return Object.entries(CATEGORY_SETTINGS)
    .filter(([category, setting]) => settings[setting] && (category !== "stealth" || settings.blockAds))
    .map(([category]) => category);
}

// Chrome indica qué regla rechaza; se quita esa y se reintenta.
async function updateDynamicRulesDroppingInvalid(removeRuleIds, addRules) {
  let rules = addRules;
  for (let attempt = 0; attempt < 50; attempt++) {
    try {
      await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules: rules });
      return true;
    } catch (error) {
      const id = Number(/Rule with id (\d+)/.exec(error.message)?.[1]);
      if (!id || id >= DYNAMIC_RULE_BASE_ID) throw error;
      rules = rules.filter((rule) => rule.id !== id);
    }
  }
  return false;
}

// Reglas de las listas actualizadas como reglas dinámicas (ids < 100000) y
// lista blanca (ids >= 100000). Devuelve false si no caben o no hay listas
// actualizadas: entonces se usan los rulesets incluidos en el paquete.
async function syncDynamicRules(settings, categories) {
  const whitelistRules = buildWhitelistRules(settings.whitelist);
  const current = await chrome.declarativeNetRequest.getDynamicRules();
  const currentListIds = current.filter((rule) => rule.id < DYNAMIC_RULE_BASE_ID).map((rule) => rule.id);
  const currentWhitelistIds = current.filter((rule) => rule.id >= DYNAMIC_RULE_BASE_ID).map((rule) => rule.id);
  const meta = await ScutumADUpdater.meta();
  const compiled = meta.dynamic ? await ScutumADUpdater.compiled("rules") : null;
  const signature = compiled ? `${meta.updatedAt}|${categories.join(",")}` : "";
  const { appliedSignature } = await chrome.storage.session.get("appliedSignature").catch(() => ({}));

  if (signature && signature === appliedSignature && currentListIds.length) {
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: currentWhitelistIds, addRules: whitelistRules });
    return true;
  }

  let listRules = [];
  if (compiled) {
    const regexSupport = new Map();
    for (const category of categories) {
      for (const rule of compiled[category] || []) {
        const regex = rule.condition.regexFilter;
        if (regex) {
          if (!regexSupport.has(regex)) {
            const result = await chrome.declarativeNetRequest.isRegexSupported({ regex }).catch(() => ({}));
            regexSupport.set(regex, result.isSupported === true);
          }
          if (!regexSupport.get(regex)) continue;
        }
        listRules.push(rule);
      }
    }
    const unsafe = listRules.filter((rule) => rule.action.type === "redirect").length;
    const regexCount = listRules.filter((rule) => rule.condition.regexFilter).length;
    const fits = listRules.length + whitelistRules.length <= (chrome.declarativeNetRequest.MAX_NUMBER_OF_DYNAMIC_RULES || 30000)
      && unsafe <= (chrome.declarativeNetRequest.MAX_NUMBER_OF_UNSAFE_DYNAMIC_RULES || 5000)
      && regexCount <= (chrome.declarativeNetRequest.MAX_NUMBER_OF_REGEX_RULES || 1000);
    if (!fits) listRules = [];
    listRules = listRules.map((rule, index) => ({ id: index + 1, ...rule }));
  }

  try {
    await updateDynamicRulesDroppingInvalid([...currentListIds, ...currentWhitelistIds], [...listRules, ...whitelistRules]);
  } catch {
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [...currentListIds, ...currentWhitelistIds], addRules: whitelistRules
    });
    listRules = [];
  }
  const active = listRules.length > 0;
  await chrome.storage.session.set({ appliedSignature: active ? signature : "" }).catch(() => {});
  return active || (compiled && categories.length === 0);
}

async function syncNetworkRules(settings) {
  const categories = enabledCategories(settings);
  const dynamicActive = await syncDynamicRules(settings, categories);
  // Con listas actualizadas, los rulesets del paquete se apagan.
  const enableRulesetIds = dynamicActive ? [] : categories;
  await chrome.declarativeNetRequest.updateEnabledRulesets({
    enableRulesetIds,
    disableRulesetIds: RULESET_IDS.filter((id) => !enableRulesetIds.includes(id))
  });
}

// Scriptlets: un trozo por grupo de dominios, nunca en sitios con modo
// Desactivado o Básico. Con las listas actualizadas se registran como
// scripts de usuario (necesita «Permitir scripts de usuario» en Chrome); si
// no, se usan los trozos incluidos en el paquete.
const SCRIPTLET_PREFIX = "scutumad-scriptlets-";
let bundledScriptletIndex = null;

async function userScriptsAvailable() {
  try {
    await chrome.userScripts.getScripts();
    return true;
  } catch {
    return false;
  }
}

async function syncScriptlets(settings) {
  const pattern = (domain) => `*://*.${domain}/*`;
  const excludeMatches = [
    ...settings.whitelist,
    ...Object.entries(settings.siteModes).filter(([, mode]) => mode === "basic").map(([domain]) => domain)
  ].map(pattern);
  const enabled = settings.protectionEnabled && settings.blockAds;
  const userScripts = await userScriptsAvailable();
  const updatedShards = enabled && userScripts ? await ScutumADUpdater.compiled("scriptlets") : null;

  const registered = await chrome.scripting.getRegisteredContentScripts();
  const ours = registered.filter((script) => script.id.startsWith(SCRIPTLET_PREFIX)).map((script) => script.id);
  if (ours.length) await chrome.scripting.unregisterContentScripts({ ids: ours });
  if (userScripts) {
    const existing = (await chrome.userScripts.getScripts()).filter((script) => script.id.startsWith(SCRIPTLET_PREFIX));
    if (existing.length) await chrome.userScripts.unregister({ ids: existing.map((script) => script.id) });
  }
  if (!enabled) return;

  const common = { ...(excludeMatches.length ? { excludeMatches } : {}), runAt: "document_start", allFrames: true, world: "MAIN" };
  if (updatedShards?.length) {
    await chrome.userScripts.register(updatedShards.map((shard) => ({
      id: `${SCRIPTLET_PREFIX}${shard.id}`, matches: shard.matches, js: [{ code: shard.code }], ...common
    })));
    return;
  }
  bundledScriptletIndex ||= fetch(chrome.runtime.getURL("rules/scriptlets/index.json"))
    .then((response) => response.json()).catch(() => []);
  const index = await bundledScriptletIndex;
  if (!index.length) return;
  await chrome.scripting.registerContentScripts(index.map((shard) => ({
    id: `${SCRIPTLET_PREFIX}${shard.id}`, matches: shard.matches, js: [shard.file], persistAcrossSessions: true, ...common
  })));
}

function queueRulesSync() {
  rulesSyncQueue = rulesSyncQueue
    .catch(() => {})
    .then(async () => {
      const settings = await readSettings();
      await syncNetworkRules(settings);
      await syncScriptlets(settings);
    });
  return rulesSyncQueue;
}

// Llamado por updater.js tras compilar listas nuevas o volver a las incluidas.
async function onFilterListsUpdated() {
  cosmeticData = null;
  cosmeticCache.clear();
  await chrome.storage.session.set({ appliedSignature: "" }).catch(() => {});
  await queueRulesSync();
}

async function ensureDefaults() {
  const settings = await readSettings();
  await chrome.storage.local.set(settings);

  // Borra los contadores y ajustes de versiones anteriores. ScutumAD no
  // conserva actividad de navegación, URLs, contenido ni estadísticas.
  await chrome.storage.local.remove(OBSOLETE_SETTINGS);
}

// Chrome cuenta en memoria las peticiones bloqueadas de cada pestaña y las
// muestra en el icono. ScutumAD no lee ni guarda esa cifra.
function showBlockedCount() {
  return chrome.declarativeNetRequest.setExtensionActionOptions?.({
    displayActionCountAsBadgeText: true
  });
}

async function ensureThemeDocument() {
  const documentUrl = chrome.runtime.getURL(OFFSCREEN_DOCUMENT);
  const existing = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
    documentUrls: [documentUrl]
  });

  if (existing.length === 0) {
    await chrome.offscreen.createDocument({
      url: documentUrl,
      reasons: ["MATCH_MEDIA"],
      justification: "Adaptar localmente el icono de ScutumAD al tema claro u oscuro"
    });
  }
}

async function applyThemeIcon(iconPixels) {
  if (!iconPixels || typeof OffscreenCanvas !== "function") {
    return;
  }

  const imageData = {};
  for (const size of [16, 32, 48, 128]) {
    const pixels = iconPixels[String(size)];
    if (!Array.isArray(pixels) || pixels.length !== size * size * 4) {
      return;
    }
    const canvas = new OffscreenCanvas(size, size);
    const context = canvas.getContext("2d");
    const data = context.createImageData(size, size);
    data.data.set(pixels);
    imageData[size] = data;
  }

  await chrome.action.setIcon({ imageData });
}

function httpHostname(value) {
  try {
    const parsed = new URL(value || "");
    return /^https?:$/.test(parsed.protocol)
      ? parsed.hostname.toLowerCase().replace(/\.$/, "")
      : null;
  } catch {
    return null;
  }
}

// Ocultación cosmética compilada de las listas (rules/cosmetic.json). Se
// carga una vez y se sirve a cada marco solo con los selectores que le tocan.
const COSMETIC_CATEGORIES = { blockAds: ["ads", "scutumad"], blockAnnoyances: ["annoyances"] };
const COSMETIC_CACHE_LIMIT = 64;
let cosmeticData = null;
const cosmeticCache = new Map();

async function loadCosmeticData() {
  if (!cosmeticData) {
    cosmeticData = ScutumADUpdater.compiled("cosmetic")
      .then((updated) => updated || fetch(chrome.runtime.getURL("rules/cosmetic.json")).then((response) => response.json()))
      .then((data) => {
        for (const category of Object.values(COSMETIC_CATEGORIES).flat()) {
          if (data[category]) {
            data[category].genericCss = cssFor(data[category].generic);
            data[category].stealthGenericCss = cssFor(data[category].generic, true);
          }
        }
        return data;
      })
      .catch((error) => {
        cosmeticData = null;
        throw error;
      });
  }
  return cosmeticData;
}

// Cada selector va en su propia regla: si Chrome no entiende uno, descarta
// solo esa regla y no el bloque entero. "selector\0estilos" viene de
// `:style()` de uBlock: aplica esos estilos en vez de ocultar.
// stealth: en vez de quitar el elemento lo deja invisible con su tamaño, así
// un elemento cebo no delata al bloqueador (se usa con los selectores genéricos).
function cssFor(selectors, stealth = false) {
  const hide = stealth ? "opacity:0!important;pointer-events:none!important" : "display:none!important";
  return selectors
    .filter((selector) => !/[{}]|\/\*|[\r\n]/.test(selector))
    .map((selector) => {
      const [target, style] = selector.split("\u0000");
      if (!style) return `${target}{${hide}}`;
      return `${target}{${style.split(";").filter((part) => part.trim()).map((part) => `${part.replace(/!important/g, "")}!important`).join(";")}}`;
    })
    .join("\n");
}

// El host, sus dominios padre y las entidades de uBlock (ejemplo.*).
function hostAndParents(hostname) {
  const labels = hostname.split(".");
  const keys = [];
  for (let start = 0; start < labels.length - 1; start++) {
    keys.push(labels.slice(start).join("."));
    for (let end = Math.max(start + 1, labels.length - 2); end < labels.length; end++) {
      keys.push(`${labels.slice(start, end).join(".")}.*`);
    }
  }
  return keys;
}

async function cosmeticCss(hostname, categories, includeGeneric, stealth = false) {
  const key = `${hostname}|${categories.join(",")}|${includeGeneric}|${stealth}`;
  if (cosmeticCache.has(key)) return cosmeticCache.get(key);
  const data = await loadCosmeticData();
  const hosts = hostAndParents(hostname);
  const parts = [];
  for (const category of categories) {
    const entry = data[category];
    if (!entry) continue;
    const exceptions = new Set(hosts.flatMap((host) => entry.exceptions[host] || []));
    const matchesAny = (list) => hosts.some((host) => list.includes(host));
    if (includeGeneric && !matchesAny(entry.genericHide)) {
      parts.push(exceptions.size
        ? cssFor(entry.generic.filter((selector) => !exceptions.has(selector)), stealth)
        : stealth ? entry.stealthGenericCss : entry.genericCss);
    }
    if (!matchesAny(entry.specificHide)) {
      parts.push(cssFor(hosts.flatMap((host) => entry.specific[host] || [])
        .filter((selector) => !exceptions.has(selector))));
    }
  }
  const css = parts.filter(Boolean).join("\n");
  if (cosmeticCache.size >= COSMETIC_CACHE_LIMIT) cosmeticCache.delete(cosmeticCache.keys().next().value);
  cosmeticCache.set(key, css);
  return css;
}

async function cosmeticForFrame(message, sender) {
  const hostname = httpHostname(sender?.url || "");
  const settings = await readSettings();
  // Off y Básico no ocultan nada; el modo se mira en el marco y la pestaña.
  if (!hostname || !settings.protectionEnabled
      || ["off", "basic"].includes(siteModeForUrls([sender?.url, sender?.tab?.url], settings))) {
    return { css: "" };
  }
  const categories = Object.entries(COSMETIC_CATEGORIES)
    .filter(([setting]) => settings[setting])
    .flatMap(([, categories]) => categories);
  return { css: categories.length
    ? await cosmeticCss(hostname, categories, message.includeGeneric === true, settings.stealthMode) : "" };
}

async function stateForTab(url) {
  const settings = await readSettings();
  let hostname = null;
  let protocol = "";

  try {
    const parsed = new URL(url || "");
    hostname = parsed.hostname.toLowerCase();
    protocol = parsed.protocol;
  } catch {
    // Las páginas internas de Chrome no tienen un dominio utilizable.
  }

  return {
    settings,
    hostname,
    siteMode: siteModeFor([hostname], settings),
    whitelisted: isWhitelisted(hostname, settings.whitelist),
    supported: /^https?:$/.test(protocol)
  };
}

function nextLearnedRuleId(rules) {
  const highest = rules.reduce((current, rule) => (
    Number.isInteger(rule.id) && rule.id > current ? rule.id : current
  ), 0);
  return Math.max(highest + 1, 500000);
}

async function addLearnedRule(selector, sender, frameDomain = null) {
  const sourceHostname = httpHostname(sender?.tab?.url || sender?.url || "");
  const validated = ScutumADLearningPolicy.normalizeSelector(selector);
  const normalizedSelector = validated?.selector || "";
  if (!sourceHostname || !normalizedSelector || normalizedSelector.length > MAX_LEARNED_SELECTOR_LENGTH) {
    return { ok: false, error: "No se pudo identificar el sitio o el selector." };
  }
  if (/[{};<>]/.test(normalizedSelector) || /(?:javascript|data):/i.test(normalizedSelector)) {
    return { ok: false, error: "El selector no es seguro." };
  }
  if (validated.disabled) return { ok: false, error: "La selección es demasiado amplia o contiene contenido protegido." };

  const settings = await readSettings();
  if (isWhitelisted(sourceHostname, settings.whitelist)) {
    return { ok: false, error: "El sitio está en la lista blanca." };
  }

  const existing = settings.learnedRules.find((rule) => (
    rule.domain === sourceHostname && rule.selector === normalizedSelector && rule.frameDomain === (frameDomain || undefined)
  ));
  if (existing) {
    return { ok: true, duplicate: true, rule: existing, learnedRules: settings.learnedRules };
  }
  if (settings.learnedRules.length >= MAX_LEARNED_RULES) {
    return { ok: false, error: "Se ha alcanzado el límite local de reglas aprendidas." };
  }

  const rule = {
    id: nextLearnedRuleId(settings.learnedRules),
    domain: sourceHostname,
    selector: normalizedSelector,
    action: "hide",
    confidence: 1
  };
  if (frameDomain) rule.frameDomain = frameDomain;
  const learnedRules = [...settings.learnedRules, rule];
  await chrome.storage.local.set({ learnedRules });
  return { ok: true, rule, learnedRules };
}

async function removeLearnedRule(ruleId) {
  if (!Number.isInteger(ruleId)) {
    return { ok: false, error: "Regla no válida." };
  }
  const settings = await readSettings();
  const learnedRules = settings.learnedRules.filter((rule) => rule.id !== ruleId);
  await chrome.storage.local.set({ learnedRules });
  return { ok: true, learnedRules };
}

async function clearLearnedRules() {
  await chrome.storage.local.set({ learnedRules: [] });
  return { ok: true, learnedRules: [] };
}

async function popupLearningContext(tabId) {
  if (!Number.isInteger(tabId)) return { available: false };
  try {
    const tab = await chrome.tabs.get(tabId);
    const openerId = tab.openerTabId ?? ScutumADPopupFirewall.learningSourceFor(tabId);
    if (!Number.isInteger(openerId)) return { available: false };
    const source = await chrome.tabs.get(openerId);
    const domain = httpHostname(source.url), destinationDomain = httpHostname(tab.url);
    const settings = await readSettings();
    if (!domain || !destinationDomain || domain === destinationDomain
      || ScutumADPopupPolicy.isTrustedDestination(tab.url, source.url)
      || isWhitelisted(domain, settings.whitelist) || !settings.protectionEnabled) return { available: false };
    return { available: true, domain, destinationDomain };
  } catch { return { available: false }; }
}

async function learnPopupPage(tabId) {
  const settings = await readSettings();
  const context = await popupLearningContext(tabId);
  if (!settings.learningEnabled || !context.available) {
    return { ok: false, error: "No se puede identificar la página de origen. Abre el anuncio desde esa página y vuelve a marcarlo." };
  }
  const existing = settings.learnedRules.find(rule => rule.action === "block-popup"
    && rule.domain === context.domain && rule.destinationDomain === context.destinationDomain);
  if (existing) {
    await chrome.tabs.remove(tabId).catch(() => {});
    return { ok: true, duplicate: true, rule: existing };
  }
  if (settings.learnedRules.length >= MAX_LEARNED_RULES) return { ok: false, error: "Se ha alcanzado el límite de reglas locales." };
  const rule = { id: nextLearnedRuleId(settings.learnedRules), domain: context.domain,
    destinationDomain: context.destinationDomain, action: "block-popup", confidence: 1 };
  await chrome.storage.local.set({ learnedRules: [...settings.learnedRules, rule] });
  await chrome.tabs.remove(tabId).catch(() => {});
  return { ok: true, rule };
}

async function updateSettings(patch) {
  const current = await readSettings();
  const next = { ...current };

  if (typeof patch.protectionEnabled === "boolean") next.protectionEnabled = patch.protectionEnabled;
  if (typeof patch.blockAds === "boolean") next.blockAds = patch.blockAds;
  if (typeof patch.blockTrackers === "boolean") next.blockTrackers = patch.blockTrackers;
  if (typeof patch.youtubeProtection === "boolean") next.youtubeProtection = patch.youtubeProtection;
  if (typeof patch.blockAnnoyances === "boolean") next.blockAnnoyances = patch.blockAnnoyances;
  if (typeof patch.blockMalware === "boolean") next.blockMalware = patch.blockMalware;
  if (typeof patch.learningEnabled === "boolean") next.learningEnabled = patch.learningEnabled;
  if (typeof patch.autoUpdateLists === "boolean") next.autoUpdateLists = patch.autoUpdateLists;
  if (typeof patch.autoUpdateApp === "boolean") next.autoUpdateApp = patch.autoUpdateApp;
  if (typeof patch.stealthMode === "boolean") next.stealthMode = patch.stealthMode;
  if (patch.siteModes && typeof patch.siteModes === "object") {
    next.siteModes = normalizeSiteModes(patch.siteModes);
  }
  if (Array.isArray(patch.whitelist)) {
    next.whitelist = [...new Set(
      patch.whitelist.map(normalizeDomain).filter(Boolean)
    )].slice(0, MAX_WHITELIST_ENTRIES);
  }

  await chrome.storage.local.set(next);
  await queueRulesSync();
  return next;
}

// Cambia el modo de un dominio de forma atómica: lista blanca y siteModes.
// Se borran también las entradas de dominios padre que afecten al sitio
// abierto, para que el modo elegido sea el que de verdad se aplica.
async function setSiteMode(domainValue, mode, hostnameValue = domainValue) {
  const domain = normalizeDomain(domainValue);
  const hostname = normalizeDomain(hostnameValue) || domain;
  if (!domain || !SITE_MODES.includes(mode)) return { ok: false, error: "Sitio o modo no válido." };
  const current = await readSettings();
  const affects = (entry) => entry === domain || hostname === entry || hostname.endsWith(`.${entry}`);
  const whitelist = current.whitelist.filter((entry) => !affects(entry));
  const siteModes = Object.fromEntries(Object.entries(current.siteModes).filter(([entry]) => !affects(entry)));
  if (mode === "off") whitelist.push(domain);
  if (mode === "basic" || mode === "strict") siteModes[domain] = mode;
  const settings = await updateSettings({ whitelist, siteModes });
  return { ok: true, settings };
}

async function exportSettings() {
  const settings = await readSettings();
  return {
    ok: true,
    data: {
      format: "scutumad-settings",
      version: chrome.runtime.getManifest().version,
      settings
    }
  };
}

async function importSettings(data) {
  const imported = data?.format === "scutumad-settings" ? data.settings : null;
  if (!imported || typeof imported !== "object") {
    return { ok: false, error: "El archivo no es una copia de ajustes de ScutumAD." };
  }
  // Las reglas importadas reciben identificadores nuevos y pasan la misma
  // validación que las que se aprenden en el navegador.
  const learnedRules = normalizeLearnedRules(imported.learnedRules)
    .map((rule, index) => ({ ...rule, id: 500000 + index }));
  await chrome.storage.local.set({ learnedRules });
  const settings = await updateSettings(imported);
  return { ok: true, settings: { ...settings, learnedRules } };
}

// Solo las páginas propias de la extensión (popup, configuración y el
// documento offscreen) pueden cambiar ajustes. Los content scripts se
// ejecutan dentro de webs ajenas y quedan limitados a sus mensajes.
// Un content script siempre tiene la URL de la web en sender.url; las
// páginas propias (también Configuración abierta en una pestaña) tienen la
// URL de la extensión.
function isExtensionPage(sender) {
  return sender?.id === chrome.runtime.id
    && typeof sender.url === "string" && sender.url.startsWith(chrome.runtime.getURL(""));
}
const EXTENSION_PAGE_MESSAGES = new Set([
  "UPDATE_SETTINGS", "SET_SITE_MODE", "LEARN_POPUP_PAGE", "REMOVE_LEARNED_RULE", "CLEAR_LEARNED_RULES",
  "APPLY_THEME_ICON", "EXPORT_SETTINGS", "IMPORT_SETTINGS", "LISTS_STATUS", "UPDATE_LISTS", "USE_BUNDLED_LISTS",
  "APP_UPDATE_STATUS", "APP_UPDATE_CHECK", "APP_UPDATE_APPLY", "APP_UPDATE_ROLLBACK"
]);

chrome.runtime.onInstalled.addListener(() => {
  queueSettingsMutation(ensureDefaults).then(queueRulesSync).catch(() => {});
  ScutumADUpdater.scheduleUpdates();
  ScutumADAppUpdater.scheduleChecks();
  ensureThemeDocument().catch(() => {});
  Promise.resolve(showBlockedCount()).catch(() => {});
});

chrome.runtime.onStartup.addListener(() => {
  queueSettingsMutation(ensureDefaults).then(queueRulesSync).catch(() => {});
  ScutumADUpdater.scheduleUpdates();
  ScutumADAppUpdater.scheduleChecks();
  ensureThemeDocument().catch(() => {});
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "local") {
    return;
  }

  // Solo estas claves afectan a las reglas de red y a los scriptlets.
  if ([
    "protectionEnabled",
    "blockAds",
    "blockTrackers",
    "blockAnnoyances",
    "blockMalware",
    "stealthMode",
    "whitelist",
    "siteModes"
  ].some((key) => key in changes)) {
    queueRulesSync().catch(() => {});
  }
});

importScripts("popup-firewall.js", "learning-coordinator.js", "app-updater.js");

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    if (EXTENSION_PAGE_MESSAGES.has(message?.type) && !isExtensionPage(sender)) {
      return { ok: false, error: "Mensaje no permitido" };
    }
    switch (message?.type) {
      case "GET_COSMETIC":
        return cosmeticForFrame(message, sender);

      case "POPUP_LINK_INTENT":
        return ScutumADPopupFirewall.rememberIntent(message, sender);

      case "GET_STATE":
        return { ...await stateForTab(message.url), popupLearning: await popupLearningContext(message.tabId) };

      case "UPDATE_SETTINGS":
        return { settings: await queueSettingsMutation(() => updateSettings(message.patch || {})) };

      case "LEARN_RULE":
        if (message.selectionToken) return ScutumADLearningCoordinator.confirm(message, sender);
        return queueSettingsMutation(() => addLearnedRule(message.selector, sender));

      case "LEARNING_PICKER":
        return ScutumADLearningCoordinator.picker(message, sender);

      case "LEARNING_SELECTED":
        return ScutumADLearningCoordinator.selected(message, sender);

      case "LEARNING_GUIDE_UPDATE":
        return ScutumADLearningCoordinator.guide(message, sender);

      case "LEARN_POPUP_PAGE":
        return queueSettingsMutation(() => learnPopupPage(message.tabId));

      case "REMOVE_LEARNED_RULE":
        return queueSettingsMutation(() => removeLearnedRule(message.ruleId));

      case "CLEAR_LEARNED_RULES":
        return queueSettingsMutation(clearLearnedRules);

      case "SET_SITE_MODE":
        return queueSettingsMutation(() => setSiteMode(message.domain, message.mode, message.hostname));

      case "LISTS_STATUS":
        return { ok: true, meta: await ScutumADUpdater.meta(), userScripts: await userScriptsAvailable(),
          bundled: await fetch(chrome.runtime.getURL("rules/version.json")).then((response) => response.json()).catch(() => null) };

      case "UPDATE_LISTS":
        return { ok: true, meta: await ScutumADUpdater.updateFilterLists({ force: true }) };

      case "USE_BUNDLED_LISTS":
        return { ok: true, meta: await ScutumADUpdater.useBundledLists() };

      case "APP_UPDATE_STATUS":
        return { ok: true, update: await ScutumADAppUpdater.status() };

      case "APP_UPDATE_CHECK":
        return { ok: true, update: await ScutumADAppUpdater.check({ manual: true }) };

      case "APP_UPDATE_APPLY":
        return { ok: true, update: await ScutumADAppUpdater.apply() };

      case "APP_UPDATE_ROLLBACK":
        return { ok: true, update: await ScutumADAppUpdater.rollback() };

      case "EXPORT_SETTINGS":
        return exportSettings();

      case "IMPORT_SETTINGS":
        return queueSettingsMutation(() => importSettings(message.data));

      case "APPLY_THEME_ICON":
        await applyThemeIcon(message.iconPixels);
        return { ok: true };

      default:
        return { ok: false, error: "Mensaje no reconocido" };
    }
  })()
    .then((result) => sendResponse(result))
    .catch((error) => sendResponse({
      ok: false,
      error: error instanceof Error ? error.message : "Error interno"
    }));

  return true;
});

queueSettingsMutation(ensureDefaults).then(queueRulesSync).catch(() => {});
ensureThemeDocument().catch(() => {});
Promise.resolve(showBlockedCount()).catch(() => {});
