(() => {
  "use strict";

  // YouTube detecta que un anuncio se acelera o se salta, y entonces bloquea
  // el vídeo o avisa del bloqueador. Por eso los anuncios se quitan antes de
  // que existan: se borran de los datos que recibe el reproductor
  // (adPlacements, adSlots, playerAds) y las peticiones del reproductor se
  // identifican como de un anuncio, para las que YouTube no sirve publicidad.
  // Solo se borran o cambian datos; no se descarga ni se ejecuta código.
  const AD_KEYS = ["adPlacements", "adSlots", "playerAds"];
  const AD_RESPONSE_URL = /playlist\?list=|\/player(?!.*get_drm_license)|watch\?[tv]=|get_watch\?/;
  const AD_BREAK_URL = /\/youtubei\/v1\/player\/ad_break/;
  const SKIP_SELECTOR = [
    ".ytp-ad-skip-button",
    ".ytp-ad-skip-button-modern",
    ".ytp-skip-ad-button",
    "button.ytp-ad-skip-button",
    "button[class*='ytp-ad-skip-button']"
  ].join(",");
  const GUARD_DELAY = 90;
  const GUARD_INTERVAL = 750;
  const defineProperty = Object.defineProperty;
  const apply = Reflect.apply;
  const nativeParse = JSON.parse;
  const nativeStringify = JSON.stringify;
  let enabled = true;

  // El estado llega por un MessagePort entregado por el content script antes
  // de que se ejecute la página. Un evento del DOM lo podría falsificar la
  // propia web para desactivar la protección.
  function connectBridge(name, onMessage) {
    const listener = (event) => {
      if (event.source !== window || event.data?.scutumadBridge !== name || !event.ports?.[0]) return;
      event.stopImmediatePropagation();
      window.removeEventListener("message", listener, true);
      event.ports[0].onmessage = (message) => onMessage(message.data);
    };
    window.addEventListener("message", listener, true);
  }

  const isObject = (value) => value !== null && typeof value === "object";

  // Borra los anuncios de una respuesta del reproductor (o de su playerResponse).
  function stripAds(data, keys = AD_KEYS) {
    if (!isObject(data)) return data;
    for (const target of [data, data.playerResponse]) {
      if (!isObject(target)) continue;
      for (const key of keys) delete target[key];
    }
    return data;
  }

  // Shorts: quita las entradas que son anuncios.
  function stripShortsAds(data) {
    if (Array.isArray(data?.entries)) {
      for (let index = data.entries.length - 1; index >= 0; index--) {
        if (isObject(data.entries[index]?.command?.reelWatchEndpoint?.adClientParams)
            && "isAd" in data.entries[index].command.reelWatchEndpoint.adClientParams) {
          data.entries.splice(index, 1);
        }
      }
    }
    return data;
  }

  // Llama a edit(valor) cada vez que la página asigna owner[key].
  function onAssign(owner, key, edit) {
    let current = owner[key];
    if (isObject(current)) edit(current);
    try {
      defineProperty(owner, key, {
        configurable: true,
        enumerable: true,
        get: () => current,
        set: (next) => {
          current = next;
          if (isObject(next)) edit(next);
        }
      });
    } catch {}
  }

  // Fija el valor de owner.a.b.c aunque la página cree los objetos más tarde.
  function forceValue(owner, path, value) {
    const [key, ...rest] = path;
    if (rest.length) {
      onAssign(owner, key, (next) => forceValue(next, rest, value));
      return;
    }
    let current = owner[key];
    try {
      defineProperty(owner, key, {
        configurable: true,
        enumerable: true,
        get: () => (enabled ? value : current),
        set: (next) => { current = next; }
      });
    } catch {}
  }

  function editJsonText(text) {
    try {
      const data = nativeParse(text);
      if (!isObject(data) || !AD_KEYS.some((key) => key in data || (isObject(data.playerResponse) && key in data.playerResponse))) return text;
      return nativeStringify(stripAds(data));
    } catch {
      return text;
    }
  }

  // La petición del reproductor se presenta como de un anuncio: YouTube no
  // inserta publicidad en ella.
  function asAdUnit(text) {
    return text
      .split('"clientScreen":"WATCH"').join('"clientScreen":"ADUNIT"')
      .split('isWebNativeShareAvailable":true}}').join('isWebNativeShareAvailable":true},"clientScreen":"ADUNIT"}');
  }

  // Cuando YouTube detecta el bloqueador con una cuenta iniciada, responde al
  // reproductor con "UNPLAYABLE" (el aviso de pagar Premium) y el vídeo no
  // carga. Hay varias formas de pedir el vídeo que YouTube sirve sin anuncios;
  // se prueba la primera y, si YouTube la rechaza, la siguiente.
  const MODES = ["param_first", "param_second", "pyv", "client_screen", "ad_type", "none"];
  const PARAM_FIRST = "eAFgAQ";
  const PARAM_SECOND = "8AUB";
  const BLOCKED_STATUS = ["LOGIN_REQUIRED", "CONTENT_CHECK_REQUIRED"];
  const pageUrl = () => String(window.location?.href || "");
  const skipsRequestEdits = () => /\/shorts\/|youtube\.com\/(?:tv|embed\/)/.test(pageUrl());
  const player = () => window.document?.getElementById?.("movie_player");
  const playerStatus = () => {
    try { return player()?.getPlayerResponse?.()?.playabilityStatus?.status; } catch { return undefined; }
  };

  function forceVisible() {
    try { defineProperty(window.document, "visibilityState", { configurable: true, get: () => "visible" }); } catch {}
  }

  function restoreVisible() {
    try { delete window.document.visibilityState; } catch {}
  }

  // Cada canal de petición (fetch y XMLHttpRequest) recuerda su propia forma.
  function createModeState() {
    return { index: 0, videoId: null };
  }
  const fetchMode = createModeState();
  const xhrMode = createModeState();

  // Cambia la petición del reproductor según la forma actual (body es el
  // objeto completo; playback, su playbackContext).
  function editPlayerRequest(body, playback, state) {
    if (!isObject(body) || !isObject(playback)) return;
    const videoId = body.videoId;
    if (videoId) {
      if (state.videoId && state.videoId !== videoId) state.index = 0;
      state.videoId = videoId;
    }
    const mode = BLOCKED_STATUS.includes(playerStatus()) ? "none" : MODES[state.index];
    const client = body.context?.client;
    const onChannel = client?.clientScreen === "CHANNEL";
    const touch = (visible = true) => {
      if (isObject(playback.contentPlaybackContext)) playback.contentPlaybackContext.lactMilliseconds = String(Date.now());
      if (visible) forceVisible();
      if (isObject(client?.configInfo)) delete client.configInfo.appInstallData;
    };
    const setParams = (value) => {
      body.params = value;
      if (isObject(body.playerRequest)) body.playerRequest.params = value;
      if (isObject(body.playbackContext)) body.playbackContext.params = value;
    };
    const ownParams = typeof body.params === "string" && body.params.startsWith("YAHI");
    if (mode === "param_first" && !onChannel && !ownParams) {
      setParams(PARAM_FIRST);
      touch();
    } else if (mode === "param_second" && !onChannel && !ownParams) {
      setParams(PARAM_SECOND);
      if (!body.playlistId && client) client.clientScreen = "CHANNEL";
      touch();
    } else if (mode === "pyv" && !onChannel) {
      playback.adPlaybackContext = { pyv: true };
      touch(false);
    } else if (mode === "client_screen" && client?.clientName === "WEB") {
      client.clientScreen = "CHANNEL";
      touch();
    } else if (mode === "ad_type") {
      playback.adPlaybackContext = { adType: "AD_TYPE_INSTREAM" };
      touch();
    } else if (mode === "none") {
      delete playback.adPlaybackContext;
      restoreVisible();
    }
  }

  function editPlayerBody(body, state) {
    if (!isObject(body?.context?.client)) return false;
    if (body.playbackContext) editPlayerRequest(body, body.playbackContext, state);
    if (body.playerRequest) editPlayerRequest(body, body.playerRequest.playbackContext, state);
    return true;
  }

  const isPlayerBodyText = (text) => typeof text === "string"
    && (text.includes('"contentPlaybackContext"') || text.includes('"adSignalsInfo"'));

  // Versión en texto: para cuerpos que ya llegan convertidos a JSON.
  function editPlayerText(text, state) {
    if (!enabled || skipsRequestEdits() || !isPlayerBodyText(text)) return text;
    try {
      const body = nativeParse(text);
      return editPlayerBody(body, state) ? asAdUnit(nativeStringify(body)) : text;
    } catch {
      return text;
    }
  }

  // Lo que responde YouTube: si rechaza la forma actual, se pasa a la siguiente.
  function checkPlayerResponse(data) {
    if (skipsRequestEdits() || MODES[fetchMode.index] === "none") return;
    if (!data.responseContext && !data.playabilityStatus) return;
    let text = "";
    try { text = nativeStringify(data); } catch {}
    if ((text.includes("playerErrorMessageRenderer") || text.includes("UNPLAYABLE")) && !text.includes("CONTENT_CHECK_REQUIRED")) {
      fetchMode.index = Math.min(fetchMode.index + 1, MODES.length - 1);
      return;
    }
    if (MODES[fetchMode.index] === "param_first") unmuteStart(data);
  }

  // Con estas formas YouTube a veces arranca el vídeo en silencio o pregunta
  // «¿sigues ahí?»: se quitan.
  function unmuteStart(data) {
    if (!data.playerConfig?.audioConfig?.muteOnStart) return;
    if (!pageUrl().includes("/watch") && !(data.cards && !data.playabilityStatus?.miniplayer)) return;
    delete data.playerConfig.audioConfig.muteOnStart;
    if (data.messages?.[0]?.youThereRenderer) delete data.messages[0].youThereRenderer;
  }

  function hookJson() {
    JSON.parse = new Proxy(nativeParse, {
      apply(target, thisArg, args) {
        const data = apply(target, thisArg, args);
        if (!enabled || !isObject(data)) return data;
        try { checkPlayerResponse(data); } catch {}
        // Con streaming SABR, la respuesta trae su propia URL y sus anuncios.
        if (data.playerResponse?.streamingData?.serverAbrStreamingUrl) stripAds(data, ["adPlacements", "adSlots"]);
        return stripShortsAds(data);
      }
    });
    JSON.stringify = new Proxy(nativeStringify, {
      apply(target, thisArg, args) {
        if (enabled && !skipsRequestEdits()) {
          const body = args[0];
          try {
            if (isObject(body?.context?.client)) {
              if (isObject(body.playbackContext) && body.playbackContext.adPlaybackContext === undefined) editPlayerRequest(body, body.playbackContext, fetchMode);
              const nested = body.playerRequest?.playbackContext;
              if (isObject(nested) && nested.adPlaybackContext === undefined) editPlayerRequest(body, nested, fetchMode);
            }
          } catch {}
        }
        const text = apply(target, thisArg, args);
        return enabled && typeof text === "string" ? asAdUnit(text) : text;
      }
    });
  }

  // Los mismos cambios por las otras vías por las que sale la petición.
  function hookRequestBodies() {
    if (typeof TextEncoder === "function") {
      TextEncoder.prototype.encode = new Proxy(TextEncoder.prototype.encode, {
        apply(target, thisArg, args) {
          if (typeof args[0] === "string") args[0] = editPlayerText(args[0], fetchMode);
          return apply(target, thisArg, args);
        }
      });
    }
    if (typeof Request === "function") {
      window.Request = new Proxy(Request, {
        construct(target, args, newTarget) {
          const init = args[1];
          if (String(args[0]).includes("youtubei") && typeof init?.body === "string") {
            const edited = editPlayerText(init.body, fetchMode);
            if (edited !== init.body) args[1] = { ...init, body: edited };
          }
          return Reflect.construct(target, args, newTarget);
        }
      });
    }
    if (typeof XMLHttpRequest === "function") {
      const proto = XMLHttpRequest.prototype;
      proto.send = new Proxy(proto.send, {
        apply(target, thisArg, args) {
          if (!/youtube\.com\/tv|youtube\.com\/embed\//.test(pageUrl())) {
            const list = Array.isArray(args[0]);
            const text = list ? args[0][0] : args[0];
            if (isPlayerBodyText(text)) {
              try {
                const body = nativeParse(text);
                if (enabled && editPlayerBody(body, xhrMode)) {
                  const edited = asAdUnit(nativeStringify(body));
                  if (list) args[0][0] = edited; else args[0] = edited;
                }
              } catch {}
            }
          }
          return apply(target, thisArg, args);
        }
      });
    }
  }

  // Si aun así aparece la pantalla de error, se oculta y se vuelve a pedir el
  // vídeo (en el mismo punto). Al segundo fallo seguido se cambia de forma.
  function beginErrorRecovery() {
    const ERROR_SCREEN = "yt-playability-error-supported-renderers#error-screen:has(>*)";
    const MINI_ERROR = "yt-playability-error-supported-renderers.ytdMiniplayerPlayerContainerPlayabilityError:has(>*)";
    const UNAVAILABLE = "ytd-watch-flexy[player-unavailable]";
    const PLAYER_ERROR = "#movie_player > .ytp-error";
    // El enlace de «vídeo no disponible en tu país» o similar: no es el bloqueador.
    const REAL_ERROR = 'yt-playability-error-supported-renderers#error-screen a[href^="//support.google.com/youtube/answer/2802245"]';
    const doc = window.document;
    const query = (selector) => { try { return doc.querySelector(selector); } catch { return null; } };
    const retried = new Set();
    let repeat = { videoId: null, mode: null, count: 0 };

    const currentVideo = () => {
      const params = new URLSearchParams(window.location?.search || "");
      let videoId = params.get("v");
      try { videoId ||= player()?.getVideoData?.()?.video_id; } catch {}
      return { videoId, time: parseInt(params.get("t") ?? "0", 10) || 0 };
    };

    const hideError = () => {
      if (!player() || query(REAL_ERROR)) return;
      const screen = query(ERROR_SCREEN);
      if (BLOCKED_STATUS.includes(playerStatus())) {
        screen?.style.setProperty("display", "block", "important");
        return;
      }
      const mini = query(MINI_ERROR);
      const unavailable = query(UNAVAILABLE);
      if (unavailable || mini) {
        screen?.style.setProperty("display", "none", "important");
        mini?.style.setProperty("display", "none", "important");
        unavailable?.removeAttribute("player-unavailable");
      }
    };

    const reload = () => {
      hideError();
      const movie = player();
      if (typeof movie?.loadVideoById !== "function") return;
      try {
        const { videoId, time } = currentVideo();
        movie.loadVideoById(videoId, time);
      } catch {}
    };

    // true la segunda vez seguida que el mismo vídeo falla con la misma forma.
    const failedTwice = (next) => {
      const { videoId } = currentVideo();
      if (!videoId) return false;
      if (repeat.videoId === videoId && repeat.mode === next) repeat.count++;
      else repeat = { videoId, mode: next, count: 1 };
      if (repeat.count < 2) return false;
      repeat.count = 0;
      return true;
    };

    const hasPlayerError = () => {
      const movie = player();
      if (!movie || query(REAL_ERROR) || BLOCKED_STATUS.includes(playerStatus())) return false;
      if (!query(ERROR_SCREEN) && !query(UNAVAILABLE) && !query(PLAYER_ERROR)) return false;
      try { return movie.getVideoData?.()?.errorCode != null; } catch { return false; }
    };

    const onChange = () => {
      if (!enabled) return;
      if (query(ERROR_SCREEN)) hideError();
      if (!hasPlayerError()) return;
      const { videoId } = currentVideo();
      for (const id of retried) if (id !== videoId) retried.delete(id);
      if (MODES[xhrMode.index] === "none") {
        if (!videoId || retried.has(videoId)) { hideError(); return; }
        retried.add(videoId);
        reload();
        return;
      }
      const next = MODES[xhrMode.index + 1];
      if (failedTwice(next)) xhrMode.index++;
      reload();
    };

    const start = () => new MutationObserver(onChange).observe(doc.documentElement, { attributes: true, childList: true, subtree: true });
    if (doc.documentElement) start();
    else doc.addEventListener("readystatechange", start, { once: true });
  }

  // Promesas del reproductor: se anula su detector de «comportamiento
  // anómalo» y se quitan anuncios de las respuestas que llegan por partes.
  function hookPromises() {
    const kinds = new WeakMap();
    const kindOf = (callback) => {
      if (kinds.has(callback)) return kinds.get(callback);
      let code = "";
      try { code = Function.prototype.toString.call(callback); } catch {}
      const kind = code.includes("onAbnormalityDetected") ? "abnormal"
        : code.includes("jspbResponseCtor") ? "jspb"
        : code.includes(".next(") ? "stream" : "";
      kinds.set(callback, kind);
      return kind;
    };
    const cleanStream = (chunk) => {
      if (typeof chunk?.value !== "string" || !chunk.value.includes("playerResponse")) return;
      let text = chunk.value;
      if ((pageUrl().includes("/watch") || (text.includes("cards") && !text.includes('"miniplayer"'))) && text.includes('"muteOnStart":true')) {
        text = text.replace('"muteOnStart":true', '"muteOnStart":false').replace('"youThereRenderer":', '"no_youThereRenderer":');
      }
      chunk.value = text.replace(/"(adSlots|playerAds)":/g, '"no_ads":');
    };
    const wrap = (callback, kind) => {
      if (kind === "abnormal") return function () {};
      if (kind === "stream") {
        return new Proxy(callback, {
          apply(target, thisArg, args) {
            if (enabled) try { cleanStream(args[0]); } catch {}
            return apply(target, thisArg, args);
          }
        });
      }
      return new Proxy(callback, {
        apply(target, thisArg, args) {
          const result = apply(target, thisArg, args);
          if (enabled && result?.responseContext) {
            try {
              delete result.adSlots;
              delete result.playerAds;
              unmuteStart(result);
            } catch {}
          }
          return result;
        }
      });
    };
    Promise.prototype.then = new Proxy(Promise.prototype.then, {
      apply(target, thisArg, args) {
        if (enabled && typeof args[0] === "function") {
          const kind = kindOf(args[0]);
          if (kind) args[0] = wrap(args[0], kind);
        }
        return apply(target, thisArg, args);
      }
    });
  }

  // Los marcos vacíos que crea la página reciben el fetch protegido, para que
  // no se use uno sin filtrar.
  function hookFrames() {
    if (typeof Node !== "function" || typeof HTMLIFrameElement !== "function") return;
    Node.prototype.appendChild = new Proxy(Node.prototype.appendChild, {
      apply(target, thisArg, args) {
        const result = apply(target, thisArg, args);
        try {
          if (result instanceof HTMLIFrameElement && result.src === "about:blank" && result.contentWindow) {
            result.contentWindow.fetch = window.fetch;
            result.contentWindow.Request = window.Request;
          }
        } catch {}
        return result;
      }
    });
  }

  function hookFetch() {
    if (typeof window.fetch !== "function") return;
    window.fetch = new Proxy(window.fetch, {
      apply(target, thisArg, args) {
        const resource = args[0];
        const url = String(typeof Request === "function" && resource instanceof Request ? resource.url : resource);
        if (enabled && AD_BREAK_URL.test(url)) return Promise.reject(new TypeError("Failed to fetch"));
        const result = apply(target, thisArg, args);
        if (!enabled || !AD_RESPONSE_URL.test(url)) return result;
        return result.then((response) => response.clone().text().then((text) => {
          const edited = editJsonText(text);
          if (edited === text) return response;
          const clean = new Response(edited, { status: response.status, statusText: response.statusText, headers: response.headers });
          try {
            defineProperty(clean, "url", { value: response.url });
            defineProperty(clean, "redirected", { value: response.redirected });
            defineProperty(clean, "type", { value: response.type });
          } catch {}
          return clean;
        }).catch(() => response));
      }
    });
  }

  function hookXhr() {
    if (typeof XMLHttpRequest !== "function") return;
    const proto = XMLHttpRequest.prototype;
    const urls = new WeakMap();
    const cache = new WeakMap();
    const open = proto.open;
    proto.open = new Proxy(open, {
      apply(target, thisArg, args) {
        urls.set(thisArg, String(args[1]));
        return apply(target, thisArg, args);
      }
    });
    for (const name of ["response", "responseText"]) {
      const descriptor = Object.getOwnPropertyDescriptor(proto, name);
      if (!descriptor?.get) continue;
      defineProperty(proto, name, {
        ...descriptor,
        get() {
          const value = apply(descriptor.get, this, []);
          if (!enabled || this.readyState !== 4 || typeof value !== "string" || !AD_RESPONSE_URL.test(urls.get(this) || "")) return value;
          const cached = cache.get(this);
          if (cached?.source === value) return cached.result;
          const result = editJsonText(value);
          cache.set(this, { source: value, result });
          return result;
        }
      });
    }
  }

  // Temporizadores con los que YouTube retrasa el vídeo si cree que hay bloqueador.
  function hookTimers() {
    window.setTimeout = new Proxy(window.setTimeout, {
      apply(target, thisArg, args) {
        const [callback, delay] = args;
        if (enabled && typeof callback === "function") {
          const code = String(callback);
          if (Number(delay) === 17000 && code.includes("[native code]")) {
            return apply(target, thisArg, [callback, 17, ...args.slice(2)]);
          }
          if (Number(delay) === 5000 && code.includes("(),a,b)")) return 0;
        }
        return apply(target, thisArg, args);
      }
    });
  }

  function installShield() {
    onAssign(window, "ytInitialPlayerResponse", (data) => enabled && stripAds(data));
    onAssign(window, "playerResponse", (data) => enabled && stripAds(data, ["adPlacements"]));
    forceValue(window, ["google_ad_status"], 1);
    forceValue(window, ["ytcfg", "data_", "EXPERIMENT_FLAGS", "web_streaming_watch"], false);
    hookJson();
    hookRequestBodies();
    hookFetch();
    hookXhr();
    hookTimers();
    hookPromises();
    hookFrames();
    beginErrorRecovery();
  }

  // Respaldo: si aun así aparece un anuncio con botón de saltar, se pulsa.
  // No se acelera ni se adelanta el vídeo: YouTube lo detecta.
  function skipCurrentAd() {
    if (!enabled) return;
    const player = document.querySelector("#movie_player, .html5-video-player");
    if (!player?.classList.contains("ad-showing")) return;
    player.querySelectorAll(SKIP_SELECTOR).forEach((button) => {
      if (button instanceof HTMLElement && !button.hidden && button.getClientRects().length > 0) {
        try {
          button.click();
        } catch {
          // El botón puede desaparecer durante la navegación interna.
        }
      }
    });
  }

  function beginPlayerGuard() {
    let guardTimer = null;
    const scheduleGuard = () => {
      if (guardTimer) {
        return;
      }
      guardTimer = window.setTimeout(() => {
        guardTimer = null;
        skipCurrentAd();
      }, GUARD_DELAY);
    };

    const mutationNeedsGuard = (record) => {
      const target = record.target instanceof Element ? record.target : null;
      if (target?.closest?.("#movie_player, .html5-video-player")) {
        return true;
      }
      return [...record.addedNodes].some((node) => {
        if (!(node instanceof Element)) {
          return false;
        }
        try {
          return node.matches("#movie_player, .html5-video-player, " + SKIP_SELECTOR)
            || Boolean(node.closest("#movie_player, .html5-video-player"));
        } catch {
          return false;
        }
      });
    };

    const startObserver = () => {
      const root = document.documentElement || document;
      const observer = new MutationObserver((records) => {
        if (records.some(mutationNeedsGuard)) {
          scheduleGuard();
        }
      });
      observer.observe(root, {
        attributes: true,
        attributeFilter: ["class", "hidden", "aria-label"],
        childList: true,
        subtree: true
      });
      scheduleGuard();
      // Respaldo limitado al reproductor activo para variantes que no
      // notifican sus cambios de clase.
      window.setInterval(scheduleGuard, GUARD_INTERVAL);
    };

    if (document.documentElement) {
      startObserver();
    } else {
      document.addEventListener("readystatechange", startObserver, { once: true });
    }
  }

  connectBridge("youtube", (message) => {
    if (message?.type !== "state") return;
    enabled = message.enabled !== false;
    skipCurrentAd();
  });

  installShield();
  beginPlayerGuard();
})();
