# Privacidad de ScutumAD 3.0.5

ScutumAD bloquea en tu navegador y no recopila datos tuyos.

## Lo que ScutumAD no hace

- No guarda ni envía historial, URLs visitadas, búsquedas ni contenido de páginas.
- No guarda ni envía nombres, correos, identificadores, cookies ni otros datos personales.
- No registra estadísticas de uso ni anuncios bloqueados.
- No tiene telemetría, analítica, publicidad, cuentas ni sincronización en la nube.
- No descarga ni ejecuta código remoto.

## Conexión 1: actualizar las listas de filtros

Con **Actualizar automáticamente** activado (Configuración → Listas de filtros), cada 6 horas ScutumAD descarga los archivos de texto de las listas de filtros desde sus webs oficiales: `easylist.to`, `easylist-downloads.adblockplus.org`, `secure.fanboy.co.nz`, `ublockorigin.github.io` y `malware-filter.gitlab.io`.

- Son descargas anónimas de un archivo público: **sin cookies, sin referer, sin parámetros y sin ningún dato tuyo, de tus ajustes ni de tu navegación**.
- Como al descargar cualquier archivo, esas webs pueden ver tu dirección IP y que la petición viene de Chrome. Nada más.
- Las listas son datos (reglas de filtrado), no código. ScutumAD las compila en tu navegador y las guarda en su almacenamiento local.
- Puedes desactivarlo: entonces ScutumAD no se conecta a nada y usa las últimas listas descargadas o las incluidas en la versión.

## Conexión 2: actualizar ScutumAD (solo con el actualizador instalado)

Si instalas el actualizador de ScutumAD, cada 6 horas ese pequeño programa local consulta `raw.githubusercontent.com/tocaway/ScutumAD-releases` para saber si hay una versión nueva, y la descarga si la instalas (o si activaste **Instalar las actualizaciones automáticamente**).

- La extensión no se conecta: se lo pide al actualizador, que hace una descarga anónima **sin cookies, sin cuenta y sin ningún dato tuyo**. GitHub puede ver tu dirección IP, como con cualquier descarga.
- El actualizador solo instala versiones **firmadas** con la clave de ScutumAD y con el mismo identificador de extensión; si algo no coincide, no toca nada.
- Sin el actualizador, ScutumAD no hace esta conexión.

## Datos guardados en tu equipo

- En `chrome.storage.local`: el estado de las actualizaciones (versión instalada y la última publicada), los interruptores, los modos por sitio, la lista de sitios desactivados y las reglas de aprendizaje que confirmas. Una regla aprendida contiene el dominio y un selector CSS, o los dominios de origen y destino de una página publicitaria.
- En el almacenamiento interno de la extensión (IndexedDB): las listas descargadas y su versión compilada.
- La exportación de ajustes crea un archivo JSON solo cuando lo pides, y lo guarda donde elijas.

## Procesamiento en el navegador

- El bloqueo de red lo hace Chrome con reglas `declarativeNetRequest`: ScutumAD no ve el contenido de las peticiones.
- El contador del icono lo calcula Chrome en memoria para cada pestaña; ScutumAD no lo lee ni lo guarda.
- El cortafuegos de pop-ups mira en memoria el origen y el destino de una ventana nueva. Los datos caducan en segundos (diez minutos para los IDs de pestaña con el aprendizaje activo) y no se guardan.
- El **modo sigiloso** no envía nada: cambia un bloqueo por un archivo vacío incluido en la extensión y usa nombres aleatorios en la página.
- El **registro de bloqueos** muestra las peticiones bloqueadas de una pestaña solo mientras su página está abierta; al cerrarla no queda nada.

## Alcance

Esta declaración describe a ScutumAD. Chrome y las webs que visitas tienen sus propias políticas y conexiones. ScutumAD bloquea muchos rastreadores conocidos, pero ninguna extensión puede garantizar que terceros no traten datos.
